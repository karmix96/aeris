"""Runtime vs accuracy vs AVL's array limit, as a function of chordwise panels.

AVL builds a dense influence matrix over all vortices and factorises it, so cost
scales ~N^3 in the vortex count while accuracy saturates. DECISION-0009 picked 24
chordwise panels on accuracy alone and never priced it.
"""
import time
from pathlib import Path
from aeris.common.config import load_yaml_config
from aeris.geometry.config_resolver import resolve_generator_and_config
from aeris.geometry.registry import get_geometry_generator
from aeris.generators.bwb_segmented_v1.pygeo_avl_adapter import (
    build_pygeo_sections_from_config, run_pygeo_native_avl_case)
from aeris.aero.models import FlightCondition

C = Path("configs/geometry/bwb.yaml")
OUT = Path("data/testaudit/cost_runs")
gid, g = resolve_generator_and_config(load_yaml_config(C))
s = get_geometry_generator(gid).sample_one(g, seed=7000)
fc = FlightCondition(alpha_deg=6.0, beta_deg=0.0, velocity_mps=28.0, altitude_m=0.0)
ex, semi, meta = build_pygeo_sections_from_config(C, sample=s)

def solve(nch, panels, tag):
    t = time.perf_counter()
    r = run_pygeo_native_avl_case(
        flight_condition=fc, output_dir=OUT / tag, extracted_sections=ex,
        semispan_m=semi, control=meta["control"], control_input_deg=4.0,
        diff_input_deg=4.0, viscous=True, name="c", nchordwise=nch,
        spanwise_panels_per_section=panels, timeout_sec=1200)
    dt = time.perf_counter() - t
    cd = r.control_derivatives or {}
    sym = next((v for k, v in cd.items() if k.endswith("_sym")), {})
    st = r.stability_axis_derivatives or {}
    return dict(t=dt, status=r.status, nv=r.n_strips and r.n_strips*nch,
                strips=r.n_strips, CL=r.cl, Cm=r.cm, Xnp=r.x_np,
                CLa=st.get("CLa"), Cmq=st.get("Cmq"), CL_de=sym.get("CL"),
                Cm_de=sym.get("Cm"))

REF = solve(30, 4, "ref30")   # richest LEGAL mesh at fixed spanwise: 192x30=5760 < 6000
print(f"reference: 30 chordwise, {REF['strips']} strips, {REF['nv']} vortices, "
      f"{REF['t']:.1f}s\n")
print(f"{'nch':>4}{'vortices':>10}{'time_s':>9}{'speedup':>9}"
      f"{'CL':>9}{'Xnp':>9}{'CL_de':>9}{'Cm_de':>9}  worst%")
rows = []
for nch in (4, 6, 8, 12, 16, 24):
    r = solve(nch, 4, f"nch{nch}")
    errs = {}
    for q in ("CL", "Cm", "Xnp", "CLa", "Cmq", "CL_de", "Cm_de"):
        a, b = r.get(q), REF.get(q)
        if isinstance(a, float) and isinstance(b, float) and abs(b) > 1e-4:
            errs[q] = abs(a-b)/max(abs(a), abs(b))
    worst = max(errs.values()) if errs else float("nan")
    rows.append((nch, r, worst, errs))
    print(f"{nch:>4}{r['nv']:>10}{r['t']:>9.1f}{REF['t']/r['t']:>8.1f}x"
          f"{r['CL']:>9.4f}{r['Xnp']:>9.4f}{r['CL_de']:>9.5f}{r['Cm_de']:>9.5f}"
          f"  {worst*100:6.2f}%")
print("\nworst-quantity breakdown:")
for nch, r, w, e in rows:
    print(f"  nch={nch:>2}: " + "  ".join(f"{k}={v*100:.2f}%" for k, v in
                                          sorted(e.items(), key=lambda kv: -kv[1])[:4]))
