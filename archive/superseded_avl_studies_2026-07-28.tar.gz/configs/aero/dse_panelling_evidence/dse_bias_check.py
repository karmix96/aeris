"""Is the cheap-panelling error a consistent BIAS or scatter?

A 3.8% control-derivative error is acceptable for design-space *ranking* only if
every design is wrong by nearly the same factor -- then it cancels in comparisons.
If the error scatters, cheap panelling reorders designs and the DSE is worthless.
This measures the ratio cheap/rich per geometry; the spread is the answer.
"""
import dataclasses, json, statistics as S
from pathlib import Path
from aeris.common.config import load_yaml_config
from aeris.geometry.config_resolver import resolve_generator_and_config
from aeris.geometry.registry import get_geometry_generator
from aeris.generators.bwb_segmented_v1.pygeo_avl_adapter import (
    build_pygeo_sections_from_config, run_pygeo_native_avl_case)
from aeris.aero.models import FlightCondition

C = Path("configs/geometry/bwb.yaml")
OUT = Path("data/lowfi_avl_study/dse_bias")
DSE, VERIF = 12, 24
gid, g = resolve_generator_and_config(load_yaml_config(C))
gen = get_geometry_generator(gid); base = gen.sample_one(g, seed=7000)
fc = FlightCondition(alpha_deg=6.0, beta_deg=0.0, velocity_mps=28.0, altitude_m=0.0)

CASES = {"nominal": {},
         "elevon_narrow": dict(elevon_start_frac=0.70, elevon_end_frac=0.85),
         "elevon_wide": dict(elevon_start_frac=0.50, elevon_end_frac=0.98),
         "max_gradient": dict(sw1_deg=-40.0, sw3_deg=-25.0, c2_ratio=0.80,
                              c4_ratio=0.08, split_ratio=0.40, b3_ratio=0.55),
         "max_ar": dict(b_total_m=1.25, c1_m=0.70, c4_ratio=0.08)}
for sd in (1001, 1010):
    CASES[f"random_{sd}"] = None

def solve(sample, nch, tag):
    ex, semi, m = build_pygeo_sections_from_config(C, sample=sample)
    r = run_pygeo_native_avl_case(
        flight_condition=fc, output_dir=OUT / tag, extracted_sections=ex,
        semispan_m=semi, control=m["control"], control_input_deg=4.0,
        diff_input_deg=4.0, viscous=True, name="b", nchordwise=nch,
        timeout_sec=1200)
    cd = r.control_derivatives or {}
    sym = next((v for k, v in cd.items() if k.endswith("_sym")), {})
    st = r.stability_axis_derivatives or {}
    return {"status": r.status, "CL": r.cl, "Cm": r.cm, "Xnp": r.x_np,
            "CLa": st.get("CLa"), "Cmq": st.get("Cmq"),
            "CL_de": sym.get("CL"), "Cm_de": sym.get("Cm")}

QS = ("CL", "Cm", "Xnp", "CLa", "Cmq", "CL_de", "Cm_de")
rows, out = {}, {}
for name, ov in CASES.items():
    s = gen.sample_one(g, seed=int(name.split("_")[1])) if ov is None \
        else dataclasses.replace(base, **ov)
    a = solve(s, DSE, f"{name}_dse"); b = solve(s, VERIF, f"{name}_verif")
    if a["status"] != "SUCCESS" or b["status"] != "SUCCESS":
        print(f"  !! {name}: {a['status']}/{b['status']} -- skipped"); continue
    out[name] = {"dse": a, "verif": b,
                 "ratio": {q: (a[q]/b[q]) for q in QS
                           if isinstance(a[q], float) and isinstance(b[q], float)
                           and abs(b[q]) > 1e-4}}
    for q, v in out[name]["ratio"].items(): rows.setdefault(q, []).append(v)
    print(f"  {name:<15} " + "  ".join(
        f"{q}={out[name]['ratio'][q]:.4f}" for q in ("CL", "CL_de", "Cm_de")
        if q in out[name]["ratio"]))

L = [f"DSE bias consistency: nchordwise {DSE} vs {VERIF}, {len(out)} geometries", "",
     "ratio = cheap/rich. A ratio far from 1 is BIAS (cancels in ranking).",
     "Spread of the ratio is what actually breaks a DSE.", "",
     f"{'quantity':<10}{'mean ratio':>12}{'bias %':>9}{'spread (max-min)':>19}{'as % of bias':>14}"]
for q in QS:
    v = rows.get(q)
    if not v or len(v) < 2: continue
    mean = S.fmean(v); spread = max(v) - min(v)
    bias = abs(mean - 1.0) * 100
    L.append(f"{q:<10}{mean:>12.4f}{bias:>8.2f}%{spread:>19.5f}"
             f"{(spread*100/bias if bias > 1e-9 else float('nan')):>13.1f}%")
L += ["", "Reading: if 'spread' is small next to 'bias %', the cheap mesh shifts every",
      "design by the same factor -- rankings are preserved and the DSE is sound."]
OUT.mkdir(parents=True, exist_ok=True)
(OUT / "dse_bias.json").write_text(json.dumps(out, indent=2, default=str))
txt = "\n".join(L); print("\n" + txt)
(OUT / "dse_bias.txt").write_text(txt + "\n")
