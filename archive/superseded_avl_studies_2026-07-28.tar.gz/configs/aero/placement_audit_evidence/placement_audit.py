"""Two audits of the DECISION-0014 verdict.

TEST 1 -- IS THE REFERENCE NEUTRAL?
The reference used in the placement study is 49 sections, uniform + pinned. But
approach B is *also* uniform + pinned, just coarser. If a 49-section mesh still
carries a placement-dependent bias, then B resembles the yardstick structurally and
scores well for that reason alone -- a circular comparison. A trustworthy reference
must give the SAME answer whether it is built uniform or adaptive. This measures
that disagreement and compares it to the B-vs-C gap it is supposed to resolve.

TEST 2 -- IS 25 SECTIONS PAST THE POINT WHERE PLACEMENT MATTERS?
Adaptive placement exists to buy accuracy per section. At a generous budget the
uniform grid already resolves everything and redistribution can only cost. The
honest question is not "which wins at 25" but "at what budget does each win".

    python standalone/lowfi_avl_study/placement_audit.py
"""

from __future__ import annotations

import dataclasses
import json
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[2]
CONFIG = REPO / "configs" / "geometry" / "bwb.yaml"
OUT = REPO / "data" / "lowfi_avl_study" / "placement_audit"

ALPHA, VELOCITY, DE, DA = 6.0, 28.0, 4.0, 4.0
REF_N, REF_PANELS = 49, 2
REF_FLOOR = 1e-4
BUDGETS = (11, 15, 19, 25)
CONTROL = ("CL_de", "Cm_de", "Cl_da", "CY_da", "Cn_da")
TRACKED = ("CL", "CDind", "cd_total", "Cm", "e", "Xnp", "CLa", "Cma",
           "Clp", "Cnb", "Cmq") + CONTROL

CASES = {
    "nominal": {},
    "elevon_narrow": dict(elevon_start_frac=0.70, elevon_end_frac=0.85),
    "max_gradient": dict(sw1_deg=-40.0, sw2_deg=-15.0, sw3_deg=-25.0,
                         c2_ratio=0.80, c3_ratio=0.30, c4_ratio=0.08,
                         twist_b0_deg=1.0, twist_b3_deg=-8.0,
                         split_ratio=0.40, b3_ratio=0.55),
    "random_1001": None,
}


def _extract(res):
    s = res.stability_axis_derivatives or {}
    cd = res.control_derivatives or {}
    sym = next((v for k, v in cd.items() if k.endswith("_sym")), {})
    dif = next((v for k, v in cd.items() if k.endswith("_diff")), {})
    return {"CL": res.cl, "CDind": res.cd_ind, "cd_total": res.cd_total,
            "Cm": res.cm, "e": res.span_efficiency, "Xnp": res.x_np,
            "CLa": s.get("CLa"), "Cma": s.get("Cma"), "Clp": s.get("Clp"),
            "Cnb": s.get("Cnb"), "Cmq": s.get("Cmq"),
            "CL_de": sym.get("CL"), "Cm_de": sym.get("Cm"),
            "Cl_da": dif.get("Cl"), "CY_da": dif.get("CY"),
            "Cn_da": dif.get("Cn"), "status": res.status}


def run(sample, *, n, placement, tag, panels=4):
    import aeris.geometry.config_resolver as CR
    from aeris.aero.models import FlightCondition
    from aeris.common.config import load_yaml_config
    from aeris.generators.bwb_segmented_v1.pygeo_avl_adapter import (
        build_pygeo_sections_from_config, run_pygeo_native_avl_case)

    gid, gc = CR.resolve_generator_and_config(load_yaml_config(CONFIG))
    gc2 = dataclasses.replace(gc, aero_discretisation=dataclasses.replace(
        gc.aero_discretisation, section_placement=placement,
        snap_sections_to_control=True, n_sections=n,
        spanwise_panels_per_section=panels))
    orig = CR.resolve_generator_and_config
    CR.resolve_generator_and_config = lambda raw: (gid, gc2)
    try:
        ex, semi, meta = build_pygeo_sections_from_config(
            CONFIG, sample=sample, n_sections=n)
    finally:
        CR.resolve_generator_and_config = orig

    fc = FlightCondition(alpha_deg=ALPHA, beta_deg=0.0,
                         velocity_mps=VELOCITY, altitude_m=0.0)
    r = run_pygeo_native_avl_case(
        flight_condition=fc, output_dir=OUT / tag, extracted_sections=ex,
        semispan_m=semi, control=meta["control"], control_input_deg=DE,
        diff_input_deg=DA, viscous=True, name="pa",
        spanwise_panels_per_section=panels, nchordwise=meta["nchordwise"],
        cspace=meta["cspace"], timeout_sec=900)
    out = _extract(r)
    out["placement"] = meta["section_placement"]
    out["ramp"] = meta.get("ramp_fraction")
    return out


def errs(got, ref):
    d = {}
    for q in TRACKED:
        a, b = got.get(q), ref.get(q)
        if not isinstance(a, float) or not isinstance(b, float):
            continue
        if abs(b) <= REF_FLOOR:
            continue
        m = max(abs(a), abs(b))
        if m > 1e-30:
            d[q] = abs(a - b) / m
    return d


def main():
    from aeris.common.config import load_yaml_config
    from aeris.geometry.config_resolver import resolve_generator_and_config
    from aeris.geometry.registry import get_geometry_generator

    OUT.mkdir(parents=True, exist_ok=True)
    gid, gcfg = resolve_generator_and_config(load_yaml_config(CONFIG))
    gen = get_geometry_generator(gid)
    base = gen.sample_one(gcfg, seed=7000)
    samples = {k: (gen.sample_one(gcfg, seed=int(k.split("_")[1])) if v is None
                   else dataclasses.replace(base, **v)) for k, v in CASES.items()}

    report = {"test1": {}, "test2": {}}

    # ---------------- TEST 1 : reference neutrality ----------------------
    print("=" * 74)
    print("TEST 1 -- is the 49-section reference neutral to placement?")
    print("=" * 74)
    refs = {}
    for name, s in samples.items():
        ru = run(s, n=REF_N, placement="never", tag=f"{name}_ref_uniform",
                 panels=REF_PANELS)
        ra = run(s, n=REF_N, placement="always", tag=f"{name}_ref_adaptive",
                 panels=REF_PANELS)
        if ru["status"] != "SUCCESS" or ra["status"] != "SUCCESS":
            print(f"  !! {name}: {ru['status']}/{ra['status']}"); continue
        e = errs(ra, ru)
        refs[name] = ru
        report["test1"][name] = {"disagreement": e,
                                 "worst": max(e.values()) if e else None,
                                 "worst_q": max(e, key=e.get) if e else None}
        w = report["test1"][name]
        print(f"  {name:<15} worst disagreement {w['worst']*100:6.2f}%  "
              f"({w['worst_q']})   ctrl "
              f"{max((v for k, v in e.items() if k in CONTROL), default=0)*100:5.2f}%")

    # ---------------- TEST 2 : budget sweep ------------------------------
    print()
    print("=" * 74)
    print("TEST 2 -- at what section budget does adaptive placement pay?")
    print("=" * 74)
    print(f"{'geometry':<15}{'budget':>7}{'B ctrl':>9}{'C ctrl':>9}"
          f"{'B all':>8}{'C all':>8}   winner(all)")
    for name, s in samples.items():
        if name not in refs:
            continue
        report["test2"][name] = {}
        for n in BUDGETS:
            b = run(s, n=n, placement="never", tag=f"{name}_b{n}_uniform")
            c = run(s, n=n, placement="always", tag=f"{name}_b{n}_adaptive")
            if b["status"] != "SUCCESS" or c["status"] != "SUCCESS":
                print(f"  {name:<15}{n:>7}  {b['status']}/{c['status']}")
                continue
            eb, ec = errs(b, refs[name]), errs(c, refs[name])
            gb = max((v for k, v in eb.items() if k in CONTROL), default=np.nan)
            gc_ = max((v for k, v in ec.items() if k in CONTROL), default=np.nan)
            ab = max(eb.values()) if eb else np.nan
            ac = max(ec.values()) if ec else np.nan
            report["test2"][name][n] = {
                "B": {"ctrl": gb, "all": ab, "errors": eb, "ramp": b["ramp"]},
                "C": {"ctrl": gc_, "all": ac, "errors": ec, "ramp": c["ramp"]}}
            win = "B uniform" if ab < ac else "C adaptive"
            print(f"  {name:<15}{n:>7}{gb*100:>8.2f}%{gc_*100:>8.2f}%"
                  f"{ab*100:>7.2f}%{ac*100:>7.2f}%   {win}")

    (OUT / "placement_audit.json").write_text(
        json.dumps(report, indent=2, default=str), encoding="utf-8")
    print("\nwrote", OUT / "placement_audit.json")


if __name__ == "__main__":
    main()
