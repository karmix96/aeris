"""Aerodynamic consequence of the placement choice: full polars, not single points.

A discretisation study that reports one alpha invites the question "does it hold
across the envelope?". This sweeps alpha for uniform+pins, gated adaptive, and the
panel-matched reference, on a benign geometry (where the gate stays shut) and a
narrow-elevon geometry (where it opens).
"""
from __future__ import annotations
import dataclasses, json
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
CONFIG = REPO / "configs" / "geometry" / "bwb.yaml"
OUT = REPO / "data" / "lowfi_avl_study" / "polars"
ALPHAS = (-2.0, 0.0, 2.0, 4.0, 6.0, 8.0, 10.0, 12.0)
DE = DA = 4.0


def solve(sample, n, placement, alpha, tag, panels=4):
    import aeris.geometry.config_resolver as CR
    from aeris.aero.models import FlightCondition
    from aeris.common.config import load_yaml_config
    from aeris.generators.bwb_segmented_v1.pygeo_avl_adapter import (
        build_pygeo_sections_from_config, run_pygeo_native_avl_case)
    gid, gc = CR.resolve_generator_and_config(load_yaml_config(CONFIG))
    gc2 = dataclasses.replace(gc, aero_discretisation=dataclasses.replace(
        gc.aero_discretisation, section_placement=placement,
        snap_sections_to_control=True, n_sections=n,
        spanwise_panels_per_section=panels))
    orig = CR.resolve_generator_and_config
    CR.resolve_generator_and_config = lambda raw: (gid, gc2)
    try:
        ex, semi, meta = build_pygeo_sections_from_config(CONFIG, sample=sample,
                                                          n_sections=n)
    finally:
        CR.resolve_generator_and_config = orig
    fc = FlightCondition(alpha_deg=alpha, beta_deg=0.0, velocity_mps=28.0,
                         altitude_m=0.0)
    r = run_pygeo_native_avl_case(
        flight_condition=fc, output_dir=OUT / tag, extracted_sections=ex,
        semispan_m=semi, control=meta["control"], control_input_deg=DE,
        diff_input_deg=DA, viscous=True, name="pol",
        spanwise_panels_per_section=panels, nchordwise=meta["nchordwise"],
        cspace=meta["cspace"], timeout_sec=900)
    cd = r.control_derivatives or {}
    sym = next((v for k, v in cd.items() if k.endswith("_sym")), {})
    return {"alpha": alpha, "status": r.status, "CL": r.cl, "CD": r.cd_total,
            "CDind": r.cd_ind, "Cm": r.cm, "e": r.span_efficiency,
            "Xnp": r.x_np, "CL_de": sym.get("CL"), "Cm_de": sym.get("Cm"),
            "placement": meta["section_placement"],
            "ramp": meta.get("ramp_fraction")}


def main():
    from aeris.common.config import load_yaml_config
    from aeris.geometry.config_resolver import resolve_generator_and_config
    from aeris.geometry.registry import get_geometry_generator
    OUT.mkdir(parents=True, exist_ok=True)
    gid, g = resolve_generator_and_config(load_yaml_config(CONFIG))
    base = get_geometry_generator(gid).sample_one(g, seed=7000)
    cases = {"nominal": base,
             "elevon_narrow": dataclasses.replace(
                 base, elevon_start_frac=0.70, elevon_end_frac=0.85)}
    configs = {"uniform_pinned": dict(n=25, placement="never", panels=4),
               "auto": dict(n=25, placement="auto", panels=4),
               "reference": dict(n=49, placement="never", panels=2)}
    rep = {}
    for cname, s in cases.items():
        rep[cname] = {}
        for kname, cfg in configs.items():
            rows = []
            for a in ALPHAS:
                r = solve(s, cfg["n"], cfg["placement"], a,
                          f"{cname}_{kname}_a{a:+.0f}", cfg["panels"])
                rows.append(r)
                print(f"  {cname:<14}{kname:<15}a={a:+5.1f}  "
                      f"CL={r['CL']}  {r['status']}")
            rep[cname][kname] = rows
    (OUT / "polars.json").write_text(json.dumps(rep, indent=2, default=str))
    print("\nwrote", OUT / "polars.json")


if __name__ == "__main__":
    main()
