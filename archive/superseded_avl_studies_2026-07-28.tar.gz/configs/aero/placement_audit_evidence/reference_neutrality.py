"""How fine must the reference be before its own placement stops mattering?

A reference that answers differently depending on how ITS sections were placed
cannot adjudicate a placement study -- and if one candidate shares its construction
(uniform+pins), that candidate is flattered. This finds the density at which the
disagreement falls below the effect we need to resolve (~0.5 pp).
"""
from __future__ import annotations
import dataclasses, json
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
CONFIG = REPO / "configs" / "geometry" / "bwb.yaml"
OUT = REPO / "data" / "lowfi_avl_study" / "reference_neutrality"
DENSITIES = (49, 73, 97)
FLOOR = 1e-4
CONTROL = ("CL_de", "Cm_de", "Cl_da", "CY_da", "Cn_da")
DRAG = ("CDind", "cd_total", "e")
TRACKED = ("CL", "CDind", "cd_total", "Cm", "e", "Xnp", "CLa", "Cma",
           "Clp", "Cnb", "Cmq") + CONTROL

import importlib
pa = importlib.import_module("standalone.lowfi_avl_study.placement_audit") \
    if False else None


def _extract(res):
    s = res.stability_axis_derivatives or {}
    cd = res.control_derivatives or {}
    sym = next((v for k, v in cd.items() if k.endswith("_sym")), {})
    dif = next((v for k, v in cd.items() if k.endswith("_diff")), {})
    return {"CL": res.cl, "CDind": res.cd_ind, "cd_total": res.cd_total,
            "Cm": res.cm, "e": res.span_efficiency, "Xnp": res.x_np,
            "CLa": s.get("CLa"), "Cma": s.get("Cma"), "Clp": s.get("Clp"),
            "Cnb": s.get("Cnb"), "Cmq": s.get("Cmq"),
            "CL_de": sym.get("CL"), "Cm_de": sym.get("Cm"),
            "Cl_da": dif.get("Cl"), "CY_da": dif.get("CY"),
            "Cn_da": dif.get("Cn"), "status": res.status}


def run(sample, n, placement, tag, panels=2):
    import aeris.geometry.config_resolver as CR
    from aeris.aero.models import FlightCondition
    from aeris.common.config import load_yaml_config
    from aeris.generators.bwb_segmented_v1.pygeo_avl_adapter import (
        build_pygeo_sections_from_config, run_pygeo_native_avl_case)
    gid, gc = CR.resolve_generator_and_config(load_yaml_config(CONFIG))
    gc2 = dataclasses.replace(gc, aero_discretisation=dataclasses.replace(
        gc.aero_discretisation, section_placement=placement,
        snap_sections_to_control=True, n_sections=n,
        spanwise_panels_per_section=panels))
    orig = CR.resolve_generator_and_config
    CR.resolve_generator_and_config = lambda raw: (gid, gc2)
    try:
        ex, semi, meta = build_pygeo_sections_from_config(CONFIG, sample=sample,
                                                          n_sections=n)
    finally:
        CR.resolve_generator_and_config = orig
    fc = FlightCondition(alpha_deg=6.0, beta_deg=0.0, velocity_mps=28.0,
                         altitude_m=0.0)
    r = run_pygeo_native_avl_case(
        flight_condition=fc, output_dir=OUT / tag, extracted_sections=ex,
        semispan_m=semi, control=meta["control"], control_input_deg=4.0,
        diff_input_deg=4.0, viscous=True, name="rn",
        spanwise_panels_per_section=panels, nchordwise=meta["nchordwise"],
        cspace=meta["cspace"], timeout_sec=1200)
    return _extract(r)


def diff(a, b):
    d = {}
    for q in TRACKED:
        x, y = a.get(q), b.get(q)
        if isinstance(x, float) and isinstance(y, float) and abs(y) > FLOOR:
            m = max(abs(x), abs(y))
            if m > 1e-30:
                d[q] = abs(x - y) / m
    return d


def main():
    from aeris.common.config import load_yaml_config
    from aeris.geometry.config_resolver import resolve_generator_and_config
    from aeris.geometry.registry import get_geometry_generator
    OUT.mkdir(parents=True, exist_ok=True)
    gid, g = resolve_generator_and_config(load_yaml_config(CONFIG))
    gen = get_geometry_generator(gid); base = gen.sample_one(g, seed=7000)
    cases = {"nominal": base,
             "elevon_narrow": dataclasses.replace(
                 base, elevon_start_frac=0.70, elevon_end_frac=0.85)}
    rep = {}
    print(f"{'geometry':<15}{'sections':>9}{'worst':>8}{'  quantity':<12}"
          f"{'ctrl':>7}{'drag':>8}")
    for name, s in cases.items():
        rep[name] = {}
        for n in DENSITIES:
            u = run(s, n, "never", f"{name}_{n}_uniform")
            a = run(s, n, "always", f"{name}_{n}_adaptive")
            if u["status"] != "SUCCESS" or a["status"] != "SUCCESS":
                print(f"  {name:<13}{n:>9}  {u['status']}/{a['status']}"); continue
            d = diff(a, u)
            worst = max(d, key=d.get)
            c = max((v for k, v in d.items() if k in CONTROL), default=0.0)
            dr = max((v for k, v in d.items() if k in DRAG), default=0.0)
            rep[name][n] = {"disagreement": d, "worst_q": worst,
                            "worst": d[worst], "ctrl": c, "drag": dr}
            print(f"{name:<15}{n:>9}{d[worst]*100:>7.2f}%  {worst:<12}"
                  f"{c*100:>6.2f}%{dr*100:>7.2f}%")
    (OUT / "reference_neutrality.json").write_text(
        json.dumps(rep, indent=2, default=str), encoding="utf-8")
    print("\nA reference is usable when 'worst' is well under the ~0.5 pp effect")
    print("we are trying to resolve between placement policies.")


if __name__ == "__main__":
    main()
