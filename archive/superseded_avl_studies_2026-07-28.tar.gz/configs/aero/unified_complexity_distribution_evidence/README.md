# Evidence — unified complexity section-distribution study

This folder is reserved for the publication-grade section-distribution campaign
implemented by `standalone/lowfi_avl_study/unified_complexity_distribution_study.py`.

The study is intentionally separate from the earlier placement decision evidence.
Its ranking score excludes AVL drag (`CDind`, `cd_total`, `e`) because the
reference-neutrality audit showed the drag reference disagrees with itself by
roughly 1-3% depending on spanwise station placement. Drag is still reported as a
diagnostic.

Figures are written to `studies/figures/unified_complexity_distribution/`.
