# DECISION-0013 — Two panelling tiers: DSE (12 chordwise) and verification (24)

- **Date**: 2026-07-26
- **Status**: Accepted
- **Supersedes**: the chordwise panel count in DECISION-0009 (24 everywhere)
- **Study**: `studies/dse_panelling_cost_accuracy.md`
- **Evidence**: `configs/aero/dse_panelling_evidence/`

## Context

A single low-fidelity design point cost **58 s**, making a 2000-design × 5-α sweep
6.7 days. DECISION-0009 selected 24 chordwise panels on accuracy grounds and never
measured the runtime consequence.

Stage timing shows the solver is the whole cost — pyGeo lofting 1.36 s, NeuralFoil
viscous 0.60 s, **AVL 56.93 s**. AVL factorises a dense influence matrix, so cost
grows ~cubically in vortex count, and 192 strips × 24 chordwise = 4608 vortices is
77% of AVL's compiled ~6000 limit.

## Decision

Ship **nchordwise = 12** as the default in `configs/geometry/bwb.yaml`, and treat
**24** as an explicitly-selected verification setting.

| tier | nchordwise | vortices | cost/point | use |
|---|---|---|---|---|
| DSE | 12 | 2304 | 14.6 s | sweeps, DoE, optimisation, screening |
| Verification | 24 | 4608 | 57.3 s | promoted designs, control sizing, pre-CFD |

## Rationale

1. **The expensive panels buy one class of quantity.** At every setting the worst
   error is a control derivative. `Xnp` is identical (0.3350) from 6 panels upward;
   `CL`, `Cm` and the stability derivatives are inside 1.5% by 8. At 12: CL 0.51%,
   Cm 0.67%, Xnp 0.00%, CL_δe 3.76%.

2. **The control-derivative error is a bias, not scatter.** CL_δe rises
   monotonically with panel count (0.00983 → 0.01163). A consistent bias cancels
   when designs are *ranked*, which is what a DSE does. Verified across geometries
   by `dse_bias_check.py`, which reports the spread of the cheap/rich ratio against
   the magnitude of the bias.

3. **12 is chosen against a requirement, not a knee.** The curve has no sharp knee —
   returns are near constant-elasticity — so 8 (7.4% control error, too coarse for
   a sizing quantity) and 16 (25.4 s, puts a 2000-design sweep back to 14 h) are
   both defensible on curvature alone. 12 is the cheapest setting that keeps every
   non-control quantity under 0.7% while bringing a 2000-design sweep to ~20 h.

## Consequences

- Every DSE/DoE result carries a stated ~4% bias-dominated error on elevon
  authority. Control-authority *sizing* must be re-run at 24.
- DECISION-0009's "24 chordwise" is now scoped to verification only. Its underlying
  finding (8 panels → 7.7% elevon error) is unchanged and is what sets the floor.
- DECISION-0010's control-resolution criterion (N_flap ≥ 6 panels aft of the hinge)
  still governs. At 12 chordwise with cosine spacing the aft-of-hinge count must be
  re-checked for any hinge position other than 0.75c.

## Guard added

AVL's response to exceeding its compiled arrays is a run with `status=FAILED` and
every coefficient `None` — indistinguishable from a physics failure, and it
silently produced an all-`NaN` study. `avl_limits_ok()` was only consulted at
config-parse time. `write_native_avl` now raises on both the NSMAX=500 strip limit
and the ~6000 vortex limit, with the remedy in the message. Covered by two tests in
`tests/aero/test_native_avl_physics_validation.py`.
