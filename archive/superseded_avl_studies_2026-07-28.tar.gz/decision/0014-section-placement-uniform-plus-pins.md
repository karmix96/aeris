# DECISION-0014 — Section placement: hard feature pins always; adaptive placement gated ("auto")

- **Date**: 2026-07-26 (revised same day after audit)
- **Status**: **DISPUTED (2026-07-28)** — configuration unchanged pending a
  convergence study; the ranking below is not established. See
  `studies/monitor_study_audit.md`.
- **Refines**: DECISION-0011 / DECISION-0012 (does not reverse them)
- **Study**: `studies/section_placement_decision.md`
- **Evidence**: `configs/aero/placement_decision_evidence/`,
  `configs/aero/placement_audit_evidence/`,
  `configs/aero/monitor_study_reanalysis/`

## Dispute notice (2026-07-28)

Re-analysis of the same 100 runs under seven defensible score definitions puts
every policy in a rank spread of at least three places, and puts both policies
previously declared "winner" at 1st under some definitions and 7th–8th under
others. The aggregate separation is 0.05–0.1 pp against a reference whose own
self-disagreement is ≥0.65 pp.

**The withdrawal recorded below was itself half-wrong.** It rested on two legs:

1. *"The reference disagrees with itself on drag, so the drag comparison is
   noise."* — **This leg does not hold.** A biased reference shared by every
   candidate is common-mode and cancels in a paired comparison; self-disagreement
   inflates absolute error, not the ranking. Re-tested as a paired sign test,
   uniform+pins beats adaptive on `CDind` on 59 of 80 paired comparisons,
   *p* = 1.3e−05. That is systematic, not scatter.
2. *"The reference shares the uniform candidate's construction, so uniform is
   flattered."* — **This leg stands**, and it is now the only thing preventing the
   drag result from being decisive.

Consequently the drag finding is neither established nor refuted, and the
"never rank discretisation with drag" rule is downgraded: drag is the design
objective and must be reported and scored. What the rule should have said is
*do not score drag against a reference built by one of the candidate rules*.
The fix is a reference-free h-refinement convergence study, not deletion of the
quantity.

## Revision notice (superseded by the dispute notice above)

An earlier version of this decision selected `section_placement: never` on the
grounds that adaptive placement cost induced drag. **That finding was withdrawn.**
An audit showed the reference could not resolve drag at all: built uniform versus
adaptive at the same density, it disagreed with *itself* by 1.2–2.9% on
`CDind`/`cd_total`, which is larger than the effect it was being used to measure.
The drag comparison was noise, and because the reference was itself uniform+pinned,
the uniform candidate was additionally flattered by sharing its construction.

## Decision

Ship `section_placement: auto` with `snap_sections_to_control: true`.

## What the evidence supports

Ranked on quantities the reference can resolve — control derivatives, forces and
stability derivatives, **excluding drag** — at a matched 25-section budget over 10
geometries:

| approach | mean | **max** |
|---|---|---|
| A uniform, no pins | 15.17% | 34.54% |
| B uniform + hard pins | **0.82%** | 1.98% |
| C adaptive, gated (`auto`) | 0.86% | **1.68%** |
| D adaptive, forced (`always`) | 0.91% | 1.68% |

1. **Hard feature pins do nearly all the work.** Without them the worst case is
   34.54%. This is the single largest effect in the study and is not in doubt.
2. **B and C are a tie on the mean** — 0.04 pp apart, inside the reference's own
   ~0.5% control-derivative noise. Any claim that one is "better on average" is
   unsupported.
3. **C has the better tail**, and wins where the gain ramp is severe: narrow elevon
   (66.7% ramp) 1.52% → 1.12%; random_1020 (36.3%) 1.98% → 1.42%. On the five
   benign geometries the gate does not fire and C is byte-identical to B.
4. A budget sweep (11/15/19/25 sections) confirms the effect is not an artefact of
   one budget: on the narrow elevon, adaptive beats uniform on control derivatives
   at **every** budget tested — 6.26/4.43, 2.94/0.63, 1.25/0.20, 1.52/0.63.

Gating is therefore doing exactly its job: no change where uniform suffices, a
worst-case improvement where it does not.

## Hard constraint discovered: drag cannot judge placement

The reference's self-disagreement on drag by density:

| sections | nominal | elevon_narrow |
|---|---|---|
| 49 | 2.90% | 0.83% |
| 73 | 1.37% | 0.67% |
| 97 | 1.17% | 0.74% |

It plateaus above 1% rather than converging. AVL computes induced drag by
Trefftz-plane integration of the spanwise load, which is acutely sensitive to how
stations sample that load — so a placement change moves the answer directly, and
"more sections" does not make the sensitivity go away at any affordable density.

**Rule of record: `CDind`, `cd_total` and `e` must not be used to rank spanwise
discretisation choices in AVL.** They may be reported; they may not adjudicate.

## Consequences

- `ramp_fraction_limit: 0.15` remains the gate. It is imperfect — random_1001
  (32.7% ramp) got worse under adaptive placement (0.81% → 1.68%) — so ramp alone
  does not fully predict benefit. Retuning it is an open item, not a blocker.
- `--section-placement always` remains available and is the right choice when a
  study specifically targets control authority on a short-span control surface.
- Ten geometries and 0.3 pp differences: the tail result is actionable, the mean
  difference is not. Reported as such.

## Related fix (unchanged, independent of the above)

Pins were unioned onto the base grid with `np.unique`, removing only exact
duplicates. Across all 10 geometries the tightest interval was 2.4%–9.1% of uniform
spacing (~0.001 of span) — one of 25 stations wasted on a near-duplicate. Pins now
absorb any base station within `SLIVER_MERGE_FRACTION = 0.25` of a uniform interval,
and the largest-gap top-up respends the freed section.
