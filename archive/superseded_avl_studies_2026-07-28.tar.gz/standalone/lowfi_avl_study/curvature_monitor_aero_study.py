"""Aero-backed comparison of AVL section-placement monitors.

Purpose
-------
Close the placement debate with actual native-AVL outputs, not geometry-only
proxies. The study compares uniform section placement, the current AERIS
curvature monitor, and cleaner proposed monitors against a finer AVL reference.

The study is intentionally standalone. It does not change production code.

Usage
-----
    python standalone/lowfi_avl_study/curvature_monitor_aero_study.py
"""

from __future__ import annotations

import argparse
import csv
import dataclasses
import json
from dataclasses import asdict
from pathlib import Path
from typing import Any, Iterable

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np

from aeris.aero.models import FlightCondition
from aeris.aero.solvers.native_avl import run_native_avl_case
from aeris.common.config import load_yaml_config
from aeris.generators.bwb_segmented_v1.pygeo_adapter import (
    build_pygeo,
    extract_sections,
    stations_from_records,
)
from aeris.generators.bwb_segmented_v1.pygeo_avl_adapter import (
    build_realized_section_polar_bridge,
)
from aeris.generators.bwb_segmented_v1.pygeo_backend import _resolve_airfoil_database
from aeris.generators.bwb_segmented_v1.services import (
    build_section_geometry_from_sample,
    generate_bwb_planform_from_sample,
)
from aeris.geometry.config_resolver import resolve_generator_and_config
from aeris.geometry.geometric_information import (
    DEFAULT_CHANNEL_WEIGHTS,
    adaptive_span_fractions,
    probe_spanwise_geometry,
    ramp_fraction,
    spanwise_information_profile,
)
from aeris.geometry.registry import get_geometry_generator

REPO = Path(__file__).resolve().parents[2]
CONFIG = REPO / "configs/geometry/bwb.yaml"
OUT = REPO / "artifacts/curvature_monitor_aero_study"

ALPHA_DEG = 6.0
BETA_DEG = 0.0
VELOCITY_MPS = 28.0
ALTITUDE_M = 0.0
ELEVON_DEG = 4.0
DIFF_DEG = 4.0

N_BUDGET = 25
NCHORDWISE = 24
SPANWISE_PER_INTERVAL = 4
REF_SECTIONS = 49
REF_SPANWISE_PER_INTERVAL = 2

FLOOR = 0.50
SMOOTH = 9
CONTROL_EDGE_SMOOTHING = 0.02

TRACK = [
    "CL",
    "CDind",
    "CDtotal",
    "Cm",
    "e",
    "Xnp",
    "CLa",
    "Cma",
    "Clp",
    "Cmq",
    "Cnb",
    "CL_de",
    "Cm_de",
    "Cl_da",
    "Cn_da",
    "CY_da",
]

CONTROL_TRACK = ["CL_de", "Cm_de", "Cl_da", "Cn_da", "CY_da"]

CHANNEL_REFERENCE_SCALES: dict[str, str | float] = {
    "x_le": "root_chord",
    "z_le": "root_chord",
    "chord": "root_chord",
    "twist": 10.0,
    "thickness": 0.1,
    "camber": 0.1,
    "control_gain": 1.0,
}

COMPLEXITY_PLOT_POLICIES = [
    "current_sum_sqrt_w3",
    "proposed_sqrt_sum_w3",
    "proposed_max_channel_w3",
    "proposed_sqrt_sum_w3_no_thickness",
]


CONSTRUCTED_CASES: dict[str, dict[str, float]] = {
    "benign": dict(
        sw1_deg=-20.0,
        sw2_deg=-15.0,
        sw3_deg=-5.0,
        twist_b0_deg=0.0,
        twist_b1_deg=-0.5,
        twist_b2_deg=-1.5,
        twist_b3_deg=-2.0,
        dihedral_b2_deg=0.0,
        dihedral_b3_deg=0.0,
        c2_ratio=0.70,
        c3_ratio=0.45,
        c4_ratio=0.15,
        b_total_m=1.0,
        c1_m=0.9,
        elevon_hinge_frac=0.75,
    ),
    "nominal": {},
    "elevon_narrow": dict(elevon_start_frac=0.70, elevon_end_frac=0.85),
    "elevon_wide": dict(elevon_start_frac=0.50, elevon_end_frac=0.98),
    "max_gradient": dict(
        sw1_deg=-40.0,
        sw2_deg=-15.0,
        sw3_deg=-25.0,
        c2_ratio=0.80,
        c3_ratio=0.30,
        c4_ratio=0.08,
        twist_b0_deg=1.0,
        twist_b3_deg=-8.0,
        split_ratio=0.40,
        b3_ratio=0.55,
    ),
    "max_ar": dict(b_total_m=1.25, c1_m=0.70, c4_ratio=0.08, twist_b3_deg=-8.0),
}

RANDOM_SEEDS = [1001, 1002, 1010, 1020]


def _moving_average(values: np.ndarray, width: int) -> np.ndarray:
    if width <= 1:
        return values
    k = int(width) | 1
    kernel = np.ones(k) / float(k)
    return np.convolve(np.pad(values, k // 2, mode="edge"), kernel, mode="valid")


def _control_gain(span_fraction: np.ndarray, band: tuple[float, float]) -> np.ndarray:
    lo, hi = band
    w = max(CONTROL_EDGE_SMOOTHING, 1e-4)
    return 0.5 * (np.tanh((span_fraction - lo) / w) - np.tanh((span_fraction - hi) / w))


def _strict_unique(values: Iterable[float], *, tol: float = 1e-4) -> list[float]:
    raw = sorted(min(max(float(v), 0.0), 1.0) for v in values)
    if not raw:
        return [0.0, 1.0]
    out = [raw[0]]
    for value in raw[1:]:
        if value - out[-1] >= tol:
            out.append(value)
        else:
            out[-1] = 0.5 * (out[-1] + value)
    out[0] = 0.0
    out[-1] = 1.0
    return out


def _pin_and_repair_count(nodes: np.ndarray, pins: Iterable[float], n: int) -> np.ndarray:
    values = np.asarray(nodes, dtype=float).copy()
    pins_clean = [float(p) for p in pins if 0.0 < float(p) < 1.0]
    for pin in pins_clean:
        interior = np.arange(1, len(values) - 1)
        if interior.size == 0:
            break
        nearest = int(interior[np.argmin(np.abs(values[interior] - pin))])
        values[nearest] = pin

    nodes_list = _strict_unique(values)
    pinned = {round(p, 12) for p in pins_clean}
    while len(nodes_list) < n:
        gaps = [(nodes_list[i + 1] - nodes_list[i], i) for i in range(len(nodes_list) - 1)]
        _, idx = max(gaps, key=lambda item: item[0])
        nodes_list.insert(idx + 1, 0.5 * (nodes_list[idx] + nodes_list[idx + 1]))
    while len(nodes_list) > n:
        candidates = [
            (min(nodes_list[i] - nodes_list[i - 1], nodes_list[i + 1] - nodes_list[i]), i)
            for i in range(1, len(nodes_list) - 1)
            if round(nodes_list[i], 12) not in pinned
        ]
        if not candidates:
            break
        _, idx = min(candidates, key=lambda item: item[0])
        nodes_list.pop(idx)
    return np.asarray(_strict_unique(nodes_list), dtype=float)


def _limit_max_gap(
    nodes: np.ndarray, pins: Iterable[float], n: int, max_gap_ratio: float
) -> np.ndarray:
    """Simple spacing repair: split largest gap, remove tightest non-pinned node."""
    nodes_list = _strict_unique(nodes)
    pinned = {round(float(p), 12) for p in pins if 0.0 < float(p) < 1.0}
    target = max_gap_ratio / float(n - 1)
    for _ in range(50):
        gaps = np.diff(np.asarray(nodes_list, dtype=float))
        if float(np.max(gaps)) <= target + 1e-9:
            break
        idx = int(np.argmax(gaps))
        inserted = 0.5 * (nodes_list[idx] + nodes_list[idx + 1])
        nodes_list.insert(idx + 1, inserted)
        candidates = []
        for i in range(1, len(nodes_list) - 1):
            if abs(nodes_list[i] - inserted) < 1e-12:
                continue
            if round(nodes_list[i], 12) in pinned:
                continue
            local_width = nodes_list[i + 1] - nodes_list[i - 1]
            candidates.append((local_width, i))
        if not candidates:
            break
        _, remove_idx = min(candidates, key=lambda item: item[0])
        nodes_list.pop(remove_idx)
        nodes_list = _strict_unique(nodes_list)
    return _pin_and_repair_count(np.asarray(nodes_list, dtype=float), pins, n)


def _feature_pins_from_sample(sample: Any) -> list[float]:
    """Hard span stations where AVL should get an exact section."""
    first_break = (1.0 - float(sample.b3_ratio)) * float(sample.split_ratio)
    second_break = 1.0 - float(sample.b3_ratio)
    pins = [
        0.0,
        first_break,
        second_break,
        float(sample.elevon_start_frac),
        float(sample.elevon_end_frac),
        1.0,
    ]
    return _strict_unique(pins, tol=1e-6)


def _policy_weights(
    *,
    control_weight: float,
    thickness_weight: float = 1.0,
    camber_weight: float = 1.0,
) -> dict[str, float]:
    weights = dict(DEFAULT_CHANNEL_WEIGHTS)
    weights["control_gain"] = float(control_weight)
    weights["thickness"] = float(thickness_weight)
    weights["camber"] = float(camber_weight)
    return weights


def _density_and_cumulative(
    y: np.ndarray,
    monitor: np.ndarray,
    *,
    floor: float,
) -> tuple[np.ndarray, np.ndarray]:
    span_len = float(y[-1] - y[0])
    area = float(np.trapezoid(monitor, y))
    if area <= 1e-12 or span_len <= 1e-12:
        blended = np.ones_like(y) / max(span_len, 1e-12)
    else:
        blended = monitor / area
    uniform = np.ones_like(y) / span_len
    density = (1.0 - floor) * blended + floor * uniform
    density = density / float(np.trapezoid(density, y))
    cumulative = np.concatenate([[0.0], np.cumsum(0.5 * (density[1:] + density[:-1]) * np.diff(y))])
    cumulative = cumulative / cumulative[-1]
    return density, cumulative


def _proposed_density(
    probe: dict[str, np.ndarray],
    band: tuple[float, float],
    *,
    mode: str,
    control_weight: float,
    thickness_weight: float = 1.0,
    camber_weight: float = 1.0,
    floor: float = FLOOR,
) -> tuple[np.ndarray, np.ndarray]:
    weights = _policy_weights(
        control_weight=control_weight,
        thickness_weight=thickness_weight,
        camber_weight=camber_weight,
    )

    y = np.asarray(probe["y_m"], dtype=float)
    span_fraction = np.asarray(probe["span_fraction"], dtype=float)
    root_chord = float(np.asarray(probe["chord"], dtype=float)[0]) or 1.0
    sources = {
        "x_le": np.asarray(probe["x_le"], dtype=float),
        "z_le": np.asarray(probe["z_le"], dtype=float),
        "chord": np.asarray(probe["chord"], dtype=float),
        "twist": np.asarray(probe["twist_deg"], dtype=float),
        "thickness": np.asarray(probe["thickness"], dtype=float),
        "camber": np.asarray(probe["camber"], dtype=float),
        "control_gain": _control_gain(span_fraction, band),
    }

    combined_curvature = np.zeros_like(y)
    max_terms: list[np.ndarray] = []
    for name, values in sources.items():
        weight = float(weights.get(name, 0.0))
        if weight <= 0.0:
            continue
        ref = CHANNEL_REFERENCE_SCALES.get(name, 1.0)
        scale = root_chord if ref == "root_chord" else float(ref)
        if scale <= 0.0 or float(np.max(values) - np.min(values)) <= 1e-12:
            continue
        scaled = (values - float(np.min(values))) / scale
        d1 = np.gradient(scaled, y, edge_order=2)
        d2 = np.gradient(d1, y, edge_order=2)
        curvature = _moving_average(np.abs(d2), SMOOTH)
        weighted_curvature = weight * curvature
        combined_curvature += weighted_curvature
        max_terms.append(weighted_curvature)

    if mode == "sqrt_sum":
        monitor = np.sqrt(combined_curvature)
    elif mode == "max_channel":
        monitor = np.sqrt(np.maximum.reduce(max_terms)) if max_terms else np.zeros_like(y)
    else:
        raise ValueError(f"unknown monitor mode: {mode}")
    return _density_and_cumulative(y, monitor, floor=floor)


def _place_from_cumulative(
    probe: dict[str, np.ndarray],
    cumulative: np.ndarray,
    pins: Iterable[float],
    *,
    n_sections: int = N_BUDGET,
) -> np.ndarray:
    targets = np.linspace(0.0, 1.0, int(n_sections))
    nodes = np.interp(targets, cumulative, np.asarray(probe["span_fraction"], dtype=float))
    nodes[0] = 0.0
    nodes[-1] = 1.0
    return _pin_and_repair_count(nodes, pins, int(n_sections))


def _build_loft(config_path: Path, sample: Any) -> tuple[Any, Any]:
    raw = load_yaml_config(config_path)
    _, gcfg = resolve_generator_and_config(raw)
    planform = generate_bwb_planform_from_sample(sample, gcfg)
    section_geometry = build_section_geometry_from_sample(planform, sample, gcfg)
    stations = tuple(
        stations_from_records(section_geometry.sections, _resolve_airfoil_database(gcfg))
    )
    frame_mode = "asb_frame" if gcfg.pygeo.frame_mode == "aeris_frame" else gcfg.pygeo.frame_mode
    build = build_pygeo(
        stations,
        k_span=gcfg.pygeo.k_span,
        frame_mode=frame_mode,
        n_ctl=gcfg.pygeo.n_ctl,
        tip=gcfg.pygeo.tip,
        tip_scale=gcfg.pygeo.tip_scale,
    )
    return build, gcfg


def _extract_at(build: Any, gcfg: Any, fractions: Iterable[float]) -> tuple[list[Any], float]:
    extracted = list(
        extract_sections(
            build,
            np.asarray(list(fractions), dtype=float),
            cst_order=gcfg.pygeo.extraction.cst_order,
            chordwise_points=gcfg.pygeo.extraction.chordwise_points,
        )
    )
    return extracted, max(float(section.y_m) for section in extracted)


def _sample_cases(config_path: Path, include_random: bool) -> list[dict[str, Any]]:
    raw = load_yaml_config(config_path)
    gid, gcfg = resolve_generator_and_config(raw)
    generator = get_geometry_generator(gid)
    base = generator.sample_one(gcfg, seed=7000)

    cases: list[dict[str, Any]] = []
    for name, overrides in CONSTRUCTED_CASES.items():
        cases.append(
            {
                "case": name,
                "kind": "constructed",
                "sample": dataclasses.replace(base, **overrides),
                "overrides": overrides,
            }
        )
    if include_random:
        for seed in RANDOM_SEEDS:
            cases.append(
                {
                    "case": f"random_{seed}",
                    "kind": "random",
                    "sample": generator.sample_one(gcfg, seed=seed),
                    "seed": seed,
                    "overrides": {},
                }
            )
    return cases


def _nodes_for_policies(
    build: Any,
    sample: Any,
    band: tuple[float, float],
) -> tuple[dict[str, np.ndarray], dict[str, np.ndarray], list[float], dict[str, np.ndarray]]:
    pins = _feature_pins_from_sample(sample)
    probe = probe_spanwise_geometry(build, n_probe=301, chordwise_probe=21)

    uniform_pinned = _pin_and_repair_count(np.linspace(0.0, 1.0, N_BUDGET), pins, N_BUDGET)

    current_weights = dict(DEFAULT_CHANNEL_WEIGHTS)
    current_weights["control_gain"] = 3.0
    current_profile = spanwise_information_profile(
        build,
        n_probe=301,
        chordwise_probe=21,
        probe=probe,
        weights=current_weights,
        control_band=band,
        floor=FLOOR,
    )
    current = adaptive_span_fractions(current_profile, N_BUDGET, must_include=pins)
    current = _pin_and_repair_count(current, pins, N_BUDGET)

    def proposed(
        *,
        mode: str = "sqrt_sum",
        control_weight: float,
        thickness_weight: float = 1.0,
    ) -> tuple[np.ndarray, np.ndarray]:
        density, cumulative = _proposed_density(
            probe,
            band,
            mode=mode,
            control_weight=control_weight,
            thickness_weight=thickness_weight,
        )
        nodes = _place_from_cumulative(probe, cumulative, pins, n_sections=N_BUDGET)
        return nodes, density

    proposed_w3, density_sqrt_w3 = proposed(control_weight=3.0)
    proposed_w1, density_sqrt_w1 = proposed(control_weight=1.0)
    proposed_w0, density_sqrt_w0 = proposed(control_weight=0.0)
    proposed_max_w3, density_max_w3 = proposed(mode="max_channel", control_weight=3.0)
    proposed_no_t, density_no_t = proposed(control_weight=3.0, thickness_weight=0.0)
    proposed_max_no_t, density_max_no_t = proposed(
        mode="max_channel", control_weight=3.0, thickness_weight=0.0
    )
    proposed_w3_gap15 = _limit_max_gap(proposed_w3, pins, N_BUDGET, max_gap_ratio=1.50)

    reference = _pin_and_repair_count(np.linspace(0.0, 1.0, REF_SECTIONS), pins, REF_SECTIONS)
    nodes_by_policy = {
        "uniform_pinned25": np.asarray(uniform_pinned, dtype=float),
        "current_sum_sqrt_w3": np.asarray(current, dtype=float),
        "proposed_sqrt_sum_w3": np.asarray(proposed_w3, dtype=float),
        "proposed_max_channel_w3": np.asarray(proposed_max_w3, dtype=float),
        "proposed_sqrt_sum_w3_no_thickness": np.asarray(proposed_no_t, dtype=float),
        "proposed_max_channel_w3_no_thickness": np.asarray(proposed_max_no_t, dtype=float),
        "proposed_sqrt_sum_w1": np.asarray(proposed_w1, dtype=float),
        "proposed_sqrt_sum_w0": np.asarray(proposed_w0, dtype=float),
        "proposed_sqrt_sum_w3_gap15": np.asarray(proposed_w3_gap15, dtype=float),
        "reference_uniform49": np.asarray(reference, dtype=float),
    }
    density_by_policy = {
        "current_sum_sqrt_w3": np.asarray(current_profile.density, dtype=float),
        "proposed_sqrt_sum_w3": density_sqrt_w3,
        "proposed_max_channel_w3": density_max_w3,
        "proposed_sqrt_sum_w3_no_thickness": density_no_t,
        "proposed_max_channel_w3_no_thickness": density_max_no_t,
        "proposed_sqrt_sum_w1": density_sqrt_w1,
        "proposed_sqrt_sum_w0": density_sqrt_w0,
    }
    return nodes_by_policy, density_by_policy, pins, probe


def _extract_metrics(result: Any) -> dict[str, Any]:
    stability = result.stability_axis_derivatives or {}
    controls = result.control_derivatives or {}
    sym = controls.get("elevon_sym", {})
    diff = controls.get("elevon_diff", {})
    return {
        "status": result.status,
        "CL": result.cl,
        "CDind": result.cd_ind,
        "CDtotal": result.cd,
        "Cm": result.cm,
        "e": result.span_efficiency,
        "Xnp": result.x_np,
        "CLa": stability.get("CLa"),
        "Cma": stability.get("Cma"),
        "Clp": stability.get("Clp"),
        "Cmq": stability.get("Cmq"),
        "Cnb": stability.get("Cnb"),
        "CL_de": sym.get("CL"),
        "Cm_de": sym.get("Cm"),
        "Cl_da": diff.get("Cl"),
        "Cn_da": diff.get("Cn"),
        "CY_da": diff.get("CY"),
        "n_sections": result.n_sections,
        "n_strips": result.n_strips,
        "n_vortices": result.n_vortices,
        "warnings": result.warnings,
        "artifact_paths": result.artifact_paths,
    }


def _load_cached(path: Path) -> dict[str, Any] | None:
    result_path = path / "native_avl_result.json"
    if not result_path.exists():
        return None
    try:
        data = json.loads(result_path.read_text(encoding="utf-8"))
    except Exception:
        return None

    class Box:
        pass

    box = Box()
    for key, value in data.items():
        setattr(box, key, value)
    return _extract_metrics(box)


def _run_policy(
    *,
    case_name: str,
    policy: str,
    build: Any,
    gcfg: Any,
    nodes: np.ndarray,
    control: dict[str, Any],
    out_dir: Path,
    reference: bool = False,
    reuse: bool = True,
) -> dict[str, Any]:
    policy_dir = out_dir / "runs" / case_name / policy
    if reuse:
        cached = _load_cached(policy_dir)
        if cached is not None:
            return cached

    extracted, semispan = _extract_at(build, gcfg, nodes)
    section_map, polar_store = build_realized_section_polar_bridge(
        extracted,
        semispan_m=semispan,
        mach=0.0,
    )
    fc = FlightCondition(
        alpha_deg=ALPHA_DEG,
        beta_deg=BETA_DEG,
        velocity_mps=VELOCITY_MPS,
        altitude_m=ALTITUDE_M,
    )
    result = run_native_avl_case(
        sorted(extracted, key=lambda s: float(s.y_m)),
        flight_condition=fc,
        output_dir=policy_dir,
        section_map=section_map,
        polar_store=polar_store,
        control=control,
        control_input_deg=ELEVON_DEG,
        diff_input_deg=DIFF_DEG,
        nchordwise=NCHORDWISE,
        spanwise_panels_per_section=(
            REF_SPANWISE_PER_INTERVAL if reference else SPANWISE_PER_INTERVAL
        ),
        name=f"{case_name}_{policy}",
    )
    return _extract_metrics(result)


def _relative_errors(candidate: dict[str, Any], reference: dict[str, Any]) -> dict[str, float]:
    errors: dict[str, float] = {}
    for key in TRACK:
        a = candidate.get(key)
        b = reference.get(key)
        if a is None or b is None:
            continue
        try:
            af = float(a)
            bf = float(b)
        except Exception:
            continue
        denom = max(abs(af), abs(bf), 1e-9)
        # Skip derivatives that are physically zero for this control family.
        if max(abs(af), abs(bf)) < 1e-8:
            continue
        errors[key] = abs(af - bf) / denom
    return errors


def _placement_metrics(nodes: np.ndarray, band: tuple[float, float]) -> dict[str, Any]:
    gaps = np.diff(np.asarray(nodes, dtype=float))
    return {
        "n_sections": int(len(nodes)),
        "ramp_fraction": float(ramp_fraction(nodes, band)),
        "max_gap": float(np.max(gaps)),
        "max_gap_ratio": float(np.max(gaps) / (1.0 / (N_BUDGET - 1))),
        "min_gap": float(np.min(gaps)),
        "sections_in_band": int(np.sum((nodes >= band[0] - 1e-9) & (nodes <= band[1] + 1e-9))),
        "nodes": [float(x) for x in nodes],
    }


def _summarize(rows: list[dict[str, Any]]) -> dict[str, Any]:
    policies = sorted({row["policy"] for row in rows})
    out: dict[str, Any] = {}
    for policy in policies:
        selected = [row for row in rows if row["policy"] == policy]
        all_errors = [
            float(row[f"err_{key}"])
            for row in selected
            for key in TRACK
            if row.get(f"err_{key}") not in (None, "")
        ]
        control_errors = [
            float(row[f"err_{key}"])
            for row in selected
            for key in CONTROL_TRACK
            if row.get(f"err_{key}") not in (None, "")
        ]
        clde_errors = [
            float(row["err_CL_de"]) for row in selected if row.get("err_CL_de") not in (None, "")
        ]
        out[policy] = {
            "n_cases": len(selected),
            "mean_all_error": float(np.mean(all_errors)) if all_errors else None,
            "max_all_error": float(np.max(all_errors)) if all_errors else None,
            "mean_control_error": float(np.mean(control_errors)) if control_errors else None,
            "max_control_error": float(np.max(control_errors)) if control_errors else None,
            "mean_cl_de_error": float(np.mean(clde_errors)) if clde_errors else None,
            "max_cl_de_error": float(np.max(clde_errors)) if clde_errors else None,
            "mean_ramp_fraction": float(np.mean([row["ramp_fraction"] for row in selected])),
            "max_ramp_fraction": float(np.max([row["ramp_fraction"] for row in selected])),
            "mean_max_gap_ratio": float(np.mean([row["max_gap_ratio"] for row in selected])),
            "max_max_gap_ratio": float(np.max([row["max_gap_ratio"] for row in selected])),
            "mean_sections": float(np.mean([row["placement_n_sections"] for row in selected])),
        }

    # Per-case winners for CL_de and worst-control error.
    for metric, out_key in (("err_CL_de", "cl_de_wins"), ("worst_control_error", "control_wins")):
        wins = {policy: 0 for policy in policies}
        for case in sorted({row["case"] for row in rows}):
            case_rows = [
                row for row in rows if row["case"] == case and row.get(metric) not in (None, "")
            ]
            if not case_rows:
                continue
            best = min(case_rows, key=lambda row: float(row[metric]))
            wins[best["policy"]] += 1
        for policy in policies:
            out[policy][out_key] = wins[policy]
    return out


def _plot_summary(out_dir: Path, summary: dict[str, Any], rows: list[dict[str, Any]]) -> None:
    policies = sorted(summary.keys())
    labels = [
        p.replace("proposed_sqrt_sum_", "prop_").replace("current_sum_sqrt_", "cur_")
        for p in policies
    ]

    fig, ax = plt.subplots(figsize=(11, 5), constrained_layout=True)
    values = [100.0 * float(summary[p]["max_control_error"]) for p in policies]
    ax.bar(labels, values, color="#4c78a8")
    ax.set_ylabel("max control-derivative error vs reference [%]")
    ax.set_title("Worst control-authority error by placement policy")
    ax.tick_params(axis="x", rotation=25)
    ax.grid(True, axis="y", alpha=0.25)
    fig.savefig(out_dir / "policy_worst_control_error.png", dpi=180)
    plt.close(fig)

    cases = sorted({row["case"] for row in rows})
    fig, ax = plt.subplots(figsize=(12, 6), constrained_layout=True)
    x = np.arange(len(cases))
    width = 0.8 / len(policies)
    for i, policy in enumerate(policies):
        vals = []
        for case in cases:
            row = next(r for r in rows if r["case"] == case and r["policy"] == policy)
            vals.append(100.0 * float(row.get("err_CL_de") or 0.0))
        ax.bar(x + (i - len(policies) / 2) * width + width / 2, vals, width, label=policy)
    ax.set_xticks(x)
    ax.set_xticklabels(cases, rotation=25, ha="right")
    ax.set_ylabel("CL_de error vs reference [%]")
    ax.set_title("Elevon lift-derivative error by case")
    ax.grid(True, axis="y", alpha=0.25)
    ax.legend(fontsize=7, ncol=2)
    fig.savefig(out_dir / "case_cl_de_error.png", dpi=180)
    plt.close(fig)


def _plot_case_complexity(
    out_dir: Path,
    *,
    case_name: str,
    probe: dict[str, np.ndarray],
    band: tuple[float, float],
    pins: Iterable[float],
    density_by_policy: dict[str, np.ndarray],
    nodes_by_policy: dict[str, np.ndarray],
) -> list[dict[str, Any]]:
    complexity_dir = out_dir / "complexity"
    complexity_dir.mkdir(parents=True, exist_ok=True)
    span = np.asarray(probe["span_fraction"], dtype=float)
    y = np.asarray(probe["y_m"], dtype=float)
    span_len = float(y[-1] - y[0])

    fig, (ax, ax_nodes) = plt.subplots(
        2,
        1,
        figsize=(11, 5.8),
        sharex=True,
        gridspec_kw={"height_ratios": [3.5, 1.0]},
        constrained_layout=True,
    )
    ax.axvspan(band[0], band[1], color="#f2c94c", alpha=0.20, label="elevon band")
    for pin in pins:
        ax.axvline(float(pin), color="#4d4d4d", lw=0.7, alpha=0.25)

    colors = {
        "current_sum_sqrt_w3": "#4c78a8",
        "proposed_sqrt_sum_w3": "#f58518",
        "proposed_max_channel_w3": "#54a24b",
        "proposed_sqrt_sum_w3_no_thickness": "#b279a2",
    }
    rows: list[dict[str, Any]] = []
    for policy in COMPLEXITY_PLOT_POLICIES:
        density = density_by_policy.get(policy)
        if density is None:
            continue
        relative = np.asarray(density, dtype=float) * span_len
        peak_idx = int(np.argmax(relative))
        ax.plot(
            span,
            relative,
            lw=1.8,
            color=colors.get(policy),
            label=policy,
        )
        rows.append(
            {
                "case": case_name,
                "policy": policy,
                "peak_complexity_to_average": float(np.max(relative)),
                "peak_span_fraction": float(span[peak_idx]),
                "mean_complexity_to_average": float(np.mean(relative)),
            }
        )

    ax.axhline(1.0, color="#111111", lw=0.8, alpha=0.35)
    ax.set_ylabel("relative aero-geometry complexity")
    ax.set_title(f"{case_name}: spanwise complexity monitor")
    ax.text(
        0.01,
        0.98,
        "1 = average; higher = needs closer AVL sections",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=8,
        color="#333333",
    )
    ax.grid(True, alpha=0.25)
    ax.legend(fontsize=7, ncol=2, loc="upper right")

    tick_policies = [
        "uniform_pinned25",
        "proposed_sqrt_sum_w3",
        "proposed_max_channel_w3",
        "proposed_sqrt_sum_w3_no_thickness",
    ]
    ax_nodes.axvspan(band[0], band[1], color="#f2c94c", alpha=0.20)
    y_positions = np.arange(len(tick_policies))[::-1]
    for y_pos, policy in zip(y_positions, tick_policies, strict=True):
        nodes = nodes_by_policy.get(policy)
        if nodes is None:
            continue
        ax_nodes.vlines(
            nodes, y_pos - 0.30, y_pos + 0.30, color=colors.get(policy, "#333333"), lw=1.2
        )
    ax_nodes.set_yticks(y_positions)
    ax_nodes.set_yticklabels(tick_policies, fontsize=8)
    ax_nodes.set_xlabel("span fraction, root to tip")
    ax_nodes.set_xlim(0.0, 1.0)
    ax_nodes.set_ylim(-0.8, len(tick_policies) - 0.2)
    ax_nodes.grid(True, axis="x", alpha=0.2)
    fig.savefig(complexity_dir / f"{case_name}_complexity.png", dpi=180)
    plt.close(fig)
    return rows


def _write_complexity_table(out_dir: Path, rows: list[dict[str, Any]]) -> None:
    fields = [
        "case",
        "policy",
        "peak_complexity_to_average",
        "peak_span_fraction",
        "mean_complexity_to_average",
    ]
    with (out_dir / "case_complexity_metrics.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field) for field in fields})


def _write_tables(out_dir: Path, rows: list[dict[str, Any]], summary: dict[str, Any]) -> None:
    fields = [
        "case",
        "kind",
        "policy",
        "placement_n_sections",
        "ramp_fraction",
        "max_gap_ratio",
        "sections_in_band",
        "solver_n_strips",
        "solver_n_vortices",
        "worst_all_error",
        "worst_control_error",
    ]
    fields += [f"err_{key}" for key in TRACK]
    with (out_dir / "case_policy_errors.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field) for field in fields})

    summary_fields = [
        "policy",
        "n_cases",
        "mean_all_error",
        "max_all_error",
        "mean_control_error",
        "max_control_error",
        "mean_cl_de_error",
        "max_cl_de_error",
        "mean_ramp_fraction",
        "max_ramp_fraction",
        "mean_max_gap_ratio",
        "max_max_gap_ratio",
        "mean_sections",
        "cl_de_wins",
        "control_wins",
    ]
    with (out_dir / "policy_summary.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=summary_fields)
        writer.writeheader()
        for policy, data in summary.items():
            row = {"policy": policy}
            row.update(data)
            writer.writerow(row)


def _write_markdown(out_dir: Path, summary: dict[str, Any], rows: list[dict[str, Any]]) -> None:
    ranked = sorted(
        summary.items(),
        key=lambda item: (
            float(item[1]["max_control_error"]),
            float(item[1]["max_all_error"]),
            float(item[1]["mean_control_error"]),
        ),
    )
    lines = [
        "# Curvature Monitor Aero Study",
        "",
        "Native AVL comparison against a finer 49-section reference with the same hard feature pins.",  # noqa: E501
        "",
        "This study measures AVL discretisation error only. The reference is not wind-tunnel or CFD truth.",  # noqa: E501
        "",
        "## Ranking",
        "",
        "| rank | policy | max control err | mean control err | max all err | CL_de wins | control wins |",  # noqa: E501
        "|---:|---|---:|---:|---:|---:|---:|",
    ]
    for i, (policy, data) in enumerate(ranked, start=1):
        lines.append(
            f"| {i} | `{policy}` | {100 * data['max_control_error']:.2f}% | "
            f"{100 * data['mean_control_error']:.2f}% | {100 * data['max_all_error']:.2f}% | "
            f"{data['cl_de_wins']} | {data['control_wins']} |"
        )
    winner = ranked[0][0]
    lines += [
        "",
        f"Selected by this study: **`{winner}`**.",
        "",
        "## What Was Tested",
        "",
        "- `uniform_pinned25`: 25 sections, uniform first guess, then exact hard pins.",
        "- `current_sum_sqrt_w3`: current AERIS sum-of-square-roots monitor, control weight 3.",
        "- `proposed_sqrt_sum_w3`: additive interpolation-error monitor, control weight 3.",
        "- `proposed_max_channel_w3`: worst-channel monitor, control weight 3.",
        "- `proposed_sqrt_sum_w3_no_thickness`: additive monitor with thickness dropped.",
        "- `proposed_max_channel_w3_no_thickness`: worst-channel monitor with thickness dropped.",
        "- `proposed_sqrt_sum_w1`: additive monitor, control weight 1.",
        "- `proposed_sqrt_sum_w0`: additive monitor, no control-gain channel, but edges still pinned.",  # noqa: E501
        "- `proposed_sqrt_sum_w3_gap15`: additive monitor plus a simple max-gap repair.",
        "",
        "All non-reference policies keep the same 25-section budget. Hard pins are root, tip, the two BWB planform/airfoil break stations, and the elevon start/end edges.",  # noqa: E501
        "",
        "## Complexity Plots",
        "",
        "The `complexity/` directory contains one PNG per geometry. The plotted value is relative monitor density: 1 means average spanwise difficulty; higher means the geometry/control surface needs closer AVL sections there.",  # noqa: E501
        "",
        "## Important Limits",
        "",
        "- Channel terms are made dimensionless before addition: lengths/root chord, twist/10 deg, thickness/0.1, camber/0.1, control gain/1.",  # noqa: E501
        "- Thickness is tested both on and off. AVL's vortex-lattice core is a mean-surface method, but the AERIS native path also writes CLAF/CDCL corrections from realised section polars, so thickness is not assumed irrelevant without testing.",  # noqa: E501
        "- Goal-oriented adaptation would refine directly against CL, CDi, Cm, or control derivatives. This study is cheaper: it tests monitor-function placement against those aero outputs after the fact.",  # noqa: E501
        "- All runs use one operating point: alpha 6 deg, beta 0 deg, velocity 28 m/s.",
    ]
    (out_dir / "README.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def run_study(
    *,
    config_path: Path = CONFIG,
    out_dir: Path = OUT,
    include_random: bool = True,
    reuse: bool = True,
) -> dict[str, Any]:
    out_dir.mkdir(parents=True, exist_ok=True)
    cases = _sample_cases(config_path, include_random)

    rows: list[dict[str, Any]] = []
    complexity_rows: list[dict[str, Any]] = []
    raw_cases: dict[str, Any] = {}
    policies_without_ref = [
        "uniform_pinned25",
        "current_sum_sqrt_w3",
        "proposed_sqrt_sum_w3",
        "proposed_max_channel_w3",
        "proposed_sqrt_sum_w3_no_thickness",
        "proposed_max_channel_w3_no_thickness",
        "proposed_sqrt_sum_w1",
        "proposed_sqrt_sum_w0",
        "proposed_sqrt_sum_w3_gap15",
    ]

    for case_entry in cases:
        case_name = case_entry["case"]
        sample = case_entry["sample"]
        build, gcfg = _build_loft(config_path, sample)
        band = (float(sample.elevon_start_frac), float(sample.elevon_end_frac))
        control = {
            "name": "elevon",
            "hinge_point": float(sample.elevon_hinge_frac),
            "symmetric": True,
            "start_frac": band[0],
            "end_frac": band[1],
        }
        nodes_by_policy, density_by_policy, pins, probe = _nodes_for_policies(build, sample, band)
        complexity_rows.extend(
            _plot_case_complexity(
                out_dir,
                case_name=case_name,
                probe=probe,
                band=band,
                pins=pins,
                density_by_policy=density_by_policy,
                nodes_by_policy=nodes_by_policy,
            )
        )

        print(
            f"[case] {case_name}: band={band[0]:.3f}-{band[1]:.3f} "
            f"pins={','.join(f'{p:.3f}' for p in pins)}"
        )
        reference = _run_policy(
            case_name=case_name,
            policy="reference_uniform49",
            build=build,
            gcfg=gcfg,
            nodes=nodes_by_policy["reference_uniform49"],
            control=control,
            out_dir=out_dir,
            reference=True,
            reuse=reuse,
        )

        raw_cases[case_name] = {
            "kind": case_entry["kind"],
            "sample": asdict(sample),
            "band": band,
            "feature_pins": pins,
            "control": control,
            "reference": reference,
            "policies": {},
        }

        for policy in policies_without_ref:
            metrics = _run_policy(
                case_name=case_name,
                policy=policy,
                build=build,
                gcfg=gcfg,
                nodes=nodes_by_policy[policy],
                control=control,
                out_dir=out_dir,
                reference=False,
                reuse=reuse,
            )
            placement = _placement_metrics(nodes_by_policy[policy], band)
            errors = _relative_errors(metrics, reference)
            worst_all = max(errors.values()) if errors else None
            control_values = [errors[k] for k in CONTROL_TRACK if k in errors]
            worst_control = max(control_values) if control_values else None
            row = {
                "case": case_name,
                "kind": case_entry["kind"],
                "policy": policy,
                "placement_n_sections": placement["n_sections"],
                "ramp_fraction": placement["ramp_fraction"],
                "max_gap_ratio": placement["max_gap_ratio"],
                "sections_in_band": placement["sections_in_band"],
                "solver_n_strips": metrics.get("n_strips"),
                "solver_n_vortices": metrics.get("n_vortices"),
                "worst_all_error": worst_all,
                "worst_control_error": worst_control,
            }
            for key in TRACK:
                row[f"err_{key}"] = errors.get(key)
            rows.append(row)
            raw_cases[case_name]["policies"][policy] = {
                "placement": placement,
                "metrics": metrics,
                "errors": errors,
                "worst_all_error": worst_all,
                "worst_control_error": worst_control,
            }
            print(
                f"  {policy:<38} CL_de={100 * errors.get('CL_de', float('nan')):6.2f}% "
                f"control_worst={100 * (worst_control or float('nan')):6.2f}% "
                f"all_worst={100 * (worst_all or float('nan')):6.2f}%"
            )

    summary = _summarize(rows)
    report = {
        "config": str(config_path),
        "settings": {
            "alpha_deg": ALPHA_DEG,
            "beta_deg": BETA_DEG,
            "velocity_mps": VELOCITY_MPS,
            "elevon_deg": ELEVON_DEG,
            "diff_deg": DIFF_DEG,
            "n_budget": N_BUDGET,
            "nchordwise": NCHORDWISE,
            "spanwise_per_interval": SPANWISE_PER_INTERVAL,
            "ref_sections": REF_SECTIONS,
            "ref_spanwise_per_interval": REF_SPANWISE_PER_INTERVAL,
            "floor": FLOOR,
            "channel_reference_scales": CHANNEL_REFERENCE_SCALES,
        },
        "summary": summary,
        "cases": raw_cases,
        "complexity_rows": complexity_rows,
    }
    (out_dir / "aero_study_report.json").write_text(
        json.dumps(report, indent=2, default=str),
        encoding="utf-8",
    )
    _write_tables(out_dir, rows, summary)
    _write_complexity_table(out_dir, complexity_rows)
    _plot_summary(out_dir, summary, rows)
    _write_markdown(out_dir, summary, rows)
    return report


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=CONFIG)
    parser.add_argument("--out-dir", type=Path, default=OUT)
    parser.add_argument("--constructed-only", action="store_true")
    parser.add_argument("--no-reuse", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    report = run_study(
        config_path=args.config,
        out_dir=args.out_dir,
        include_random=not args.constructed_only,
        reuse=not args.no_reuse,
    )
    ranked = sorted(
        report["summary"].items(),
        key=lambda item: (
            float(item[1]["max_control_error"]),
            float(item[1]["max_all_error"]),
            float(item[1]["mean_control_error"]),
        ),
    )
    print("\nFinal ranking:")
    for i, (policy, data) in enumerate(ranked, start=1):
        print(
            f"{i}. {policy:<28} "
            f"max_control={100 * data['max_control_error']:.2f}% "
            f"mean_control={100 * data['mean_control_error']:.2f}% "
            f"max_all={100 * data['max_all_error']:.2f}%"
        )
    print(f"\nArtifacts: {args.out_dir}")


if __name__ == "__main__":
    main()
