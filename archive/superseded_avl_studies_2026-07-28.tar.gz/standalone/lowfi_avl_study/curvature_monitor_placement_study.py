"""Geometry-only pilot study for curvature-based AVL section placement.

This compares:

1. The current production monitor:
       rho = sum_k w_k * sqrt(abs(g_k''))

2. A mathematically cleaner proposed monitor:
       rho = sqrt(sum_k w_k * abs(g_k''))

No AVL is run here. The outputs only describe section placement geometry:
section count, spacing, ramp fraction, and how many sections land inside the
elevon span. Aerodynamic error still requires a follow-up AVL convergence run.
"""

from __future__ import annotations

import argparse
import csv
import json
from dataclasses import asdict
from pathlib import Path
from typing import Any, Iterable

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np

from aeris.common.config import load_yaml_config
from aeris.generators.bwb_segmented_v1.pygeo_adapter import (
    build_pygeo,
    stations_from_records,
)
from aeris.generators.bwb_segmented_v1.pygeo_backend import _resolve_airfoil_database
from aeris.generators.bwb_segmented_v1.services import (
    build_section_geometry_from_sample,
    generate_bwb_planform_from_sample,
)
from aeris.geometry.config_resolver import resolve_generator_and_config
from aeris.geometry.geometric_information import (
    DEFAULT_CHANNEL_WEIGHTS,
    adaptive_span_fractions,
    probe_spanwise_geometry,
    ramp_fraction,
    spanwise_information_profile,
)
from aeris.geometry.registry import get_geometry_generator

REPO = Path(__file__).resolve().parents[2]
DEFAULT_CONFIG = REPO / "configs/geometry/bwb.yaml"
DEFAULT_OUT = REPO / "artifacts/curvature_monitor_placement_study"
N_SECTIONS = 25
RAMP_LIMIT = 0.15
FLOOR = 0.50
CONTROL_EDGE_SMOOTHING = 0.02
SMOOTH = 9


CHANNEL_REFERENCE_SCALES: dict[str, str | float] = {
    "x_le": "root_chord",
    "z_le": "root_chord",
    "chord": "root_chord",
    "twist": 10.0,
    "thickness": 0.1,
    "camber": 0.1,
    "control_gain": 1.0,
}


def _moving_average(values: np.ndarray, width: int) -> np.ndarray:
    if width <= 1:
        return values
    k = int(width) | 1
    kernel = np.ones(k) / float(k)
    return np.convolve(np.pad(values, k // 2, mode="edge"), kernel, mode="valid")


def _control_gain(span_fraction: np.ndarray, band: tuple[float, float]) -> np.ndarray:
    lo, hi = float(band[0]), float(band[1])
    w = max(CONTROL_EDGE_SMOOTHING, 1e-4)
    return 0.5 * (
        np.tanh((span_fraction - lo) / w) - np.tanh((span_fraction - hi) / w)
    )


def _strict_unique(values: Iterable[float], *, tol: float = 1e-4) -> list[float]:
    out: list[float] = []
    for value in sorted(float(v) for v in values):
        value = min(max(value, 0.0), 1.0)
        if not out or value - out[-1] >= tol:
            out.append(value)
        else:
            out[-1] = 0.5 * (out[-1] + value)
    out[0] = 0.0
    out[-1] = 1.0
    return out


def _largest_gap_insert(nodes: list[float], pins: set[float], n: int) -> list[float]:
    nodes = _strict_unique(nodes)
    while len(nodes) < n:
        gaps = [(nodes[i + 1] - nodes[i], i) for i in range(len(nodes) - 1)]
        _, idx = max(gaps, key=lambda item: item[0])
        nodes.insert(idx + 1, 0.5 * (nodes[idx] + nodes[idx + 1]))
    while len(nodes) > n:
        interior = [
            (min(nodes[i] - nodes[i - 1], nodes[i + 1] - nodes[i]), i)
            for i in range(1, len(nodes) - 1)
            if not any(abs(nodes[i] - pin) < 1e-9 for pin in pins)
        ]
        if not interior:
            break
        _, idx = min(interior, key=lambda item: item[0])
        nodes.pop(idx)
    return _strict_unique(nodes)


def _pin_features_exact(nodes: np.ndarray, pins: Iterable[float], n: int) -> np.ndarray:
    values = np.asarray(nodes, dtype=float).copy()
    pins_clean = [float(p) for p in pins if 0.0 < float(p) < 1.0]
    for pin in pins_clean:
        interior = np.arange(1, len(values) - 1)
        if interior.size == 0:
            break
        nearest = int(interior[np.argmin(np.abs(values[interior] - pin))])
        values[nearest] = pin
    pinned = {round(p, 12) for p in pins_clean}
    repaired = _largest_gap_insert(_strict_unique(values), pinned, n)
    return np.asarray(repaired, dtype=float)


def _proposed_sqrt_sum_density(
    probe: dict[str, np.ndarray],
    band: tuple[float, float],
    *,
    weights: dict[str, float] | None = None,
    floor: float = FLOOR,
    smooth: int = SMOOTH,
) -> tuple[np.ndarray, np.ndarray]:
    weights = dict(DEFAULT_CHANNEL_WEIGHTS if weights is None else weights)
    y = np.asarray(probe["y_m"], dtype=float)
    span_fraction = np.asarray(probe["span_fraction"], dtype=float)
    root_chord = float(np.asarray(probe["chord"], dtype=float)[0]) or 1.0

    sources = {
        "x_le": np.asarray(probe["x_le"], dtype=float),
        "z_le": np.asarray(probe["z_le"], dtype=float),
        "chord": np.asarray(probe["chord"], dtype=float),
        "twist": np.asarray(probe["twist_deg"], dtype=float),
        "thickness": np.asarray(probe["thickness"], dtype=float),
        "camber": np.asarray(probe["camber"], dtype=float),
        "control_gain": _control_gain(span_fraction, band),
    }

    combined_curvature = np.zeros_like(y)
    channel_integrals: dict[str, float] = {}
    for name, values in sources.items():
        weight = float(weights.get(name, 0.0))
        if weight <= 0.0:
            continue
        ref = CHANNEL_REFERENCE_SCALES.get(name, 1.0)
        scale = root_chord if ref == "root_chord" else float(ref)
        span = float(np.max(values) - np.min(values))
        if scale <= 0.0 or span <= 1e-12:
            channel_integrals[name] = 0.0
            continue
        scaled = (values - float(np.min(values))) / scale
        d1 = np.gradient(scaled, y, edge_order=2)
        d2 = np.gradient(d1, y, edge_order=2)
        curvature = _moving_average(np.abs(d2), smooth)
        combined_curvature += weight * curvature
        channel_integrals[name] = float(np.trapezoid(curvature, y))

    blended = np.sqrt(combined_curvature)
    area = float(np.trapezoid(blended, y))
    span_len = float(y[-1] - y[0])
    if area <= 1e-12 or span_len <= 1e-12:
        blended = np.ones_like(y) / max(span_len, 1e-12)
    else:
        blended = blended / area

    uniform = np.ones_like(y) / span_len
    density = (1.0 - floor) * blended + floor * uniform
    density = density / float(np.trapezoid(density, y))
    cumulative = np.concatenate(
        [[0.0], np.cumsum(0.5 * (density[1:] + density[:-1]) * np.diff(y))]
    )
    cumulative = cumulative / cumulative[-1]
    return density, cumulative


def _place_from_cumulative(
    span_fraction: np.ndarray,
    cumulative: np.ndarray,
    *,
    n_sections: int,
    pins: Iterable[float],
) -> np.ndarray:
    targets = np.linspace(0.0, 1.0, int(n_sections))
    nodes = np.interp(targets, cumulative, span_fraction)
    nodes[0] = 0.0
    nodes[-1] = 1.0
    return _pin_features_exact(nodes, pins, int(n_sections))


def _build_case(config_path: Path, seed: int) -> dict[str, Any]:
    raw = load_yaml_config(config_path)
    gid, gcfg = resolve_generator_and_config(raw)
    generator = get_geometry_generator(gid)
    sample = generator.sample_one(gcfg, seed=seed)

    planform = generate_bwb_planform_from_sample(sample, gcfg)
    section_geometry = build_section_geometry_from_sample(planform, sample, gcfg)
    stations = tuple(
        stations_from_records(section_geometry.sections, _resolve_airfoil_database(gcfg))
    )
    frame_mode = "asb_frame" if gcfg.pygeo.frame_mode == "aeris_frame" else gcfg.pygeo.frame_mode
    build = build_pygeo(
        stations,
        k_span=gcfg.pygeo.k_span,
        frame_mode=frame_mode,
        n_ctl=gcfg.pygeo.n_ctl,
        tip=gcfg.pygeo.tip,
        tip_scale=gcfg.pygeo.tip_scale,
    )

    control = {
        "start_frac": float(sample.elevon_start_frac),
        "end_frac": float(sample.elevon_end_frac),
        "hinge_point": float(sample.elevon_hinge_frac),
    }
    return {"seed": seed, "sample": asdict(sample), "build": build, "control": control}


def _policy_metrics(name: str, nodes: np.ndarray, band: tuple[float, float]) -> dict[str, Any]:
    gaps = np.diff(np.asarray(nodes, dtype=float))
    uniform_gap = 1.0 / (N_SECTIONS - 1)
    lo, hi = band
    return {
        "policy": name,
        "n_sections": int(len(nodes)),
        "ramp_fraction": float(ramp_fraction(nodes, band)),
        "max_gap": float(np.max(gaps)),
        "max_gap_ratio": float(np.max(gaps) / uniform_gap),
        "min_gap": float(np.min(gaps)),
        "sections_in_band": int(np.sum((nodes >= lo - 1e-9) & (nodes <= hi + 1e-9))),
        "nodes": [float(x) for x in nodes],
    }


def _plot_case(
    out_dir: Path,
    seed: int,
    rows: list[dict[str, Any]],
    band: tuple[float, float],
) -> None:
    fig, axes = plt.subplots(2, 1, figsize=(10, 7), constrained_layout=True)

    ax = axes[0]
    for row, y, color in zip(
        rows,
        [0.25, 0.50, 0.75],
        ["#8f8f8f", "#4c78a8", "#f28e2b"],
        strict=False,
    ):
        nodes = np.asarray(row["nodes"], dtype=float)
        ax.scatter(nodes, np.full_like(nodes, y), s=24, label=row["policy"], color=color)
    ax.axvspan(band[0], band[1], color="#f8d56b", alpha=0.25)
    ax.axvline(band[0], color="#d62728", linewidth=1.2)
    ax.axvline(band[1], color="#d62728", linewidth=1.2)
    ax.set_xlim(-0.02, 1.02)
    ax.set_ylim(0.1, 0.9)
    ax.set_yticks([])
    ax.set_title(f"Seed {seed}: section positions; yellow = elevon span")
    ax.set_xlabel("span fraction")
    ax.grid(True, axis="x", alpha=0.25)
    ax.legend(fontsize=8, loc="upper center", ncol=3)

    ax = axes[1]
    for row, color in zip(rows, ["#8f8f8f", "#4c78a8", "#f28e2b"], strict=False):
        nodes = np.asarray(row["nodes"], dtype=float)
        grid = np.linspace(0.0, 1.0, 500)
        node_gain = np.where((nodes >= band[0] - 1e-9) & (nodes <= band[1] + 1e-9), 1.0, 0.0)
        gain = np.interp(grid, nodes, node_gain)
        ax.plot(
            grid,
            gain,
            color=color,
            linewidth=2,
            label=f"{row['policy']} ({100 * row['ramp_fraction']:.1f}%)",
        )
    ideal = np.where((grid >= band[0]) & (grid <= band[1]), 1.0, 0.0)
    ax.plot(grid, ideal, color="black", linestyle="--", linewidth=1.4, label="ideal")
    ax.axvspan(band[0], band[1], color="#f8d56b", alpha=0.15)
    ax.set_ylim(-0.08, 1.15)
    ax.set_title("Control gain seen by AVL between section cuts")
    ax.set_xlabel("span fraction")
    ax.set_ylabel("gain")
    ax.grid(True, alpha=0.25)
    ax.legend(fontsize=8)

    fig.savefig(out_dir / f"seed_{seed}_placement_policies.png", dpi=180)
    plt.close(fig)


def run_study(config_path: Path, out_dir: Path, seeds: list[int]) -> dict[str, Any]:
    out_dir.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, Any]] = []
    case_summaries: list[dict[str, Any]] = []

    for seed in seeds:
        case = _build_case(config_path, seed)
        control = case["control"]
        band = (float(control["start_frac"]), float(control["end_frac"]))
        pins = [band[0], band[1]]

        uniform = np.linspace(0.0, 1.0, N_SECTIONS)
        uniform_edges = np.unique(np.concatenate([uniform, np.asarray(pins)]))

        probe = probe_spanwise_geometry(case["build"], n_probe=301, chordwise_probe=21)
        current_profile = spanwise_information_profile(
            case["build"],
            n_probe=301,
            chordwise_probe=21,
            probe=probe,
            control_band=band,
            floor=FLOOR,
        )
        current = adaptive_span_fractions(current_profile, N_SECTIONS, must_include=pins)
        proposed_density, proposed_cumulative = _proposed_sqrt_sum_density(probe, band)
        proposed = _place_from_cumulative(
            np.asarray(probe["span_fraction"], dtype=float),
            proposed_cumulative,
            n_sections=N_SECTIONS,
            pins=pins,
        )

        policy_rows = [
            _policy_metrics("uniform_plus_edges", uniform_edges, band),
            _policy_metrics("current_sum_sqrt", current, band),
            _policy_metrics("proposed_sqrt_sum", proposed, band),
        ]
        for row in policy_rows:
            row.update(
                {
                    "seed": seed,
                    "elevon_start": band[0],
                    "elevon_end": band[1],
                    "elevon_width": band[1] - band[0],
                    "hinge": float(control["hinge_point"]),
                }
            )
            rows.append(row)
        _plot_case(out_dir, seed, policy_rows, band)
        case_summaries.append(
            {
                "seed": seed,
                "elevon": control,
                "uniform_ramp_fraction": policy_rows[0]["ramp_fraction"],
                "current_ramp_fraction": policy_rows[1]["ramp_fraction"],
                "proposed_ramp_fraction": policy_rows[2]["ramp_fraction"],
            }
        )

    csv_path = out_dir / "placement_policy_summary.csv"
    fieldnames = [
        "seed",
        "policy",
        "n_sections",
        "elevon_start",
        "elevon_end",
        "elevon_width",
        "hinge",
        "ramp_fraction",
        "max_gap",
        "max_gap_ratio",
        "min_gap",
        "sections_in_band",
        "nodes",
    ]
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    key: json.dumps(row[key]) if key == "nodes" else row[key]
                    for key in fieldnames
                }
            )

    aggregate: dict[str, Any] = {}
    for policy in sorted({row["policy"] for row in rows}):
        selected = [row for row in rows if row["policy"] == policy]
        aggregate[policy] = {
            "mean_ramp_fraction": float(np.mean([r["ramp_fraction"] for r in selected])),
            "max_ramp_fraction": float(np.max([r["ramp_fraction"] for r in selected])),
            "mean_max_gap_ratio": float(np.mean([r["max_gap_ratio"] for r in selected])),
            "max_max_gap_ratio": float(np.max([r["max_gap_ratio"] for r in selected])),
            "mean_sections": float(np.mean([r["n_sections"] for r in selected])),
            "min_sections": int(np.min([r["n_sections"] for r in selected])),
            "max_sections": int(np.max([r["n_sections"] for r in selected])),
        }

    report = {
        "config": str(config_path),
        "seeds": seeds,
        "n_sections_nominal": N_SECTIONS,
        "ramp_limit": RAMP_LIMIT,
        "floor": FLOOR,
        "policies": {
            "uniform_plus_edges": "25 uniform fractions plus exact elevon start/end pins.",
            "current_sum_sqrt": (
                "Current AERIS monitor: sum_k w_k * sqrt(abs(g_k'')); "
                "exact count not guaranteed by production helper."
            ),
            "proposed_sqrt_sum": (
                "Pilot monitor: sqrt(sum_k w_k * abs(g_k'')) with exact-count repair."
            ),
        },
        "aggregate": aggregate,
        "cases": case_summaries,
        "limits": [
            "Geometry-only: no AVL coefficients and no aerodynamic error percentages.",
            "Random seeds are not a substitute for constructed corner cases.",
            "The proposed metric is not production behavior.",
        ],
    }
    (out_dir / "placement_policy_summary.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )

    md = [
        "# Curvature Monitor Placement Pilot",
        "",
        "This is a geometry-only comparison. No AVL solve is run here.",
        "",
        "| policy | mean ramp | max ramp | mean max-gap ratio | section count range |",
        "|---|---:|---:|---:|---:|",
    ]
    for policy, agg in aggregate.items():
        md.append(
            f"| {policy} | {100*agg['mean_ramp_fraction']:.1f}% | "
            f"{100*agg['max_ramp_fraction']:.1f}% | "
            f"{agg['mean_max_gap_ratio']:.2f}x | "
            f"{agg['min_sections']}-{agg['max_sections']} |"
        )
    md += [
        "",
        "The proposed metric is cleaner mathematically, but this pilot only shows",
        "that it produces plausible section distributions. It does not prove lower",
        "aerodynamic error until an AVL convergence check is run.",
    ]
    (out_dir / "README.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    return report


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT)
    parser.add_argument(
        "--seeds",
        default="1001,1002,1010,1020,1030,1040,1050,1060,1070,1080,1090,1100",
        help="Comma-separated deterministic sample seeds.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    seeds = [int(item.strip()) for item in str(args.seeds).split(",") if item.strip()]
    report = run_study(args.config, args.out_dir, seeds)
    print(json.dumps(report["aggregate"], indent=2))
    print(args.out_dir)


if __name__ == "__main__":
    main()
