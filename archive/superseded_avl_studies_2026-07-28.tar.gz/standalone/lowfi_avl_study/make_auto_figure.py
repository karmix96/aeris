"""One figure that answers: what does section_placement: auto actually DO?"""
from pathlib import Path
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np

FIGS = Path(__file__).resolve().parents[2] / "studies/figures/placement_decision"

GREY, GREEN, RED, BLUE = "#8a8f98", "#1f6f4a", "#c0392b", "#1f4e79"


def box(ax, x, y, w, h, text, fc, ec, fs=8.6, weight="normal"):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.012",
                                fc=fc, ec=ec, lw=1.5, zorder=2))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center",
            fontsize=fs, weight=weight, zorder=3, linespacing=1.45)


def arrow(ax, x1, y1, x2, y2, label="", col="#444", off=0.012):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>",
                                 mutation_scale=13, lw=1.4, color=col, zorder=1))
    if label:
        ax.text((x1 + x2) / 2, (y1 + y2) / 2 + off, label, fontsize=8,
                color=col, ha="center", va="bottom", weight="bold")


def main():
    fig = plt.figure(figsize=(12.6, 7.4))
    gs = fig.add_gridspec(2, 2, height_ratios=[1.32, 1.0], hspace=0.30,
                          wspace=0.20)

    # ---------- the decision flow -------------------------------------
    ax = fig.add_subplot(gs[0, :]); ax.axis("off")
    ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    ax.set_title('What "section_placement: auto" actually does, step by step',
                 fontsize=12, weight="bold", pad=8)

    box(ax, .015, .60, .175, .30,
        "1. Lay down\nEVEN spacing\n(25 − pins)", "#eef2f7", BLUE)
    box(ax, .215, .60, .175, .30,
        "2. INSERT the\nhard feature pins\n(kinks + elevon ends)", "#eef2f7", BLUE)
    box(ax, .415, .585, .195, .33,
        "3. Measure the\nGAIN RAMP\nof that grid", "#fff6e8", "#c07a2c")
    box(ax, .645, .60, .155, .30,
        "ramp ≤ 15% ?", "#ffffff", "#444", weight="bold")

    box(ax, .828, .80, .165, .17,
        "STOP — ship it.\nIdentical to 'never'.", "#e9f5ee", GREEN, weight="bold")
    box(ax, .825, .49, .165, .22,
        "Re-space by the\ninformation metric,\nkeeping every pin", "#fdeceb", RED)
    box(ax, .645, .12, .345, .20,
        "Accept the new spacing ONLY if it actually lowers the ramp.\n"
        "Otherwise keep the even grid. Then top the count back to 25\n"
        "by bisecting the largest remaining gap.", "#fdeceb", RED, fs=8.2)

    arrow(ax, .190, .75, .215, .75)
    arrow(ax, .390, .75, .415, .75)
    arrow(ax, .610, .75, .645, .75)
    arrow(ax, .800, .80, .825, .87, "YES", GREEN)
    arrow(ax, .800, .70, .825, .60, "", RED)
    ax.text(.812, .655, "NO", fontsize=8, color=RED, ha="center",
            va="top", weight="bold")
    arrow(ax, .905, .49, .905, .32, "", RED)

    ax.text(.5, .045,
            'So "auto" is not a third kind of spacing. It is EVEN spacing with pins, '
            'plus one test:\nredistribute only when the control surface would '
            'otherwise be badly smeared.',
            ha="center", va="center", fontsize=9.6, style="italic")

    # ---------- worked example: gate CLOSED ---------------------------
    for k, (ttl, ramp, adapt, col, note) in enumerate((
            ("nominal geometry — gate stays CLOSED",
             7.6, None, GREEN,
             "ramp 7.6% ≤ 15%  →  even spacing kept.\n"
             "Result is byte-identical to 'never'.\n"
             "This is what happens on 5 of the 10 geometries tested."),
            ("narrow elevon (band 0.70–0.85) — gate OPENS",
             66.7, 13.0, RED,
             "ramp 66.7% > 15%  →  re-spaced by the metric.\n"
             "Ramp falls 66.7% → 13.0%; worst control error\n"
             "1.52% → 1.12%."))):
        ax = fig.add_subplot(gs[1, k])
        vals = [ramp] + ([adapt] if adapt is not None else [])
        labels = ["even + pins"] + (["after metric"] if adapt is not None else [])
        cols = [GREY] + ([col] if adapt is not None else [])
        b = ax.bar(labels, vals, color=cols, width=.5)
        for bb, v in zip(b, vals):
            ax.text(bb.get_x() + bb.get_width() / 2, v + 2, f"{v:.1f}%",
                    ha="center", fontsize=10, weight="bold")
        ax.axhline(15, color="#c0392b", ls="--", lw=1.4)
        ax.text(0.02, 17, "gate = 15%", transform=ax.get_yaxis_transform(),
                fontsize=8.4, color="#c0392b", va="bottom")
        ax.set_ylim(0, 78); ax.set_ylabel("gain ramp / band width  [%]", fontsize=9)
        ax.set_title(ttl, fontsize=10, weight="bold")
        ax.tick_params(labelsize=9); ax.grid(axis="y", alpha=.25, lw=.6)
        for s in ("top", "right"): ax.spines[s].set_visible(False)
        ax.text(.5, -.30, note, transform=ax.transAxes, ha="center", va="top",
                fontsize=8.6, linespacing=1.5)

    fig.subplots_adjust(bottom=0.17)
    fig.savefig(FIGS / "09_what_auto_means.png", dpi=150, bbox_inches="tight")
    print("wrote", FIGS / "09_what_auto_means.png")


if __name__ == "__main__":
    main()
