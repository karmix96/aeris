"""Figures for the DSE-vs-verification panelling decision (DECISION-0013)."""
from pathlib import Path
import json
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

REPO = Path(__file__).resolve().parents[2]
FIGS = REPO / "studies" / "figures" / "dse_panelling"
EV = REPO / "configs" / "aero" / "dse_panelling_evidence"

NCH   = np.array([4, 6, 8, 12, 16, 24])
NV    = np.array([768, 1152, 1536, 2304, 3072, 4608])
TIME  = np.array([1.8, 3.7, 6.9, 14.6, 25.4, 57.3])
WORST = np.array([15.94, 10.22, 7.41, 3.76, 1.79, 0.62])
CL    = np.array([2.02, 1.58, 1.07, 0.51, 0.23, 0.12])
CM    = np.array([1.12, 1.91, 1.47, 0.67, 0.33, 0.12])
XNP   = np.array([0.12, 0.00, 0.00, 0.00, 0.00, 0.00])
STAGE = {"pyGeo loft + extract": 1.36, "NeuralFoil viscous": 0.60, "AVL solve": 56.93}
DSE, VERIF = 12, 24


def _s(ax, t, xl, yl):
    ax.set_title(t, fontsize=10.5, weight="bold")
    ax.set_xlabel(xl, fontsize=9); ax.set_ylabel(yl, fontsize=9)
    ax.grid(alpha=.25, lw=.6); ax.tick_params(labelsize=8)
    for k in ("top", "right"): ax.spines[k].set_visible(False)


def fig_tradeoff():
    fig, ax = plt.subplots(figsize=(7.6, 5.0))
    ax.plot(TIME, WORST, "-o", color="#1f4e79", lw=1.6, ms=6, zorder=3)
    for t, w, n in zip(TIME, WORST, NCH):
        ax.annotate(f"{n}", (t, w), textcoords="offset points", xytext=(7, 6),
                    fontsize=9, weight="bold", color="#1f4e79")
    for n, c, lab in ((DSE, "#1f6f4a", "DSE tier"), (VERIF, "#c0392b", "verification")):
        i = int(np.where(NCH == n)[0][0])
        ax.scatter([TIME[i]], [WORST[i]], s=230, facecolor="none",
                   edgecolor=c, lw=2.2, zorder=4)
        ax.annotate(lab, (TIME[i], WORST[i]), textcoords="offset points",
                    xytext=(12, -16), fontsize=9, weight="bold", color=c)
    ax.set_xscale("log"); ax.set_yscale("log")
    _s(ax, "Cost vs accuracy — labels are chordwise panel counts",
       "seconds per design point  (log)", "worst error vs 30-panel reference  [%]  (log)")
    fig.tight_layout(); fig.savefig(FIGS / "01_cost_accuracy_tradeoff.png", dpi=150)
    plt.close(fig)


def fig_scaling():
    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    ax.plot(NV, TIME, "-o", color="#1f4e79", lw=1.6, ms=6, label="measured")
    ref = TIME[0] * (NV / NV[0]) ** 3
    ax.plot(NV, ref, "--", color="#999", lw=1.3, label="pure $N^3$ (LU)")
    ax.plot(NV, TIME[0] * (NV / NV[0]) ** 2, ":", color="#bbb", lw=1.3,
            label="pure $N^2$ (matrix build)")
    ax.axvline(6000, color="#c0392b", lw=1.4)
    ax.text(6100, TIME[1], "AVL array limit\n~6000 vortices", fontsize=8,
            color="#c0392b", va="bottom")
    ax.axvline(4608, color="#c07a2c", ls="--", lw=1.2)
    ax.text(4650, TIME[0]*1.4, "old default\n(77% of limit)", fontsize=8, color="#c07a2c")
    ax.set_xscale("log"); ax.set_yscale("log"); ax.legend(fontsize=8, frameon=False)
    _s(ax, "Why AVL is slow here: dense-matrix scaling, run near the ceiling",
       "vortices  (log)", "solve time  [s]  (log)")
    fig.tight_layout(); fig.savefig(FIGS / "02_vortex_scaling.png", dpi=150)
    plt.close(fig)


def fig_stage():
    fig, ax = plt.subplots(figsize=(7.2, 2.5))
    left = 0.0
    cols = {"pyGeo loft + extract": "#6b8fb5", "NeuralFoil viscous": "#8fbf7f",
            "AVL solve": "#c0392b"}
    for k, v in STAGE.items():
        ax.barh([0], [v], left=left, color=cols[k], label=f"{k}  ({v:.2f} s)")
        left += v
    ax.set_yticks([]); ax.set_xlim(0, left * 1.02)
    ax.legend(fontsize=8.5, frameon=False, ncol=1, loc="center left",
              bbox_to_anchor=(1.01, 0.5))
    _s(ax, "Where one 58 s design point goes — the solver is the whole cost",
       "seconds", "")
    fig.tight_layout(); fig.savefig(FIGS / "03_stage_breakdown.png", dpi=150)
    plt.close(fig)


def fig_which_quantity():
    fig, ax = plt.subplots(figsize=(7.6, 4.6))
    ax.plot(NCH, WORST, "-o", color="#c0392b", lw=1.8, ms=6,
            label="$C_{L\\delta e}$ (control)")
    ax.plot(NCH, CL, "-s", color="#1f4e79", lw=1.4, ms=5, label="$C_L$")
    ax.plot(NCH, CM, "-^", color="#6b8fb5", lw=1.4, ms=5, label="$C_m$")
    ax.plot(NCH, XNP, "-d", color="#1f6f4a", lw=1.4, ms=5, label="$X_{np}$")
    ax.axvline(DSE, color="#1f6f4a", ls="--", lw=1.3)
    ax.text(DSE + .4, 8, "DSE tier = 12", fontsize=9, color="#1f6f4a", weight="bold")
    ax.set_yscale("symlog", linthresh=0.05)
    _s(ax, "Only the CONTROL derivatives need panels — everything else converges early",
       "chordwise panels", "error vs reference  [%]")
    ax.legend(fontsize=8.5, frameon=False)
    fig.tight_layout(); fig.savefig(FIGS / "04_which_quantity_needs_panels.png", dpi=150)
    plt.close(fig)


def fig_bias():
    """The claim that licenses a cheap DSE tier: bias, not scatter."""
    f = REPO / "data" / "lowfi_avl_study" / "dse_bias" / "dse_bias.json"
    if not f.exists():
        f = EV / "dse_bias.json"
    if not f.exists():
        print("  (bias json not present yet — skipping fig 05)"); return
    d = json.loads(f.read_text())
    names = list(d)
    qs = ["CL", "Cm", "CLa", "CL_de", "Cm_de"]
    fig, ax = plt.subplots(figsize=(8.4, 4.6))
    x = np.arange(len(qs)); w = 0.8 / max(1, len(names))
    for i, n in enumerate(names):
        v = [d[n]["ratio"].get(q, np.nan) for q in qs]
        ax.bar(x + i * w - 0.4 + w / 2, v, w, label=n)
    ax.axhline(1.0, color="#333", lw=1.2)
    ax.set_ylim(0.94, 1.02)
    ax.set_xticks(x); ax.set_xticklabels(qs, fontsize=9)
    _s(ax, "Bias, not scatter: every geometry is shifted by the SAME factor\n"
           "(bars level across geometries ⇒ design rankings survive)",
       "", "ratio  nchordwise 12 / 24")
    ax.legend(fontsize=7.5, frameon=False, ncol=4)
    fig.tight_layout(); fig.savefig(FIGS / "05_bias_not_scatter.png", dpi=150)
    plt.close(fig)


if __name__ == "__main__":
    FIGS.mkdir(parents=True, exist_ok=True)
    fig_tradeoff(); fig_scaling(); fig_stage(); fig_which_quantity(); fig_bias()
    print("figures ->", FIGS)
