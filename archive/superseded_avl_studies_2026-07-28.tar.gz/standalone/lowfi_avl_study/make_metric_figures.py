"""Figures that EXPLAIN the geometric-information metric, plus the audit results."""
from __future__ import annotations
import json
from pathlib import Path
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

REPO = Path(__file__).resolve().parents[2]
FIGS = REPO / "studies" / "figures" / "placement_decision"
CONFIG = REPO / "configs" / "geometry" / "bwb.yaml"


def _style(ax, t, xl, yl):
    ax.set_title(t, fontsize=10.5, weight="bold")
    ax.set_xlabel(xl, fontsize=9); ax.set_ylabel(yl, fontsize=9)
    ax.grid(alpha=.25, lw=.6); ax.tick_params(labelsize=8)
    for s in ("top", "right"): ax.spines[s].set_visible(False)


def fig_metric_explained():
    """What the monitor sees, channel by channel, and where sections land."""
    import dataclasses
    from aeris.common.config import load_yaml_config
    from aeris.geometry.config_resolver import resolve_generator_and_config
    from aeris.geometry.registry import get_geometry_generator
    from aeris.geometry.geometric_information import (
        spanwise_information_profile, adaptive_span_fractions)
    from aeris.generators.bwb_segmented_v1.pygeo_avl_adapter import (
        build_pygeo_sections_from_config)

    from aeris.generators.bwb_segmented_v1.pygeo_adapter import (
        build_pygeo, stations_from_records)
    from aeris.generators.bwb_segmented_v1.pygeo_backend import (
        _resolve_airfoil_database)
    from aeris.generators.bwb_segmented_v1.services import (
        build_section_geometry_from_sample, generate_bwb_planform_from_sample)

    gid, g = resolve_generator_and_config(load_yaml_config(CONFIG))
    base = get_geometry_generator(gid).sample_one(g, seed=7000)
    sample = dataclasses.replace(base, elevon_start_frac=0.70,
                                 elevon_end_frac=0.85)
    ex, semi, meta = build_pygeo_sections_from_config(CONFIG, sample=sample)

    # rebuild the same pyGeo loft the adapter feeds the monitor
    pf = generate_bwb_planform_from_sample(sample, g)
    sg = build_section_geometry_from_sample(pf, sample, g)
    stations = tuple(stations_from_records(sg.sections, _resolve_airfoil_database(g)))
    frame = "asb_frame" if g.pygeo.frame_mode == "aeris_frame" else g.pygeo.frame_mode
    build = build_pygeo(stations, k_span=g.pygeo.k_span, frame_mode=frame,
                        n_ctl=g.pygeo.n_ctl, tip=g.pygeo.tip,
                        tip_scale=g.pygeo.tip_scale)
    band = (float(meta["control"]["start_frac"]), float(meta["control"]["end_frac"]))
    prof = spanwise_information_profile(build, n_probe=301, chordwise_probe=21,
                                        control_band=band)

    y = np.asarray(prof.span_fraction)
    fig, axes = plt.subplots(3, 1, figsize=(9.2, 9.4), sharex=True)

    # (1) the raw shape channels
    ax = axes[0]
    for name, ch in prof.channels.items():
        v = np.asarray(ch.values, dtype=float)
        rng = np.nanmax(v) - np.nanmin(v)
        if rng < 1e-12:
            continue
        ax.plot(y, (v - np.nanmin(v)) / rng, lw=1.4, label=name)
    _style(ax, "STEP 1-2  What the monitor looks at: seven shape channels along the span\n"
               "(each shown rescaled to 0-1 here only so they fit one axis)",
           "", "channel (rescaled)")
    ax.legend(fontsize=7.5, ncol=4, frameon=False)

    # (2) the density = sqrt(|curvature|), worst channel
    ax = axes[1]
    d = np.asarray(prof.density, dtype=float)
    ax.fill_between(y, 0, d, color="#6b8fb5", alpha=.35)
    ax.plot(y, d, color="#1f4e79", lw=1.8)
    ax.axhline(0.5, color="#c07a2c", ls="--", lw=1.2)
    ax.text(0.02, 0.53, "floor = 0.50 (no region may be starved)",
            fontsize=7.5, color="#c07a2c")
    for e in band:
        ax.axvline(e, color="#c0392b", lw=1.1, ls=":")
    ax.text(0.775, ax.get_ylim()[1]*.9, "elevon band", fontsize=8,
            color="#c0392b", ha="center")
    _style(ax, "STEP 3-5  Density = sqrt(|second derivative|), worst channel wins, "
               "control_gain weighted x3\nTall = shape changing fast = needs sections",
           "", "information density")

    # (3) resulting section positions vs uniform
    ax = axes[2]
    frac = np.array(sorted(float(s.span_fraction) for s in ex))
    n = len(frac)
    uni = np.linspace(0, 1, n)
    ax.plot(uni, np.zeros_like(uni) + 1, "|", ms=22, mew=1.8, color="#999",
            label=f"uniform ({n} sections)")
    ax.plot(frac, np.zeros_like(frac) + 0.6, "|", ms=22, mew=1.8,
            color="#1f6f4a", label=f"as built ({n}, {meta['section_placement']})")
    for pin in meta["feature_pins"]:
        ax.plot([pin], [0.6], "v", ms=7, color="#c0392b", zorder=5)
    ax.plot([], [], "v", color="#c0392b", label="hard feature pin (never dropped)")
    ax.set_ylim(0.3, 1.3); ax.set_yticks([])
    _style(ax, "STEP a-f  Where the sections actually end up",
           "span fraction  (0 = centreline, 1 = tip)", "")
    ax.legend(fontsize=8, frameon=False, loc="upper center", ncol=3)

    fig.tight_layout()
    fig.savefig(FIGS / "06_what_the_metric_is.png", dpi=150)
    plt.close(fig)
    print("  06_what_the_metric_is.png")


def fig_audit():
    """Why the first verdict was wrong: the reference could not resolve drag."""
    f = REPO / "configs" / "aero" / "placement_audit_evidence" / "reference_neutrality.json"
    if not f.exists():
        print("  (no neutrality json)"); return
    d = json.loads(f.read_text())
    fig, ax = plt.subplots(figsize=(7.6, 4.6))
    for name, marker, col in (("nominal", "o", "#1f4e79"),
                              ("elevon_narrow", "s", "#c0392b")):
        if name not in d:
            continue
        ns = sorted(int(k) for k in d[name])
        drag = [d[name][str(n)]["drag"] * 100 for n in ns]
        ctrl = [d[name][str(n)]["ctrl"] * 100 for n in ns]
        ax.plot(ns, drag, "-" + marker, color=col, lw=1.8, ms=7,
                label=f"{name} — drag")
        ax.plot(ns, ctrl, "--" + marker, color=col, lw=1.3, ms=5, alpha=.6,
                label=f"{name} — control derivs")
    ax.axhspan(0, 0.5, color="#1f6f4a", alpha=.12)
    ax.text(52, 0.18, "usable: below the ~0.5 pp effect being measured",
            fontsize=8, color="#1f6f4a")
    _style(ax, "Why the first verdict was withdrawn:\n"
               "the reference disagrees with ITSELF depending on how its own sections are placed",
           "reference sections", "self-disagreement, uniform vs adaptive  [%]")
    ax.legend(fontsize=8, frameon=False)
    fig.tight_layout(); fig.savefig(FIGS / "07_reference_not_neutral.png", dpi=150)
    plt.close(fig); print("  07_reference_not_neutral.png")


def fig_budget():
    f = REPO / "configs" / "aero" / "placement_audit_evidence" / "placement_audit.json"
    if not f.exists():
        print("  (no audit json)"); return
    d = json.loads(f.read_text()).get("test2", {})
    names = [n for n in d if d[n]]
    if not names:
        return
    fig, axes = plt.subplots(1, len(names), figsize=(3.5 * len(names), 3.9),
                             sharey=True)
    axes = np.atleast_1d(axes)
    for ax, n in zip(axes, names):
        bs = sorted(int(k) for k in d[n])
        b = [d[n][str(k)]["B"]["ctrl"] * 100 for k in bs]
        c = [d[n][str(k)]["C"]["ctrl"] * 100 for k in bs]
        ax.plot(bs, b, "-o", color="#6b8fb5", lw=1.6, ms=5, label="uniform + pins")
        ax.plot(bs, c, "-o", color="#1f6f4a", lw=1.6, ms=5, label="adaptive")
        _style(ax, n, "section budget", "worst control error [%]")
        ax.set_yscale("log")
    axes[0].legend(fontsize=8, frameon=False)
    fig.suptitle("Control-derivative error vs section budget — adaptive wins at "
                 "EVERY budget where the ramp is severe", fontsize=10.5,
                 weight="bold")
    fig.tight_layout(); fig.savefig(FIGS / "08_budget_sweep.png", dpi=150)
    plt.close(fig); print("  08_budget_sweep.png")


if __name__ == "__main__":
    FIGS.mkdir(parents=True, exist_ok=True)
    fig_metric_explained(); fig_audit(); fig_budget()
    print("->", FIGS)
