"""Figures + HTML report for the section-placement decision study."""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

REPO = Path(__file__).resolve().parents[2]
DATA = REPO / "data" / "lowfi_avl_study" / "placement_decision" / "placement_decision.json"
RESCUE = REPO / "configs" / "aero" / "placement_decision_evidence"
FIGS = REPO / "studies" / "figures" / "placement_decision"

LABEL = {"A_uniform_no_pins": "A  uniform, no pins",
         "B_uniform_pinned": "B  uniform + hard pins",
         "C_adopted_auto": "C  adopted (auto)",
         "D_adopted_always": "D  monitor always on"}
COLOR = {"A_uniform_no_pins": "#b0b7c3", "B_uniform_pinned": "#6b8fb5",
         "C_adopted_auto": "#1f6f4a", "D_adopted_always": "#c07a2c"}
APS = list(LABEL)


def load() -> dict:
    src = DATA if DATA.exists() else RESCUE / "placement_decision.json"
    return json.loads(src.read_text(encoding="utf-8"))


def _style(ax, title, xl, yl):
    ax.set_title(title, fontsize=11, weight="bold")
    ax.set_xlabel(xl, fontsize=9); ax.set_ylabel(yl, fontsize=9)
    ax.grid(alpha=.25, linewidth=.6); ax.tick_params(labelsize=8)
    for s in ("top", "right"): ax.spines[s].set_visible(False)


def fig_per_case(r, out):
    cases = list(r["cases"])
    x = np.arange(len(cases)); w = 0.2
    fig, ax = plt.subplots(figsize=(11, 4.4))
    for i, ap in enumerate(APS):
        v = [r["cases"][c]["approaches"][ap]["worst_control"] * 100 for c in cases]
        ax.bar(x + (i - 1.5) * w, v, w, label=LABEL[ap], color=COLOR[ap])
    _style(ax, "Worst control-derivative error vs the 49-section reference "
               "(equal 25-section budget)", "", "worst error  [%]")
    ax.set_xticks(x); ax.set_xticklabels(cases, rotation=20, ha="right", fontsize=8)
    ax.legend(fontsize=8, ncol=4, frameon=False)
    fig.tight_layout(); fig.savefig(out / "01_per_case_control_error.png", dpi=150)
    plt.close(fig)


def fig_summary(r, out):
    s = r["summary"]
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.0))
    for ax, key, t in ((axes[0], "max_ctrl", "WORST case (the number that must be defended)"),
                       (axes[1], "mean_ctrl", "MEAN across all 10 geometries")):
        order = sorted(APS, key=lambda a: s[a][key])
        v = [s[a][key] * 100 for a in order]
        b = ax.barh([LABEL[a] for a in order], v, color=[COLOR[a] for a in order])
        for bb, vv in zip(b, v):
            ax.text(vv + max(v) * .02, bb.get_y() + bb.get_height() / 2,
                    f"{vv:.2f}%", va="center", fontsize=8.5, weight="bold")
        _style(ax, t, "worst control-derivative error  [%]", "")
        ax.set_xlim(0, max(v) * 1.25); ax.invert_yaxis()
    fig.tight_layout(); fig.savefig(out / "02_summary_ranking.png", dpi=150)
    plt.close(fig)


def fig_ramp(r, out):
    """The mechanism: ramp fraction is what placement actually changes."""
    cases = list(r["cases"])
    fig, ax = plt.subplots(figsize=(7.4, 4.6))
    for ap in APS:
        xs = [r["cases"][c]["approaches"][ap].get("ramp") for c in cases]
        ys = [r["cases"][c]["approaches"][ap]["worst_control"] * 100 for c in cases]
        pts = [(a * 100, b) for a, b in zip(xs, ys) if isinstance(a, float) and np.isfinite(a)]
        if pts:
            ax.scatter(*zip(*pts), s=46, color=COLOR[ap], label=LABEL[ap],
                       edgecolor="white", linewidth=.7, zorder=3)
    ax.axvline(15, color="#c0392b", ls="--", lw=1.2)
    ax.text(15.4, ax.get_ylim()[1] * .93, "DECISION-0010 limit\nramp $\\leq$ 15%",
            fontsize=7.6, color="#c0392b")
    _style(ax, "Mechanism: what placement changes is the gain-ramp fraction",
           "gain-ramp fraction of the elevon band  [%]", "worst control error  [%]")
    ax.legend(fontsize=8, frameon=False)
    fig.tight_layout(); fig.savefig(out / "03_ramp_mechanism.png", dpi=150)
    plt.close(fig)


def fig_gap(r, out):
    cases = list(r["cases"])
    x = np.arange(len(cases)); w = 0.2
    fig, ax = plt.subplots(figsize=(11, 3.8))
    for i, ap in enumerate(APS):
        v = [r["cases"][c]["approaches"][ap].get("max_gap") or np.nan for c in cases]
        ax.bar(x + (i - 1.5) * w, v, w, label=LABEL[ap], color=COLOR[ap])
    ax.axhline(1.0, color="#555", lw=1, ls=":")
    _style(ax, "Cost side: largest spanwise gap relative to uniform "
               "(1.0 = perfectly even)", "", "max gap / uniform gap")
    ax.set_xticks(x); ax.set_xticklabels(cases, rotation=20, ha="right", fontsize=8)
    ax.legend(fontsize=8, ncol=4, frameon=False)
    fig.tight_layout(); fig.savefig(out / "04_gradation_cost.png", dpi=150)
    plt.close(fig)


def fig_quantities(r, out):
    """Which quantities the approaches actually differ on."""
    cases = list(r["cases"])
    qs = sorted({q for c in cases for ap in APS
                 for q in r["cases"][c]["approaches"][ap]["errors"]})
    fig, ax = plt.subplots(figsize=(11, 4.4))
    x = np.arange(len(qs)); w = 0.2
    for i, ap in enumerate(APS):
        v = [np.nanmax([r["cases"][c]["approaches"][ap]["errors"].get(q, np.nan)
                        for c in cases]) * 100 for q in qs]
        ax.bar(x + (i - 1.5) * w, v, w, label=LABEL[ap], color=COLOR[ap])
    _style(ax, "Worst error per quantity, across all geometries "
               "(only references above the print-noise floor)", "", "worst error  [%]")
    ax.set_yscale("log"); ax.set_xticks(x)
    ax.set_xticklabels(qs, rotation=35, ha="right", fontsize=8)
    ax.legend(fontsize=8, ncol=4, frameon=False)
    fig.tight_layout(); fig.savefig(out / "05_per_quantity.png", dpi=150)
    plt.close(fig)


def main() -> None:
    r = load()
    FIGS.mkdir(parents=True, exist_ok=True)
    RESCUE.mkdir(parents=True, exist_ok=True)
    for f in (fig_per_case, fig_summary, fig_ramp, fig_gap, fig_quantities):
        f(r, FIGS)
    # rescue the evidence out of gitignored data/
    (RESCUE / "placement_decision.json").write_text(
        json.dumps(r, indent=2, default=str), encoding="utf-8")
    txt = DATA.parent / "placement_decision.txt"
    if txt.exists():
        (RESCUE / "placement_decision.txt").write_text(
            txt.read_text(encoding="utf-8"), encoding="utf-8")
    print("figures ->", FIGS)
    print("evidence rescued ->", RESCUE)


if __name__ == "__main__":
    main()
