"""Generate studies/section_placement_decision.md from the measured JSON."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[2]
EV = REPO / "configs" / "aero" / "placement_decision_evidence" / "placement_decision.json"
RAW = REPO / "data" / "lowfi_avl_study" / "placement_decision" / "placement_decision.json"
OUT = REPO / "studies" / "section_placement_decision.md"

LABEL = {"A_uniform_no_pins": "A — uniform, no pins",
         "B_uniform_pinned": "B — uniform + hard pins",
         "C_adopted_auto": "C — adopted (pins + monitor, gated)",
         "D_adopted_always": "D — monitor always on"}
APS = list(LABEL)
CONTROL = ("CL_de", "Cm_de", "Cl_da", "CY_da", "Cn_da")


def main() -> None:
    r = json.loads((EV if EV.exists() else RAW).read_text(encoding="utf-8"))
    s, cases = r["summary"], list(r["cases"])
    st = r["settings"]
    # Rank on the worst error across ALL quantities, not just the control
    # derivatives. Ranking a placement method only on the quantities it was
    # designed to improve is question-begging: it hides the cost the method pays
    # elsewhere, and here that cost is real (induced drag).
    order = sorted(APS, key=lambda a: (s[a]["max_all"], s[a]["mean_all"]))
    win = order[0]

    def cell(c, ap, k="worst_control"):
        return r["cases"][c]["approaches"][ap][k]

    L = [f"# Which section-placement approach should AERIS use?",
         "",
         "**Status: decided — see the verdict below. Supersedes the ranking in "
         "`curvature_monitor_metric_evaluation.md`.**", "",
         "## Why this study exists", "",
         "The configuration AERIS adopted in DECISION-0012 had never itself been "
         "measured. The earlier study measured a policy of the *same name* but a "
         "different implementation: pins **replaced** their nearest neighbour "
         "(losing pins and widening gaps) and the section budget drifted — asking "
         "for 25 produced 29. Ranking numbers from that run therefore do not "
         "transfer to the code that ships. This study measures the shipped code.",
         "",
         "## What is being compared", "",
         "| | approach | what it does |",
         "|---|---|---|",
         "| A | uniform, no pins | evenly spaced sections; only the elevon edges land on features |",
         "| B | uniform + hard pins | evenly spaced, then the six planform/control breakpoints are **inserted** as sections |",
         "| C | **adopted** | B, plus the worst-channel geometric-information monitor, switched on only when the gain-ramp criterion is violated |",
         "| D | monitor always on | same monitor, forced on every geometry |",
         "",
         "## Method", "",
         f"- **{len(cases)} geometries**: 6 hand-built stress cases (benign, nominal, "
         "narrow elevon, wide elevon, maximum planform gradient, maximum aspect "
         f"ratio) + {len(cases)-6} random DoE draws.",
         f"- **Equal budget**: every approach gets **exactly {st['budget']} sections**. "
         "This is the property the earlier study lacked, and without it the "
         "comparison is not a comparison of *placement* — it is a comparison of "
         "resolution.",
         f"- **Reference**: the same geometry at **{st['reference_sections']} sections** "
         f"with **{st.get('panels_reference', 2)} spanwise panels** per interval, "
         "uniform + pinned. This is *panel-matched*: the candidates run "
         f"{st['budget']} sections x {st.get('panels_candidate', 4)} panels = 96 strips "
         f"per side, and the reference runs {st['reference_sections']} x "
         f"{st.get('panels_reference', 2)} = the same 96 strips per side, the same "
         "4608 vortices, but twice as many geometric stations defining the loft. So "
         "the comparison isolates what placement governs — how well a finite set of "
         "stations describes the shape and the control edges — instead of "
         "confounding it with panel resolution. (A 49x4 reference would be 9216 "
         "vortices, past AVL's ~6000 array limit; it returns `status=FAILED` with "
         "every coefficient `None`. That silently NaN'd the first run of this study, "
         "and `write_native_avl` now raises on it instead.)",
         f"- **Condition**: alpha {st['alpha_deg']}°, V {st['velocity_mps']} m/s, "
         f"elevon symmetric {st['elevon_sym_deg']}°, differential "
         f"{st['elevon_diff_deg']}°, viscous (NeuralFoil CDCL) on.",
         f"- **Print-noise floor**: a relative error is only counted when the "
         f"reference magnitude exceeds `{st['reference_floor']:g}` — 100× AVL's "
         "printed resolution of 1e-6. Omitting this floor is what invalidated the "
         "previous ranking: `Cn_da` has a reference of −2.3e−05, so one unit in "
         "AVL's last printed digit *is* 4.35% error, and seven policies scored "
         "exactly 4.348% on meshes with 6× different ramp fractions.",
         "",
         "## Result", "",
         f"| approach | mean worst-control | **max worst-control** | mean worst-any | max worst-any | per-case wins |",
         "|---|---|---|---|---|---|"]
    for ap in order:
        v = s[ap]
        wins = sum(1 for i in range(len(cases))
                    if v["per_case"][i] == min(s[a]["per_case"][i] for a in APS))
        star = " **←**" if ap == win else ""
        L.append(f"| {LABEL[ap]}{star} | {v['mean_ctrl']*100:.2f}% | "
                 f"**{v['max_ctrl']*100:.2f}%** | {v['mean_all']*100:.2f}% | "
                 f"{v['max_all']*100:.2f}% | {wins}/{len(cases)} |")

    L += ["", "![ranking](figures/placement_decision/02_summary_ranking.png)", "",
          "### Per geometry", "",
          "Worst control-derivative error, then the gain-ramp fraction that "
          "explains it. `placement` is what the gate actually chose for C.", "",
          "| geometry | " + " | ".join(LABEL[a].split(" — ")[0] for a in APS) +
          " | ramp A | ramp C | C chose |", "|---" * (len(APS) + 4) + "|"]
    for c in cases:
        row = [f"{cell(c, a)*100:.2f}%" for a in APS]
        best = min(cell(c, a) for a in APS)
        row = [(f"**{x}**" if abs(cell(c, a) - best) < 1e-12 else x)
               for x, a in zip(row, APS)]

        def _r(ap):
            v = cell(c, ap, "ramp")
            return f"{v*100:.1f}%" if isinstance(v, float) and np.isfinite(v) else "—"

        L.append(f"| {c} | " + " | ".join(row) +
                 f" | {_r('A_uniform_no_pins')} | {_r('C_adopted_auto')}"
                 f" | {cell(c, 'C_adopted_auto', 'placement')} |")

    L += ["", "![per case](figures/placement_decision/01_per_case_control_error.png)",
          "", "### Mechanism", "",
          "Placement does not act on the derivatives directly. What it changes is "
          "the **gain-ramp fraction**: AVL interpolates control gain linearly "
          "between sections, so the two intervals just outside the elevon band "
          "carry a half-deflected elevon. Their combined width divided by the band "
          "width is the ramp fraction, and DECISION-0010 measured r = +0.978 "
          "between it and control-derivative error.", "",
          "![mechanism](figures/placement_decision/03_ramp_mechanism.png)", "",
          "The cost side is gradation: inserting pins and grading toward high-"
          "information regions leaves a larger largest-gap than uniform spacing.",
          "", "![cost](figures/placement_decision/04_gradation_cost.png)", "",
          "![per quantity](figures/placement_decision/05_per_quantity.png)", ""]

    # ---- verdict, derived from the data ---------------------------------
    a_max, w_max = s["A_uniform_no_pins"]["max_all"], s[win]["max_all"]
    L += ["## Verdict", "",
          f"**Use {LABEL[win]}.** Worst case across all {len(cases)} geometries: "
          f"**{w_max*100:.2f}%** on control derivatives, versus "
          f"{a_max*100:.2f}% for unpinned uniform spacing "
          f"({'a ' + format(a_max/w_max, '.2f') + '× reduction' if w_max > 0 else 'n/a'}).",
          ""]
    if s["C_adopted_auto"]["max_ctrl"] <= s["D_adopted_always"]["max_ctrl"]:
        L.append("Gating the monitor on the ramp criterion (C) is at least as good "
                 "as running it unconditionally (D), and it leaves the majority of "
                 "geometries on plain graded-uniform spacing — the more defensible "
                 "default, because it means the adaptive machinery only engages "
                 "where a stated criterion says it must.")
    else:
        L.append("Running the monitor unconditionally (D) beats gating it (C). The "
                 "gate should be removed, or its threshold retuned — see open items.")
    L += ["",
          "### Settings to use", "", "```yaml", "geometry:", "  aero_discretisation:",
          f"    n_sections: {st['budget']}            # FINAL count, pins included",
          "    span_margin: 0.0",
          "    snap_sections_to_control: true   # pins are INSERTED, never substituted",
          f"    section_placement: {'auto' if win == 'C_adopted_auto' else 'always' if win == 'D_adopted_always' else 'never'}",
          "    ramp_fraction_limit: 0.15",
          "    spanwise_panels_per_section: 4", "    nchordwise: 24", "    cspace: 1.0",
          "```", "",
          "### What is *not* claimed", "",
          "- Nothing here is claimed about `Cn_da`, `CY_da` or any other quantity "
          "whose reference falls below the print-noise floor on a given geometry; "
          "those entries are dropped, not scored as zero.",
          "- The reference is a finer AVL mesh, not experiment or CFD. This study "
          "establishes **discretisation convergence**, not physical accuracy.",
          "- The monitor's channel weights and the 0.15 ramp gate are calibrated on "
          "this geometry family, not derived from first principles.",
          "",
          "### Open items", "",
          "- The `floor = 0.50` clamp inside the monitor was tuned against the "
          "earlier magnitude-erasing normalisation; it has not been re-tuned since "
          "the fixed physical reference scales replaced it.",
          "- Section budget is fixed at 25 by config. The monitor produces the "
          "information integral needed to *choose* the budget; that is not wired up.",
          "",
          "### Reproduce", "", "```bash",
          "python standalone/lowfi_avl_study/placement_decision_study.py",
          "python standalone/lowfi_avl_study/make_placement_figures.py",
          "python standalone/lowfi_avl_study/make_placement_report.py", "```", "",
          "Evidence (tracked, survives `data/` being wiped): "
          "`configs/aero/placement_decision_evidence/`.", ""]

    OUT.write_text("\n".join(L) + "\n", encoding="utf-8")
    print("wrote", OUT)
    print("winner:", win, f"{w_max*100:.2f}%")


if __name__ == "__main__":
    main()
