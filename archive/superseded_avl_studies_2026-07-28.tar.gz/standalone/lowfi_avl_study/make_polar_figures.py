"""Polars and error statistics — the aerodynamic consequence of the choices."""
from __future__ import annotations
import json
from pathlib import Path
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

REPO = Path(__file__).resolve().parents[2]
FIGS = REPO / "studies" / "figures" / "placement_decision"
POL = REPO / "data" / "lowfi_avl_study" / "polars" / "polars.json"
EV = REPO / "configs" / "aero" / "placement_decision_evidence" / "placement_decision.json"

STY = {"uniform_pinned": ("#8a8f98", "-o", "uniform + pins (25)"),
       "auto": ("#1f6f4a", "-s", "auto (25)"),
       "reference": ("#c0392b", "--", "reference (49)")}
LBL = {"A_uniform_no_pins": "A no pins", "B_uniform_pinned": "B uniform+pins",
       "C_adopted_auto": "C auto", "D_adopted_always": "D always"}
COL = {"A_uniform_no_pins": "#b0b7c3", "B_uniform_pinned": "#6b8fb5",
       "C_adopted_auto": "#1f6f4a", "D_adopted_always": "#c07a2c"}
CONTROL = ("CL_de", "Cm_de", "Cl_da", "CY_da", "Cn_da")
DRAG = {"CDind", "cd_total", "e"}


def _s(ax, t, xl, yl):
    ax.set_title(t, fontsize=9.8, weight="bold")
    ax.set_xlabel(xl, fontsize=8.8); ax.set_ylabel(yl, fontsize=8.8)
    ax.grid(alpha=.25, lw=.6); ax.tick_params(labelsize=8)
    for s in ("top", "right"): ax.spines[s].set_visible(False)


def fig_polars():
    d = json.loads(POL.read_text())
    cases = list(d)
    fig, axes = plt.subplots(len(cases), 4, figsize=(15.2, 3.5 * len(cases)))
    axes = np.atleast_2d(axes)
    for r, cname in enumerate(cases):
        for kname, rows in d[cname].items():
            col, mk, lab = STY[kname]
            ok = [x for x in rows if x.get("status") == "SUCCESS"]
            a = [x["alpha"] for x in ok]
            CL = [x["CL"] for x in ok]; CD = [x["CD"] for x in ok]
            Cm = [x["Cm"] for x in ok]; de = [x["CL_de"] for x in ok]
            lw = 2.2 if kname == "reference" else 1.5
            axes[r][0].plot(a, CL, mk, color=col, lw=lw, ms=4, label=lab)
            axes[r][1].plot(CD, CL, mk, color=col, lw=lw, ms=4, label=lab)
            axes[r][2].plot(a, Cm, mk, color=col, lw=lw, ms=4, label=lab)
            axes[r][3].plot(a, de, mk, color=col, lw=lw, ms=4, label=lab)
        t = cname.replace("_", " ")
        _s(axes[r][0], f"{t} — lift curve", "alpha [deg]", "$C_L$")
        _s(axes[r][1], f"{t} — drag polar", "$C_D$ (total)", "$C_L$")
        _s(axes[r][2], f"{t} — pitching moment", "alpha [deg]", "$C_m$")
        _s(axes[r][3], f"{t} — elevon authority", "alpha [deg]", "$C_{L\\delta e}$")
        axes[r][0].legend(fontsize=7.6, frameon=False)
    fig.suptitle("Polars: uniform+pins and auto against the panel-matched reference\n"
                 "(the curves lie on top of each other — that is the result)",
                 fontsize=12, weight="bold")
    fig.tight_layout(rect=[0, 0, 1, 0.93])
    fig.savefig(FIGS / "13_polars.png", dpi=150); plt.close(fig)
    print("  13_polars.png")


def fig_polar_errors():
    """Error across the envelope — separating the real effect from a zero-crossing.

    Relative error is meaningless where the reference passes through zero. Cm does
    exactly that between alpha 0 and 2 deg, so a relative-error plot shows a
    spurious spike there while the underlying ABSOLUTE offset is nearly constant.
    Left panel: the quantity placement targets, where relative error is safe.
    Right panel: Cm as an absolute offset, which is the honest way to show it.
    """
    d = json.loads(POL.read_text())
    cases = list(d)
    fig, axes = plt.subplots(2, len(cases), figsize=(6.6 * len(cases), 7.4))
    axes = np.atleast_2d(axes)
    if axes.shape[0] == 1:
        axes = axes.T
    for k, cname in enumerate(cases):
        ref = {x["alpha"]: x for x in d[cname]["reference"]
               if x.get("status") == "SUCCESS"}
        # --- (top) elevon authority, relative error -----------------------
        ax = axes[0][k]
        for kname in ("uniform_pinned", "auto"):
            col, mk, lab = STY[kname]
            a, e = [], []
            for x in d[cname][kname]:
                r = ref.get(x["alpha"])
                if not r or x.get("status") != "SUCCESS":
                    continue
                p, tt = x.get("CL_de"), r.get("CL_de")
                if isinstance(p, float) and isinstance(tt, float) and abs(tt) > 1e-4:
                    a.append(x["alpha"]); e.append(abs(p - tt) / max(abs(p), abs(tt)) * 100)
            ax.plot(a, e, mk, color=col, lw=1.8, ms=5, label=lab)
        _s(ax, f"{cname.replace('_', ' ')} — elevon authority $C_{{L\\delta e}}$",
           "alpha [deg]", "error vs reference [%]")
        ax.set_ylim(bottom=0); ax.legend(fontsize=8, frameon=False)

        # --- (bottom) Cm as an ABSOLUTE offset ----------------------------
        ax = axes[1][k]
        for kname in ("uniform_pinned", "auto"):
            col, mk, lab = STY[kname]
            a, e = [], []
            for x in d[cname][kname]:
                r = ref.get(x["alpha"])
                if not r or x.get("status") != "SUCCESS":
                    continue
                p, tt = x.get("Cm"), r.get("Cm")
                if isinstance(p, float) and isinstance(tt, float):
                    a.append(x["alpha"]); e.append(abs(p - tt))
            ax.plot(a, e, mk, color=col, lw=1.8, ms=5, label=lab)
        zc = [x["alpha"] for x in d[cname]["reference"]
              if isinstance(x.get("Cm"), float) and abs(x["Cm"]) < 0.05]
        if zc:
            ax.axvspan(min(zc), max(zc), color="#c0392b", alpha=.10)
            ax.text(np.mean(zc), ax.get_ylim()[1] * .92,
                    "$C_m$ crosses zero here —\nrelative error is meaningless",
                    fontsize=7.6, color="#c0392b", ha="center", va="top")
        _s(ax, f"{cname.replace('_', ' ')} — $C_m$, ABSOLUTE offset",
           "alpha [deg]", "$|\\Delta C_m|$")
        ax.set_ylim(bottom=0); ax.legend(fontsize=8, frameon=False)
    fig.suptitle("Across the alpha envelope, not just one design point.\n"
                 "Adaptive placement is ~3x better on elevon authority at every "
                 "alpha, and carries a small constant $C_m$ offset.",
                 fontsize=11.8, weight="bold")
    fig.tight_layout(rect=[0, 0, 1, 0.92])
    fig.savefig(FIGS / "14_polar_errors.png", dpi=150); plt.close(fig)
    print("  14_polar_errors.png")


def fig_stats():
    """Distribution over the 10 geometries: median, quartiles, outliers."""
    r = json.loads(EV.read_text())
    cases = list(r["cases"]); aps = list(LBL)
    fig, axes = plt.subplots(1, 2, figsize=(13.0, 4.8))

    # (a) worst resolvable error per geometry
    data = []
    for ap in aps:
        v = []
        for c in cases:
            e = r["cases"][c]["approaches"][ap]["errors"]
            x = [y for q, y in e.items() if q not in DRAG]
            if x:
                v.append(max(x) * 100)
        data.append(v)
    ax = axes[0]
    bp = ax.boxplot(data, tick_labels=[LBL[a] for a in aps], patch_artist=True,
                    medianprops=dict(color="black", lw=2), widths=.55)
    for patch, ap in zip(bp["boxes"], aps):
        patch.set_facecolor(COL[ap]); patch.set_alpha(.75)
    for i, v in enumerate(data):
        ax.scatter(np.full(len(v), i + 1) + np.random.uniform(-.08, .08, len(v)),
                   v, s=16, color="#333", zorder=3, alpha=.65)
        ax.text(i + 1, max(v) * 1.08, f"med {np.median(v):.2f}%", ha="center",
                fontsize=8, weight="bold")
    ax.set_yscale("log")
    _s(ax, "(a) Worst resolvable error per geometry — n = 10\n"
           "box = quartiles, line = median, dots = individual geometries",
       "", "worst error [%]  (log)")

    # (b) control derivatives only, pooled across geometries
    ax = axes[1]
    data2 = []
    for ap in aps:
        v = []
        for c in cases:
            e = r["cases"][c]["approaches"][ap]["errors"]
            v += [y * 100 for q, y in e.items() if q in CONTROL]
        data2.append(v)
    bp = ax.boxplot(data2, tick_labels=[LBL[a] for a in aps], patch_artist=True,
                    medianprops=dict(color="black", lw=2), widths=.55)
    for patch, ap in zip(bp["boxes"], aps):
        patch.set_facecolor(COL[ap]); patch.set_alpha(.75)
    for i, v in enumerate(data2):
        ax.text(i + 1, max(v) * 1.10, f"med {np.median(v):.2f}%", ha="center",
                fontsize=8, weight="bold")
    ax.set_yscale("log")
    _s(ax, "(b) All five control derivatives, pooled over 10 geometries\n"
           "n = 50 per approach",
       "", "error [%]  (log)")
    fig.suptitle("Distribution of error across the design set, not a single number",
                 fontsize=12, weight="bold")
    fig.tight_layout(rect=[0, 0, 1, 0.92])
    fig.savefig(FIGS / "15_error_distributions.png", dpi=150); plt.close(fig)
    print("  15_error_distributions.png")
    for ap, v, v2 in zip(aps, data, data2):
        print(f"    {LBL[ap]:<16} worst med {np.median(v):6.2f}%  "
              f"ctrl med {np.median(v2):6.3f}%  ctrl p90 {np.percentile(v2,90):6.3f}%")


if __name__ == "__main__":
    FIGS.mkdir(parents=True, exist_ok=True)
    fig_stats()
    if POL.exists():
        fig_polars(); fig_polar_errors()
    else:
        print("  (polars.json not ready)")
