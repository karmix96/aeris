"""Spanwise anatomy of the method: what varies, how complex it is, where sections go."""
from __future__ import annotations
import dataclasses
from pathlib import Path
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

REPO = Path(__file__).resolve().parents[2]
CONFIG = REPO / "configs" / "geometry" / "bwb.yaml"
FIGS = REPO / "studies" / "figures" / "placement_decision"

UNITS = {"x_le": "LE sweep,  x/c_root", "z_le": "dihedral,  z/c_root",
         "chord": "chord,  c/c_root", "twist": "twist  [deg]",
         "thickness": "max t/c", "camber": "max camber/c",
         "control_gain": "elevon gain  [0-1]"}
ORDER = ["x_le", "z_le", "chord", "twist", "thickness", "camber", "control_gain"]


def _sty(ax, t="", xl="", yl=""):
    if t: ax.set_title(t, fontsize=9.5, weight="bold")
    ax.set_xlabel(xl, fontsize=8.5); ax.set_ylabel(yl, fontsize=8.5)
    ax.grid(alpha=.25, lw=.6); ax.tick_params(labelsize=7.8)
    for s in ("top", "right"): ax.spines[s].set_visible(False)


def _setup(narrow=True):
    from aeris.common.config import load_yaml_config
    from aeris.geometry.config_resolver import resolve_generator_and_config
    from aeris.geometry.registry import get_geometry_generator
    from aeris.generators.bwb_segmented_v1.pygeo_adapter import (
        build_pygeo, stations_from_records)
    from aeris.generators.bwb_segmented_v1.pygeo_backend import _resolve_airfoil_database
    from aeris.generators.bwb_segmented_v1.services import (
        build_section_geometry_from_sample, generate_bwb_planform_from_sample)
    from aeris.geometry.geometric_information import spanwise_information_profile
    from aeris.generators.bwb_segmented_v1.pygeo_avl_adapter import (
        build_pygeo_sections_from_config)

    gid, g = resolve_generator_and_config(load_yaml_config(CONFIG))
    base = get_geometry_generator(gid).sample_one(g, seed=7000)
    s = dataclasses.replace(base, elevon_start_frac=0.70,
                            elevon_end_frac=0.85) if narrow else base
    pf = generate_bwb_planform_from_sample(s, g)
    sg = build_section_geometry_from_sample(pf, s, g)
    st = tuple(stations_from_records(sg.sections, _resolve_airfoil_database(g)))
    frame = "asb_frame" if g.pygeo.frame_mode == "aeris_frame" else g.pygeo.frame_mode
    build = build_pygeo(st, k_span=g.pygeo.k_span, frame_mode=frame,
                        n_ctl=g.pygeo.n_ctl, tip=g.pygeo.tip,
                        tip_scale=g.pygeo.tip_scale)
    ex, semi, meta = build_pygeo_sections_from_config(CONFIG, sample=s)
    band = (float(meta["control"]["start_frac"]), float(meta["control"]["end_frac"]))
    prof = spanwise_information_profile(build, n_probe=301, chordwise_probe=21,
                                        control_band=band)
    return s, meta, ex, prof, band


def fig_channels():
    """Each design variable's spanwise distribution, in its own physical units."""
    _, meta, _, prof, band = _setup(True)
    y = np.asarray(prof.span_fraction)
    chans = [c for c in ORDER if c in prof.channels]
    n = len(chans)
    fig, axes = plt.subplots((n + 1) // 2, 2, figsize=(10.4, 2.05 * ((n + 1) // 2)),
                             sharex=True)
    axes = np.atleast_1d(axes).ravel()
    for ax, name in zip(axes, chans):
        v = np.asarray(prof.channels[name].values, dtype=float)
        ax.plot(y, v, color="#1f4e79", lw=1.7)
        ax.axvspan(band[0], band[1], color="#c0392b", alpha=.09)
        for p in meta["feature_pins"]:
            ax.axvline(p, color="#c07a2c", lw=.9, ls=":", alpha=.85)
        _sty(ax, name, "", UNITS.get(name, name))
    for ax in axes[n:]:
        ax.axis("off")
    for ax in axes[max(0, n - 2):n]:
        ax.set_xlabel("span fraction", fontsize=8.5)
    fig.suptitle("Spanwise distribution of every channel the monitor watches\n"
                 "shaded = elevon band · dotted = hard feature pins  "
                 "(narrow-elevon geometry)",
                 fontsize=11.5, weight="bold")
    fig.tight_layout(rect=[0, 0, 1, 0.955])
    fig.savefig(FIGS / "10_spanwise_channels.png", dpi=150)
    plt.close(fig); print("  10_spanwise_channels.png")


def fig_complexity():
    """How complex the wing is along the span, and the budget that follows."""
    _, meta, ex, prof, band = _setup(True)
    y = np.asarray(prof.span_fraction)
    d = np.asarray(prof.density, dtype=float)
    cum = np.asarray(prof.cumulative, dtype=float)
    fig, axes = plt.subplots(2, 1, figsize=(9.6, 6.2), sharex=True,
                             gridspec_kw={"height_ratios": [1.35, 1]})
    ax = axes[0]
    ax.fill_between(y, 0, d, color="#6b8fb5", alpha=.35)
    ax.plot(y, d, color="#1f4e79", lw=1.9, label="worst-channel density")
    ax.axhline(0.5, color="#c07a2c", ls="--", lw=1.2, label="floor 0.50")
    ax.axvspan(band[0], band[1], color="#c0392b", alpha=.09)
    for p in meta["feature_pins"]:
        ax.axvline(p, color="#c07a2c", lw=.9, ls=":")
    _sty(ax, "Wing complexity along the span:  rho(y) = sqrt(|d2g/dy2|), worst channel",
         "", "information density")
    ax.legend(fontsize=8, frameon=False)
    ax = axes[1]
    ax.plot(y, cum, color="#1f6f4a", lw=2.0)
    ax.plot([0, 1], [0, 1], color="#999", ls="--", lw=1.2,
            label="uniform (constant complexity)")
    ax.axvspan(band[0], band[1], color="#c0392b", alpha=.09)
    _sty(ax, "Cumulative complexity — sections are placed at equal steps UP this curve",
         "span fraction", "cumulative fraction")
    ax.legend(fontsize=8, frameon=False)
    ax.text(.03, .78, "steep = complex,\nneeds sections", fontsize=8, color="#1f6f4a")
    fig.tight_layout(); fig.savefig(FIGS / "11_spanwise_complexity.png", dpi=150)
    plt.close(fig); print("  11_spanwise_complexity.png")


def fig_placement_compare():
    """What auto actually produces, against uniform, on both gate branches."""
    import aeris.geometry.config_resolver as CR
    from aeris.common.config import load_yaml_config
    from aeris.generators.bwb_segmented_v1.pygeo_avl_adapter import (
        build_pygeo_sections_from_config)

    def grid(sample, placement):
        gid, gc = CR.resolve_generator_and_config(load_yaml_config(CONFIG))
        gc2 = dataclasses.replace(gc, aero_discretisation=dataclasses.replace(
            gc.aero_discretisation, section_placement=placement))
        o = CR.resolve_generator_and_config
        CR.resolve_generator_and_config = lambda raw: (gid, gc2)
        try:
            ex, _, m = build_pygeo_sections_from_config(CONFIG, sample=sample)
        finally:
            CR.resolve_generator_and_config = o
        return np.array(sorted(float(s.span_fraction) for s in ex)), m

    from aeris.geometry.config_resolver import resolve_generator_and_config
    from aeris.geometry.registry import get_geometry_generator
    gid, g = resolve_generator_and_config(load_yaml_config(CONFIG))
    base = get_geometry_generator(gid).sample_one(g, seed=7000)
    cases = [("nominal  —  gate CLOSED", base),
             ("narrow elevon  —  gate OPEN",
              dataclasses.replace(base, elevon_start_frac=0.70,
                                  elevon_end_frac=0.85))]
    fig, axes = plt.subplots(2, 2, figsize=(12.4, 6.0),
                            gridspec_kw={"width_ratios": [2.0, 1.0]})
    for r, (title, s) in enumerate(cases):
        fu, mu = grid(s, "never")
        fa, ma = grid(s, "auto")
        band = (float(mu["control"]["start_frac"]), float(mu["control"]["end_frac"]))
        ax = axes[r][0]
        ax.axvspan(band[0], band[1], color="#c0392b", alpha=.10,
                   label="elevon band")
        ax.plot(fu, np.full_like(fu, 1.0), "|", ms=26, mew=2.0, color="#8a8f98",
                label=f"uniform + pins  ({len(fu)})")
        ax.plot(fa, np.full_like(fa, 0.6), "|", ms=26, mew=2.0, color="#1f6f4a",
                label=f"auto  ({len(fa)}, {ma['section_placement']})")
        for p in mu["feature_pins"]:
            ax.plot([p], [1.0], "v", ms=6.5, color="#c07a2c", zorder=5)
            ax.plot([p], [0.6], "v", ms=6.5, color="#c07a2c", zorder=5)
        ax.plot([], [], "v", color="#c07a2c", label="hard feature pin")
        ax.set_ylim(.35, 1.35); ax.set_yticks([])
        _sty(ax, title, "span fraction" if r else "", "")
        ax.legend(fontsize=7.6, frameon=False, ncol=4, loc="upper center")
        ax.text(.005, 1.19, f"ramp {mu['ramp_fraction']*100:.1f}%", fontsize=8,
                color="#8a8f98", weight="bold")
        ax.text(.005, .79, f"ramp {ma['ramp_fraction']*100:.1f}%", fontsize=8,
                color="#1f6f4a", weight="bold")
        # spacing histogram
        ax = axes[r][1]
        ax.step(fu[:-1], np.diff(fu), where="post", color="#8a8f98", lw=1.7,
                label="uniform + pins")
        ax.step(fa[:-1], np.diff(fa), where="post", color="#1f6f4a", lw=1.7,
                label="auto")
        ax.axvspan(band[0], band[1], color="#c0392b", alpha=.10)
        _sty(ax, "local section spacing", "span fraction" if r else "", "Δ span")
        ax.legend(fontsize=7.6, frameon=False)
    fig.suptitle("What 'auto' actually produces, against uniform spacing",
                 fontsize=12, weight="bold")
    fig.tight_layout(rect=[0, 0, 1, 0.945])
    fig.savefig(FIGS / "12_auto_vs_uniform_grid.png", dpi=150)
    plt.close(fig); print("  12_auto_vs_uniform_grid.png")


if __name__ == "__main__":
    FIGS.mkdir(parents=True, exist_ok=True)
    fig_channels(); fig_complexity(); fig_placement_compare()
    print("->", FIGS)
