"""Which section-placement approach should AERIS use? Measured, at equal budget.

Closes a gap: the configuration adopted in DECISION-0012 (worst-channel monitor,
thickness off, hard pins inserted, exact 25-section budget) had never itself been
run. Codex's study measured a policy of the same NAME but with a different pin
implementation (pins replaced neighbours; budget drifted), so its numbers do not
transfer.

Four approaches, all at EXACTLY 25 final sections against a 49-section reference
built the same way, over the same 10 geometries Codex used:

  A  uniform_no_pins   uniform spacing, elevon edges only     (pre-DECISION-0012)
  B  uniform_pinned    uniform + hard feature pins
  C  adopted_auto      pins + worst-channel monitor, gated on the ramp criterion
                       (what AERIS does now)
  D  adopted_always    same monitor, forced on every geometry

RANKING RULE (DECISION-0012): a relative error is only counted when the reference
magnitude exceeds 1e-4, i.e. 100x AVL's printed resolution. Without that floor the
ranking is decided by rounding in AVL's last printed digit -- the defect that
invalidated the previous study's conclusion.

    python standalone/lowfi_avl_study/placement_decision_study.py
"""

from __future__ import annotations

import dataclasses
import json
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[2]
CONFIG = REPO / "configs" / "geometry" / "bwb.yaml"
OUT = REPO / "data" / "lowfi_avl_study" / "placement_decision"

ALPHA, BETA, VELOCITY = 6.0, 0.0, 28.0
DE, DA = 4.0, 4.0
BUDGET, REFERENCE = 25, 49
# Panel-matched reference. The candidates run 25 sections x 4 spanwise panels per
# interval = 96 strips per side. The reference runs 49 sections x 2 = 96 strips per
# side: the SAME strip count, the same vortex count, twice as many geometric
# stations defining the loft. So the comparison isolates the thing placement
# governs (how well a finite set of stations describes the shape and the control
# edges) instead of confounding it with panel resolution. Running the reference at
# 49 x 4 instead would be 9216 vortices -- past AVL's ~6000 array limit, which
# returns status=FAILED with every coefficient None.
PANELS_CANDIDATE, PANELS_REFERENCE = 4, 2
REF_FLOOR = 1e-4          # DECISION-0012 print-noise floor

CONTROL = ("CL_de", "Cm_de", "Cl_da", "CY_da", "Cn_da")
TRACKED = ("CL", "CDind", "cd_total", "Cm", "e", "Xnp", "CLa", "Cma", "Clp",
           "Cnb", "Cmq") + CONTROL

CASES: dict[str, dict] = {
    "benign": dict(sw1_deg=-20.0, sw2_deg=-15.0, sw3_deg=-5.0, twist_b0_deg=0.0,
                   twist_b1_deg=-0.5, twist_b2_deg=-1.5, twist_b3_deg=-2.0,
                   dihedral_b2_deg=0.0, dihedral_b3_deg=0.0, c2_ratio=0.70,
                   c3_ratio=0.45, c4_ratio=0.15, b_total_m=1.0, c1_m=0.9),
    "nominal": {},
    "elevon_narrow": dict(elevon_start_frac=0.70, elevon_end_frac=0.85),
    "elevon_wide": dict(elevon_start_frac=0.50, elevon_end_frac=0.98),
    "max_gradient": dict(sw1_deg=-40.0, sw2_deg=-15.0, sw3_deg=-25.0,
                         c2_ratio=0.80, c3_ratio=0.30, c4_ratio=0.08,
                         twist_b0_deg=1.0, twist_b3_deg=-8.0,
                         split_ratio=0.40, b3_ratio=0.55),
    "max_ar": dict(b_total_m=1.25, c1_m=0.70, c4_ratio=0.08, twist_b3_deg=-8.0),
}
RANDOM_SEEDS = (1001, 1002, 1010, 1020)

APPROACHES = {
    "A_uniform_no_pins": dict(placement="never", pins=False),
    "B_uniform_pinned": dict(placement="never", pins=True),
    "C_adopted_auto": dict(placement="auto", pins=True),
    "D_adopted_always": dict(placement="always", pins=True),
}


def _extract(res) -> dict:
    s = res.stability_axis_derivatives or {}
    cd = res.control_derivatives or {}
    sym = next((v for k, v in cd.items() if k.endswith("_sym")), {})
    dif = next((v for k, v in cd.items() if k.endswith("_diff")), {})
    return {"CL": res.cl, "CDind": res.cd_ind, "cd_total": res.cd_total,
            "Cm": res.cm, "e": res.span_efficiency, "Xnp": res.x_np,
            "CLa": s.get("CLa"), "Cma": s.get("Cma"), "Clp": s.get("Clp"),
            "Cnb": s.get("Cnb"), "Cmq": s.get("Cmq"),
            "CL_de": sym.get("CL"), "Cm_de": sym.get("Cm"),
            "Cl_da": dif.get("Cl"), "CY_da": dif.get("CY"), "Cn_da": dif.get("Cn"),
            "n_strips": res.n_strips, "status": res.status}


def run_one(sample, *, n_sections, placement, pins, tag, spanwise_panels, retries=1):
    """One AVL solve with the production entry point, config patched per approach."""
    import aeris.geometry.config_resolver as CR
    from aeris.aero.models import FlightCondition
    from aeris.common.config import load_yaml_config
    from aeris.generators.bwb_segmented_v1.pygeo_avl_adapter import (
        build_pygeo_sections_from_config, run_pygeo_native_avl_case)

    gid, gc = CR.resolve_generator_and_config(load_yaml_config(CONFIG))
    gc2 = dataclasses.replace(gc, aero_discretisation=dataclasses.replace(
        gc.aero_discretisation, section_placement=placement,
        snap_sections_to_control=pins, n_sections=n_sections,
        spanwise_panels_per_section=spanwise_panels))
    orig = CR.resolve_generator_and_config
    CR.resolve_generator_and_config = lambda raw: (gid, gc2)
    try:
        ex, semi, meta = build_pygeo_sections_from_config(
            CONFIG, sample=sample, n_sections=n_sections)
    finally:
        CR.resolve_generator_and_config = orig

    fc = FlightCondition(alpha_deg=ALPHA, beta_deg=BETA, velocity_mps=VELOCITY,
                         altitude_m=0.0)
    res = run_pygeo_native_avl_case(
        flight_condition=fc, output_dir=OUT / tag, extracted_sections=ex,
        semispan_m=semi, control=meta["control"], control_input_deg=DE,
        diff_input_deg=DA, viscous=True, name="pd",
        spanwise_panels_per_section=spanwise_panels,
        nchordwise=meta["nchordwise"], cspace=meta["cspace"], timeout_sec=900)
    out = _extract(res)
    out.update(n_sections=meta["n_sections"], nchordwise=meta["nchordwise"],
               ramp=meta.get("ramp_fraction"),
               max_gap=meta.get("max_gap_ratio"),
               placement=meta.get("section_placement"))
    # AVL occasionally stalls on a stiff case; a stall is a tooling event, not a
    # property of the placement policy, so retry before letting it colour a result.
    if out.get("status") != "SUCCESS" and retries > 0:
        print(f"    [{tag}] status={out.get('status')} -- retrying")
        return run_one(sample, n_sections=n_sections, placement=placement,
                       pins=pins, tag=tag + "_retry",
                       spanwise_panels=spanwise_panels, retries=retries - 1)
    return out


def main() -> None:
    from aeris.common.config import load_yaml_config
    from aeris.geometry.config_resolver import resolve_generator_and_config
    from aeris.geometry.registry import get_geometry_generator

    OUT.mkdir(parents=True, exist_ok=True)
    gid, gcfg = resolve_generator_and_config(load_yaml_config(CONFIG))
    gen = get_geometry_generator(gid)
    base = gen.sample_one(gcfg, seed=7000)

    cases = {k: dataclasses.replace(base, **v) for k, v in CASES.items()}
    for sd in RANDOM_SEEDS:
        cases[f"random_{sd}"] = gen.sample_one(gcfg, seed=sd)

    report: dict = {"settings": {
        "alpha_deg": ALPHA, "beta_deg": BETA, "velocity_mps": VELOCITY,
        "elevon_sym_deg": DE, "elevon_diff_deg": DA, "budget": BUDGET,
        "reference_sections": REFERENCE, "reference_floor": REF_FLOOR,
        "panels_candidate": PANELS_CANDIDATE,
        "panels_reference": PANELS_REFERENCE},
        "cases": {}}

    for name, sample in list(cases.items()):
        ref = run_one(sample, n_sections=REFERENCE, placement="never", pins=True,
                      tag=f"{name}_reference", spanwise_panels=PANELS_REFERENCE)
        if ref.get("status") != "SUCCESS":
            print(f"  !! {name}: REFERENCE {ref.get('status')} -- geometry EXCLUDED")
            report.setdefault("excluded", {})[name] = f"reference {ref.get('status')}"
            continue
        entry = {"reference": ref, "approaches": {}}
        for ap, cfg in APPROACHES.items():
            got = run_one(sample, n_sections=BUDGET, tag=f"{name}_{ap}",
                          spanwise_panels=PANELS_CANDIDATE, **cfg)
            if got.get("status") != "SUCCESS":
                print(f"  !! {name}/{ap}: {got.get('status')} -- cell dropped")
                report.setdefault("failures", []).append(
                    {"case": name, "approach": ap, "status": got.get("status")})
            errs = {}
            for q in TRACKED:
                a, b = got.get(q), ref.get(q)
                if not isinstance(a, float) or not isinstance(b, float):
                    continue
                if abs(b) <= REF_FLOOR:      # print-noise floor
                    continue
                d = max(abs(a), abs(b))
                if d > 1e-30:
                    errs[q] = abs(a - b) / d
            got["errors"] = errs
            got["worst_control"] = max(
                (v for k, v in errs.items() if k in CONTROL), default=float("nan"))
            got["worst_all"] = max(errs.values(), default=float("nan"))
            entry["approaches"][ap] = got
        report["cases"][name] = entry
        line = "  ".join(
            f"{ap.split('_',1)[0]}={entry['approaches'][ap]['worst_control']*100:5.2f}%"
            for ap in APPROACHES)
        print(f"{name:<15} {line}")

    (OUT / "placement_decision.json").write_text(
        json.dumps(report, indent=2, default=str), encoding="utf-8")

    # ---- summary ---------------------------------------------------------
    L = ["Section-placement decision study — equal 25-section budget",
         f"reference {REFERENCE} sections x {PANELS_REFERENCE} panels "
         f"(panel-matched to {BUDGET} x {PANELS_CANDIDATE}); alpha {ALPHA} deg, "
         f"de={DE} da={DA} deg; {len(cases)} geometries",
         f"print-noise floor |reference| > {REF_FLOOR:g} (DECISION-0012)", "",
         f"{'approach':<20}{'mean ctrl':>11}{'max ctrl':>10}{'mean all':>10}"
         f"{'max all':>9}{'wins':>6}"]
    cases = {c: v for c, v in cases.items() if c in report["cases"]}
    stats = {}
    for ap in APPROACHES:
        wc = [report["cases"][c]["approaches"][ap]["worst_control"] for c in cases]
        wa = [report["cases"][c]["approaches"][ap]["worst_all"] for c in cases]
        stats[ap] = {"mean_ctrl": float(np.nanmean(wc)), "max_ctrl": float(np.nanmax(wc)),
                     "mean_all": float(np.nanmean(wa)), "max_all": float(np.nanmax(wa)),
                     "per_case": wc}
    for ap, s in sorted(stats.items(), key=lambda kv: kv[1]["max_ctrl"]):
        wins = sum(1 for c in range(len(cases))
                   if s["per_case"][c] == min(stats[a]["per_case"][c] for a in APPROACHES))
        L.append(f"{ap:<20}{s['mean_ctrl']*100:>10.2f}%{s['max_ctrl']*100:>9.2f}%"
                 f"{s['mean_all']*100:>9.2f}%{s['max_all']*100:>8.2f}%{wins:>6}")
    L += ["", f"{'case':<15}" + "".join(f"{a.split('_',1)[0]:>9}" for a in APPROACHES)]
    for c in cases:
        L.append(f"{c:<15}" + "".join(
            f"{report['cases'][c]['approaches'][a]['worst_control']*100:>8.2f}%"
            for a in APPROACHES))
    report["summary"] = stats
    (OUT / "placement_decision.json").write_text(
        json.dumps(report, indent=2, default=str), encoding="utf-8")
    text = "\n".join(L)
    print("\n" + text)
    (OUT / "placement_decision.txt").write_text(text + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
