"""Re-analyse the 100-run curvature-monitor study without changing the data.

The question this asks is NOT "which policy wins". It is "is the winner an
artefact of how the score was defined?". We therefore re-rank the same 90
comparison rows under several defensible score definitions and look at how
much the ranking moves.

Reads   artifacts/curvature_monitor_aero_study/
Writes  configs/aero/monitor_study_reanalysis/   (tracked; survives data/ wipes)
"""

from __future__ import annotations

import csv
import json
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
STUDY = ROOT / "artifacts" / "curvature_monitor_aero_study"
OUT = ROOT / "configs" / "aero" / "monitor_study_reanalysis"

# err_<name> column  ->  path into native_avl_result.json
REF_PATH = {
    "CL": ("cl",),
    "CDind": ("cd_ind",),
    "CDtotal": ("cd_total",),
    "Cm": ("cm",),
    "e": ("span_efficiency",),
    "Xnp": ("x_np",),
    "CLa": ("stability_axis_derivatives", "CLa"),
    "Cma": ("stability_axis_derivatives", "Cma"),
    "Clp": ("stability_axis_derivatives", "Clp"),
    "Cmq": ("stability_axis_derivatives", "Cmq"),
    "Cnb": ("stability_axis_derivatives", "Cnb"),
    "CL_de": ("control_derivatives", "elevon_sym", "CL"),
    "Cm_de": ("control_derivatives", "elevon_sym", "Cm"),
    "Cl_da": ("control_derivatives", "elevon_diff", "Cl"),
    "Cn_da": ("control_derivatives", "elevon_diff", "Cn"),
    "CY_da": ("control_derivatives", "elevon_diff", "CY"),
}

DRAG = {"CDind", "CDtotal", "e"}
CONTROL = {"CL_de", "Cm_de", "Cl_da", "Cn_da", "CY_da"}
FORCE = {"CL", "Cm"}
STAB = {"Xnp", "CLa", "Cma", "Clp", "Cmq", "Cnb"}

NOISE_FLOOR = 1e-4  # AVL prints 6 decimals -> 100x its print resolution


def dig(d, path):
    for k in path:
        d = d[k]
    return d


def load_references() -> dict[str, dict[str, float]]:
    refs = {}
    for case_dir in sorted((STUDY / "runs").iterdir()):
        f = case_dir / "reference_uniform49" / "native_avl_result.json"
        if not f.exists():
            continue
        r = json.loads(f.read_text())
        refs[case_dir.name] = {q: float(dig(r, p)) for q, p in REF_PATH.items()}
    return refs


def load_rows():
    with open(STUDY / "case_policy_errors.csv") as fh:
        return list(csv.DictReader(fh))


def score(rows, refs, *, quantities, floor, agg):
    """Per-policy aggregate over cases of the worst admissible error."""
    per_policy: dict[str, list[float]] = {}
    for r in rows:
        case, pol = r["case"], r["policy"]
        errs = []
        for q in quantities:
            ref = refs[case][q]
            if floor and abs(ref) <= NOISE_FLOOR:
                continue
            v = r.get(f"err_{q}")
            if v in (None, ""):
                continue
            errs.append(float(v))
        if errs:
            per_policy.setdefault(pol, []).append(max(errs))
    return {p: agg(v) for p, v in per_policy.items()}


def dropped_quantities(refs):
    out = {}
    for q in REF_PATH:
        n = sum(1 for c in refs if abs(refs[c][q]) <= NOISE_FLOOR)
        if n:
            out[q] = n
    return out


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    refs = load_references()
    rows = load_rows()
    lines: list[str] = []

    def say(s=""):
        print(s)
        lines.append(s)

    say("=" * 78)
    say("RE-ANALYSIS OF THE 100-RUN CURVATURE-MONITOR STUDY")
    say("Same data, same 90 comparison rows. Only the score definition changes.")
    say("=" * 78)
    say()

    say("Quantities whose reference sits under the 1e-4 print-noise floor")
    say("(relative error there is rounding, not physics):")
    say()
    say(f"  {'quantity':<10}{'cases below floor (of 10)':>28}")
    for q, n in sorted(dropped_quantities(refs).items(), key=lambda kv: -kv[1]):
        say(f"  {q:<10}{n:>28}")
    say()

    ALL = set(REF_PATH)
    definitions = {
        "D1 everything, no floor (the study's own score)": dict(
            quantities=ALL, floor=False, agg=max),
        "D2 everything, noise floor": dict(
            quantities=ALL, floor=True, agg=max),
        "D3 no drag, noise floor": dict(
            quantities=ALL - DRAG, floor=True, agg=max),
        "D4 control only, noise floor": dict(
            quantities=CONTROL, floor=True, agg=max),
        "D5 forces+stability only, noise floor": dict(
            quantities=FORCE | STAB, floor=True, agg=max),
        "D6 no drag, noise floor, MEAN over cases": dict(
            quantities=ALL - DRAG, floor=True, agg=statistics.fmean),
        "D7 no drag, noise floor, MEDIAN over cases": dict(
            quantities=ALL - DRAG, floor=True, agg=statistics.median),
    }

    ranks: dict[str, dict[str, int]] = {}
    for label, kw in definitions.items():
        s = score(rows, refs, **kw)
        order = sorted(s, key=lambda p: s[p])
        say("-" * 78)
        say(label)
        say("-" * 78)
        for i, p in enumerate(order, 1):
            say(f"  {i:>2}. {p:<38} {100 * s[p]:6.2f}%")
            ranks.setdefault(p, {})[label] = i
        say()

    say("=" * 78)
    say("RANK STABILITY  (position of each policy under each definition)")
    say("=" * 78)
    keys = list(definitions)
    hdr = "  " + "policy".ljust(38) + "".join(f"{k.split()[0]:>5}" for k in keys)
    say(hdr + "   spread")
    for p in sorted(ranks, key=lambda p: statistics.fmean(ranks[p].values())):
        rr = [ranks[p][k] for k in keys]
        say("  " + p.ljust(38) + "".join(f"{v:>5}" for v in rr)
            + f"   {min(rr)}-{max(rr)}")
    say()

    # signal vs noise
    s = score(rows, refs, quantities=ALL - DRAG, floor=True, agg=statistics.fmean)
    best, worst_adaptive = min(s.values()), max(
        v for k, v in s.items() if k != "uniform_pinned25")
    say("=" * 78)
    say("SIGNAL VERSUS THE REFERENCE'S OWN NOISE")
    say("=" * 78)
    say(f"  spread across all 8 monitor policies (D6): "
        f"{100 * best:.2f}% .. {100 * worst_adaptive:.2f}%  "
        f"-> signal = {100 * (worst_adaptive - best):.2f} pp")
    say("  reference disagreement with ITSELF on control derivatives,")
    say("  measured at 49/73/97 sections (placement_audit_evidence):")
    say("    nominal 0.65%   elevon_narrow 0.73%   max_gradient 0.13%   "
        "random_1001 1.20%")
    say(f"  -> noise >= 0.65 pp on the cases where it was measured")
    say()

    (OUT / "reanalysis.txt").write_text("\n".join(lines) + "\n")
    (OUT / "reanalysis.json").write_text(json.dumps(
        {"ranks": ranks, "references": refs,
         "below_floor": dropped_quantities(refs)}, indent=2))
    print(f"\nwrote {OUT}/reanalysis.txt and reanalysis.json")


if __name__ == "__main__":
    main()
