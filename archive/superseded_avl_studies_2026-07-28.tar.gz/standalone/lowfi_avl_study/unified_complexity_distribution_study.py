"""Publication-grade study of AERIS spanwise section distribution.

This is deliberately separate from the earlier exploratory scripts. Its job is
to make the section-distribution claim defensible under review:

* compare the unified spanwise complexity metric against the simple baseline
  (uniform spacing + hard feature pins);
* keep the section budget exactly equal across policies;
* use panel-matched references so placement is not confounded with panel count;
* report drag, but never let AVL drag rank spanwise placement;
* predeclare the quantities and score used for acceptance.

Common commands
---------------

Fast, no AVL solve; produces paper figures from evidence already checked in:

    python standalone/lowfi_avl_study/unified_complexity_distribution_study.py \
        figures-existing

Small smoke campaign:

    python standalone/lowfi_avl_study/unified_complexity_distribution_study.py \
        run --quick

Full publication campaign (expensive):

    python standalone/lowfi_avl_study/unified_complexity_distribution_study.py \
        run --suite full
"""

from __future__ import annotations

import argparse
import dataclasses
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence

import numpy as np

REPO = Path(__file__).resolve().parents[2]
CONFIG = REPO / "configs" / "geometry" / "bwb.yaml"
DATA = REPO / "data" / "lowfi_avl_study" / "unified_complexity_distribution"
EVIDENCE = REPO / "configs" / "aero" / "unified_complexity_distribution_evidence"
FIGS = REPO / "studies" / "figures" / "unified_complexity_distribution"

STUDY_ID = "unified_complexity_distribution"
REF_FLOOR = 1.0e-4
RAMP_LIMIT = 0.15
SLIVER_MERGE_FRACTION = 0.25

CONTROL_Q = ("CL_de", "Cm_de", "Cl_da", "CY_da", "Cn_da")
CORE_Q = ("CL", "Cm", "Xnp", "CLa", "Cma", "Clp", "Cnb", "Cmq")
DRAG_Q = ("CDind", "cd_total", "e")
TRACKED_Q = CORE_Q + CONTROL_Q + DRAG_Q


@dataclass(frozen=True)
class PlacementPolicy:
    """One section-placement rule to test."""

    key: str
    label: str
    family: str
    hard_pins: bool = True
    gate: bool = False
    combine: str = "max"
    floor: float = 0.50
    control_weight: float = 3.0
    thickness_weight: float = 0.0
    use_control_channel: bool = True
    accept_only_if_ramp_improves: bool = True


POLICIES: dict[str, PlacementPolicy] = {
    "U0_uniform_no_pins": PlacementPolicy(
        "U0_uniform_no_pins", "U0 uniform, no pins", "uniform",
        hard_pins=False,
    ),
    "U1_uniform_pins": PlacementPolicy(
        "U1_uniform_pins", "U1 uniform + hard pins", "uniform",
        hard_pins=True,
    ),
    "C0_complexity_geom_only": PlacementPolicy(
        "C0_complexity_geom_only", "C0 complexity, geometry only", "complexity",
        hard_pins=True, gate=False, control_weight=0.0,
        use_control_channel=False,
    ),
    "C1_unified_complexity_auto": PlacementPolicy(
        "C1_unified_complexity_auto", "C1 unified complexity, gated", "complexity",
        hard_pins=True, gate=True, control_weight=3.0,
    ),
    "C2_unified_complexity_always": PlacementPolicy(
        "C2_unified_complexity_always", "C2 unified complexity, always", "complexity",
        hard_pins=True, gate=False, control_weight=3.0,
    ),
    "C3_complexity_thickness_on": PlacementPolicy(
        "C3_complexity_thickness_on", "C3 complexity, thickness on", "complexity",
        hard_pins=True, gate=False, control_weight=3.0, thickness_weight=1.0,
    ),
    "C4_complexity_sum_blend": PlacementPolicy(
        "C4_complexity_sum_blend", "C4 complexity, sum blend", "complexity",
        hard_pins=True, gate=False, combine="sum", control_weight=3.0,
    ),
}


@dataclass(frozen=True)
class FlightPoint:
    key: str
    alpha_deg: float
    de_deg: float = 4.0
    da_deg: float = 4.0
    beta_deg: float = 0.0
    velocity_mps: float = 28.0


QUICK_FLIGHT_POINTS = (FlightPoint("a6_de4_da4", 6.0, 4.0, 4.0),)
FULL_FLIGHT_POINTS = (
    FlightPoint("a-2_de4_da4", -2.0, 4.0, 4.0),
    FlightPoint("a0_de4_da4", 0.0, 4.0, 4.0),
    FlightPoint("a3_de4_da4", 3.0, 4.0, 4.0),
    FlightPoint("a6_de4_da4", 6.0, 4.0, 4.0),
    FlightPoint("a9_de4_da4", 9.0, 4.0, 4.0),
    FlightPoint("a12_de4_da4", 12.0, 4.0, 4.0),
)


def _mkdirs() -> None:
    DATA.mkdir(parents=True, exist_ok=True)
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    FIGS.mkdir(parents=True, exist_ok=True)


def _style(ax, title: str = "", xlabel: str = "", ylabel: str = "") -> None:
    if title:
        ax.set_title(title, fontsize=10.5, weight="bold")
    ax.set_xlabel(xlabel, fontsize=9)
    ax.set_ylabel(ylabel, fontsize=9)
    ax.grid(alpha=0.25, linewidth=0.6)
    ax.tick_params(labelsize=8)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)


def _load_geometry_context():
    from aeris.common.config import load_yaml_config
    from aeris.geometry.config_resolver import resolve_generator_and_config
    from aeris.geometry.registry import get_geometry_generator

    gid, gcfg = resolve_generator_and_config(load_yaml_config(CONFIG))
    gen = get_geometry_generator(gid)
    return gid, gcfg, gen


def _samples(suite: str) -> dict[str, Any]:
    gid, gcfg, gen = _load_geometry_context()
    del gid
    base = gen.sample_one(gcfg, seed=7000)
    cases: dict[str, Any] = {
        "nominal": base,
        "benign": dataclasses.replace(
            base,
            sw1_deg=-20.0,
            sw2_deg=-15.0,
            sw3_deg=-5.0,
            twist_b0_deg=0.0,
            twist_b1_deg=-0.5,
            twist_b2_deg=-1.5,
            twist_b3_deg=-2.0,
            dihedral_b2_deg=0.0,
            dihedral_b3_deg=0.0,
            c2_ratio=0.70,
            c3_ratio=0.45,
            c4_ratio=0.15,
            b_total_m=1.0,
            c1_m=0.9,
        ),
        "elevon_narrow": dataclasses.replace(
            base, elevon_start_frac=0.70, elevon_end_frac=0.85
        ),
        "elevon_wide": dataclasses.replace(
            base, elevon_start_frac=0.50, elevon_end_frac=0.98
        ),
        "hinge_min": dataclasses.replace(base, elevon_hinge_frac=0.65),
        "hinge_max": dataclasses.replace(base, elevon_hinge_frac=0.82),
        "max_gradient": dataclasses.replace(
            base,
            sw1_deg=-40.0,
            sw2_deg=-15.0,
            sw3_deg=-25.0,
            c2_ratio=0.80,
            c3_ratio=0.30,
            c4_ratio=0.08,
            twist_b0_deg=1.0,
            twist_b3_deg=-8.0,
            split_ratio=0.40,
            b3_ratio=0.55,
        ),
        "max_ar": dataclasses.replace(
            base, b_total_m=1.25, c1_m=0.70, c4_ratio=0.08, twist_b3_deg=-8.0
        ),
        "min_ar": dataclasses.replace(
            base, b_total_m=0.75, c1_m=1.10, c4_ratio=0.20
        ),
        "max_dihedral": dataclasses.replace(
            base, dihedral_b2_deg=6.0, dihedral_b3_deg=10.0
        ),
    }
    seeds = (1001, 1002) if suite == "quick" else (1001, 1002, 1010, 1020, 1030, 1040)
    for seed in seeds:
        cases[f"random_{seed}"] = gen.sample_one(gcfg, seed=seed)
    if suite == "quick":
        keep = ("nominal", "elevon_narrow", "max_gradient", "random_1001")
        return {k: cases[k] for k in keep}
    return cases


def _build_loft(sample: Any):
    from aeris.common.config import load_yaml_config
    from aeris.generators.bwb_segmented_v1.pygeo_adapter import (
        build_pygeo,
        stations_from_records,
    )
    from aeris.generators.bwb_segmented_v1.pygeo_backend import _resolve_airfoil_database
    from aeris.generators.bwb_segmented_v1.services import (
        build_section_geometry_from_sample,
        generate_bwb_planform_from_sample,
    )
    from aeris.geometry.config_resolver import resolve_generator_and_config

    gid, gcfg = resolve_generator_and_config(load_yaml_config(CONFIG))
    planform = generate_bwb_planform_from_sample(sample, gcfg)
    section_geometry = build_section_geometry_from_sample(planform, sample, gcfg)
    stations = tuple(
        stations_from_records(section_geometry.sections, _resolve_airfoil_database(gcfg))
    )
    frame_mode = "asb_frame" if gcfg.pygeo.frame_mode == "aeris_frame" else gcfg.pygeo.frame_mode
    build = build_pygeo(
        stations,
        k_span=gcfg.pygeo.k_span,
        frame_mode=frame_mode,
        n_ctl=gcfg.pygeo.n_ctl,
        tip=gcfg.pygeo.tip,
        tip_scale=gcfg.pygeo.tip_scale,
    )
    surfaces = getattr(gcfg.control_surfaces, "surfaces", None)
    control = None
    if surfaces:
        cs = surfaces[0]
        hinge = cs.hinge_point
        start = cs.spanwise.start_frac
        end = cs.spanwise.end_frac
        if getattr(gcfg, "elevon_bounds", None) is not None:
            hinge = float(getattr(sample, "elevon_hinge_frac", hinge))
            start = float(getattr(sample, "elevon_start_frac", start))
            end = float(getattr(sample, "elevon_end_frac", end))
        control = {
            "name": cs.name,
            "hinge_point": hinge,
            "symmetric": cs.symmetric,
            "start_frac": start,
            "end_frac": end,
        }
    return gcfg, build, control


def _feature_pins(sample: Any, control: dict[str, Any] | None, *, hard_pins: bool) -> list[float]:
    pins = [0.0, 1.0]
    if hard_pins:
        try:
            b3r = float(sample.b3_ratio)
            splt = float(sample.split_ratio)
            pins.extend([(1.0 - b3r) * splt, 1.0 - b3r])
        except (AttributeError, TypeError, ValueError):
            pass
        if control is not None:
            pins.extend([float(control["start_frac"]), float(control["end_frac"])])
    return sorted({round(float(v), 9) for v in pins if 0.0 <= float(v) <= 1.0})


def _is_pin(value: float, pins: Sequence[float]) -> bool:
    return any(abs(float(value) - float(pin)) < 1.0e-9 for pin in pins)


def _merge_pins(base: np.ndarray, pins: Sequence[float]) -> np.ndarray:
    if not pins:
        return np.unique(base)
    pin_arr = np.asarray(pins, dtype=float)
    uniform = 1.0 / max(1, len(base) - 1)
    tol = SLIVER_MERGE_FRACTION * uniform
    kept = [float(f) for f in base if not np.any(np.abs(pin_arr - f) < tol)]
    return np.unique(np.concatenate([np.asarray(kept, dtype=float), pin_arr]))


def _enforce_budget(fractions: Sequence[float], pins: Sequence[float], budget: int) -> np.ndarray:
    f = np.unique(np.asarray(list(fractions), dtype=float))
    budget = int(budget)
    while len(f) < budget:
        gaps = np.diff(f)
        k = int(np.argmax(gaps))
        f = np.insert(f, k + 1, 0.5 * (f[k] + f[k + 1]))
    while len(f) > budget:
        candidates = []
        for i in range(1, len(f) - 1):
            if _is_pin(float(f[i]), pins):
                continue
            local = min(float(f[i] - f[i - 1]), float(f[i + 1] - f[i]))
            candidates.append((local, i))
        if not candidates:
            raise ValueError(
                f"cannot enforce budget={budget}; {len(f)} points and all removable "
                "points are hard pins"
            )
        _, drop = min(candidates)
        f = np.delete(f, drop)
    return np.unique(f)


def _weights(policy: PlacementPolicy) -> dict[str, float]:
    from aeris.geometry.geometric_information import DEFAULT_CHANNEL_WEIGHTS

    weights = dict(DEFAULT_CHANNEL_WEIGHTS)
    weights["control_gain"] = float(policy.control_weight)
    weights["thickness"] = float(policy.thickness_weight)
    return weights


def sections_for_policy(
    sample: Any,
    policy: PlacementPolicy,
    *,
    budget: int,
    ramp_limit: float = RAMP_LIMIT,
) -> tuple[list[Any], float, dict[str, Any]]:
    from aeris.generators.bwb_segmented_v1.pygeo_adapter import extract_sections
    from aeris.geometry.geometric_information import (
        adaptive_span_fractions,
        ramp_fraction,
        spanwise_information_profile,
    )

    gcfg, build, control = _build_loft(sample)
    band = None
    if control is not None:
        band = (float(control["start_frac"]), float(control["end_frac"]))
    pins = _feature_pins(sample, control, hard_pins=policy.hard_pins)
    interior_pins = [p for p in pins if 0.0 < p < 1.0]
    n_base = int(budget) - len(interior_pins)
    n_base = max(2, n_base)
    fractions = np.linspace(0.0, 1.0, n_base)
    if policy.hard_pins:
        fractions = _merge_pins(fractions, pins)
    fractions = _enforce_budget(fractions, pins, budget)
    uniform_ramp = ramp_fraction(fractions, band) if band is not None else float("nan")
    placement_used = "uniform"
    profile_metadata: dict[str, Any] | None = None

    if policy.family == "complexity":
        should_adapt = (not policy.gate) or (
            band is not None and np.isfinite(uniform_ramp) and uniform_ramp > ramp_limit
        )
        if should_adapt:
            profile = spanwise_information_profile(
                build,
                n_probe=301,
                chordwise_probe=21,
                weights=_weights(policy),
                floor=policy.floor,
                combine=policy.combine,
                control_band=band if policy.use_control_channel else None,
            )
            adaptive = adaptive_span_fractions(profile, n_base, must_include=pins)
            adaptive = _enforce_budget(adaptive, pins, budget)
            adaptive_ramp = ramp_fraction(adaptive, band) if band is not None else float("nan")
            if (
                not policy.accept_only_if_ramp_improves
                or not np.isfinite(uniform_ramp)
                or adaptive_ramp <= uniform_ramp + 1.0e-12
            ):
                fractions = adaptive
                placement_used = "complexity"
            profile_metadata = {
                "combine": policy.combine,
                "floor": policy.floor,
                "weights": _weights(policy),
                "concentration": profile.concentration(),
                "channel_shares": profile.channel_shares(),
                "accepted": placement_used == "complexity",
                "adaptive_ramp": adaptive_ramp,
            }

    fractions = _enforce_budget(fractions, pins, budget)
    extracted = list(
        extract_sections(
            build,
            fractions,
            cst_order=gcfg.pygeo.extraction.cst_order,
            chordwise_points=gcfg.pygeo.extraction.chordwise_points,
        )
    )
    semispan = max(float(sec.y_m) for sec in extracted)
    final_ramp = ramp_fraction(fractions, band) if band is not None else float("nan")
    max_gap_ratio = float(np.max(np.diff(fractions)) / (1.0 / max(1, len(fractions) - 1)))
    meta = {
        "policy": policy.key,
        "policy_label": policy.label,
        "placement_used": placement_used,
        "n_sections": len(extracted),
        "fractions": [float(x) for x in fractions],
        "feature_pins": [float(x) for x in pins],
        "control": control,
        "ramp_fraction_uniform_before_adapt": uniform_ramp,
        "ramp_fraction": final_ramp,
        "max_gap_ratio": max_gap_ratio,
        "profile": profile_metadata,
    }
    return extracted, semispan, meta


def _extract_result(res: Any) -> dict[str, Any]:
    stability = res.stability_axis_derivatives or {}
    controls = res.control_derivatives or {}
    sym = next((v for k, v in controls.items() if k.endswith("_sym")), {})
    dif = next((v for k, v in controls.items() if k.endswith("_diff")), {})
    return {
        "status": res.status,
        "CL": res.cl,
        "CDind": res.cd_ind,
        "cd_total": res.cd_total,
        "Cm": res.cm,
        "e": res.span_efficiency,
        "Xnp": res.x_np,
        "CLa": stability.get("CLa"),
        "Cma": stability.get("Cma"),
        "Clp": stability.get("Clp"),
        "Cnb": stability.get("Cnb"),
        "Cmq": stability.get("Cmq"),
        "CL_de": sym.get("CL"),
        "Cm_de": sym.get("Cm"),
        "Cl_da": dif.get("Cl"),
        "CY_da": dif.get("CY"),
        "Cn_da": dif.get("Cn"),
        "n_strips": res.n_strips,
    }


def _run_one(
    sample: Any,
    policy: PlacementPolicy,
    flight: FlightPoint,
    *,
    budget: int,
    spanwise_panels: int,
    nchordwise: int,
    tag: str,
    timeout_sec: int,
) -> dict[str, Any]:
    from aeris.aero.models import FlightCondition
    from aeris.generators.bwb_segmented_v1.pygeo_avl_adapter import run_pygeo_native_avl_case

    sections, semispan, meta = sections_for_policy(sample, policy, budget=budget)
    fc = FlightCondition(
        alpha_deg=float(flight.alpha_deg),
        beta_deg=float(flight.beta_deg),
        velocity_mps=float(flight.velocity_mps),
        altitude_m=0.0,
    )
    res = run_pygeo_native_avl_case(
        flight_condition=fc,
        output_dir=DATA / "runs" / tag,
        extracted_sections=sections,
        semispan_m=semispan,
        control=meta["control"],
        control_input_deg=float(flight.de_deg),
        diff_input_deg=float(flight.da_deg),
        viscous=True,
        name="ucd",
        nchordwise=int(nchordwise),
        spanwise_panels_per_section=int(spanwise_panels),
        cspace=1.0,
        timeout_sec=int(timeout_sec),
    )
    out = _extract_result(res)
    out["meta"] = meta
    out["flight"] = dataclasses.asdict(flight)
    out["budget"] = int(budget)
    out["spanwise_panels_per_section"] = int(spanwise_panels)
    out["nchordwise"] = int(nchordwise)
    return out


def _errors(candidate: dict[str, Any], reference: dict[str, Any]) -> dict[str, Any]:
    relative: dict[str, float] = {}
    absolute: dict[str, float] = {}
    excluded: dict[str, str] = {}
    for q in TRACKED_Q:
        a = candidate.get(q)
        b = reference.get(q)
        if not isinstance(a, float) or not isinstance(b, float):
            excluded[q] = "missing"
            continue
        absolute[q] = abs(a - b)
        if abs(b) <= REF_FLOOR:
            excluded[q] = f"|reference| <= {REF_FLOOR:g}"
            continue
        denom = max(abs(a), abs(b))
        if denom <= 1.0e-30:
            excluded[q] = "zero denominator"
            continue
        relative[q] = abs(a - b) / denom
    return {"relative": relative, "absolute": absolute, "excluded": excluded}


def _worst(errs: dict[str, Any], quantities: Sequence[str]) -> float | None:
    vals = [
        float(errs["relative"][q])
        for q in quantities
        if q in errs.get("relative", {}) and math.isfinite(float(errs["relative"][q]))
    ]
    return max(vals) if vals else None


def _limits_ok(n_sections: int, spanwise_panels: int, nchordwise: int) -> tuple[bool, str]:
    total_strips = 2 * (int(n_sections) - 1) * int(spanwise_panels)
    vortices = total_strips * int(nchordwise)
    if total_strips > 500:
        return False, f"{total_strips} strips > AVL NSMAX=500"
    if vortices > 6000:
        return False, f"{vortices} vortices > AVL limit ~6000"
    return True, "ok"


def run_campaign(args: argparse.Namespace) -> dict[str, Any]:
    _mkdirs()
    suite = "quick" if args.quick else args.suite
    cases = _samples(suite)
    budgets = tuple(int(v) for v in args.budgets.split(","))
    flights = QUICK_FLIGHT_POINTS if args.quick else FULL_FLIGHT_POINTS
    selected_policies = [POLICIES[k] for k in args.policies.split(",")]
    reference_policy = POLICIES["U1_uniform_pins"]

    report: dict[str, Any] = {
        "study_id": STUDY_ID,
        "settings": {
            "suite": suite,
            "budgets": budgets,
            "candidate_spanwise_panels": args.spanwise_panels,
            "reference_rule": "reference_sections = 2 * budget - 1; reference_spanwise_panels = 2",
            "nchordwise": args.nchordwise,
            "ref_floor": REF_FLOOR,
            "ranking_quantities": {
                "core": CORE_Q,
                "control": CONTROL_Q,
                "reported_not_ranked": DRAG_Q,
            },
            "policies": {p.key: dataclasses.asdict(p) for p in selected_policies},
        },
        "cases": {},
        "failures": [],
    }
    for case_name, sample in cases.items():
        print(f"\nCASE {case_name}")
        case_entry = report["cases"].setdefault(case_name, {"budgets": {}})
        for budget in budgets:
            ref_sections = 2 * int(budget) - 1
            ref_panels = max(1, int(args.spanwise_panels) // 2)
            ok, reason = _limits_ok(ref_sections, ref_panels, args.nchordwise)
            if not ok:
                report["failures"].append(
                    {"case": case_name, "budget": budget, "reference": reason}
                )
                print(f"  budget {budget}: reference skipped: {reason}")
                continue
            budget_entry = case_entry["budgets"].setdefault(str(budget), {"flights": {}})
            for flight in flights:
                print(f"  budget {budget:>2}  {flight.key}")
                ref_tag = f"{case_name}/b{budget}/{flight.key}/reference_uniform_pins"
                reference = _run_one(
                    sample,
                    reference_policy,
                    flight,
                    budget=ref_sections,
                    spanwise_panels=ref_panels,
                    nchordwise=args.nchordwise,
                    tag=ref_tag,
                    timeout_sec=args.timeout,
                )
                if reference.get("status") != "SUCCESS":
                    report["failures"].append(
                        {
                            "case": case_name,
                            "budget": budget,
                            "flight": flight.key,
                            "reference_status": reference.get("status"),
                        }
                    )
                    continue
                flight_entry = budget_entry["flights"].setdefault(
                    flight.key, {"reference": reference, "policies": {}}
                )
                for policy in selected_policies:
                    ok, reason = _limits_ok(budget, args.spanwise_panels, args.nchordwise)
                    if not ok:
                        report["failures"].append(
                            {
                                "case": case_name,
                                "budget": budget,
                                "flight": flight.key,
                                "policy": policy.key,
                                "reason": reason,
                            }
                        )
                        continue
                    tag = f"{case_name}/b{budget}/{flight.key}/{policy.key}"
                    got = _run_one(
                        sample,
                        policy,
                        flight,
                        budget=budget,
                        spanwise_panels=args.spanwise_panels,
                        nchordwise=args.nchordwise,
                        tag=tag,
                        timeout_sec=args.timeout,
                    )
                    got["errors"] = _errors(got, reference)
                    got["score"] = {
                        "worst_core": _worst(got["errors"], CORE_Q),
                        "worst_control": _worst(got["errors"], CONTROL_Q),
                        "worst_ranked": _worst(got["errors"], CORE_Q + CONTROL_Q),
                        "worst_drag_reported": _worst(got["errors"], DRAG_Q),
                    }
                    flight_entry["policies"][policy.key] = got
    report["summary"] = summarise_report(report)
    out = DATA / "unified_complexity_distribution.json"
    out.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
    (EVIDENCE / out.name).write_text(out.read_text(encoding="utf-8"), encoding="utf-8")
    return report


def summarise_report(report: dict[str, Any]) -> dict[str, Any]:
    rows: dict[str, dict[str, list[float]]] = {}
    for case in report.get("cases", {}).values():
        for budget in case.get("budgets", {}).values():
            for flight in budget.get("flights", {}).values():
                for key, run in flight.get("policies", {}).items():
                    score = run.get("score", {})
                    item = rows.setdefault(
                        key,
                        {"core": [], "control": [], "ranked": [], "drag": [], "ramp": []},
                    )
                    for dst, src in (
                        ("core", "worst_core"),
                        ("control", "worst_control"),
                        ("ranked", "worst_ranked"),
                        ("drag", "worst_drag_reported"),
                    ):
                        val = score.get(src)
                        if isinstance(val, float) and math.isfinite(val):
                            item[dst].append(val)
                    ramp = run.get("meta", {}).get("ramp_fraction")
                    if isinstance(ramp, float) and math.isfinite(ramp):
                        item["ramp"].append(ramp)
    out: dict[str, Any] = {}
    for key, vals in rows.items():
        out[key] = {}
        for name, arr in vals.items():
            a = np.asarray(arr, dtype=float)
            if not a.size:
                continue
            out[key][name] = {
                "n": int(a.size),
                "mean": float(np.mean(a)),
                "median": float(np.median(a)),
                "p90": float(np.percentile(a, 90)),
                "max": float(np.max(a)),
            }
    return out


def _load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def figures_from_existing() -> None:
    """Produce paper-ready figures using the evidence already in the repository."""
    _mkdirs()
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    placement = _load_json(
        REPO / "configs" / "aero" / "placement_decision_evidence" / "placement_decision.json"
    )
    neutrality = _load_json(
        REPO / "configs" / "aero" / "placement_audit_evidence" / "reference_neutrality.json"
    )
    audit = _load_json(
        REPO / "configs" / "aero" / "placement_audit_evidence" / "placement_audit.json"
    )

    # 01: why drag is reported but not ranked.
    fig, ax = plt.subplots(figsize=(7.3, 4.4))
    for name, color, marker in (
        ("nominal", "#1f4e79", "o"),
        ("elevon_narrow", "#c0392b", "s"),
    ):
        data = neutrality[name]
        sections = sorted(int(k) for k in data)
        drag = [data[str(n)]["drag"] * 100 for n in sections]
        ctrl = [data[str(n)]["ctrl"] * 100 for n in sections]
        ax.plot(sections, drag, "-" + marker, color=color, lw=1.9, ms=7, label=f"{name}: drag")
        ax.plot(sections, ctrl, "--" + marker, color=color, lw=1.4, ms=5, alpha=0.65,
                label=f"{name}: control")
    ax.axhspan(0.0, 0.5, color="#1f6f4a", alpha=0.12)
    ax.text(51, 0.16, "below approximate 0.5 percentage-point policy effect",
            fontsize=8, color="#1f6f4a")
    _style(
        ax,
        "Reference-neutrality audit: AVL drag cannot rank spanwise placement",
        "reference sections",
        "reference self-disagreement [%]",
    )
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(FIGS / "01_drag_reference_neutrality.png", dpi=180)
    plt.close(fig)

    # 02: policy ranking on admissible, non-drag quantities.
    labels = {
        "A_uniform_no_pins": "uniform\nno pins",
        "B_uniform_pinned": "uniform\n+ pins",
        "C_adopted_auto": "unified complexity\n gated",
        "D_adopted_always": "unified complexity\n always",
    }
    colors = {
        "A_uniform_no_pins": "#b0b7c3",
        "B_uniform_pinned": "#5d83ab",
        "C_adopted_auto": "#1f6f4a",
        "D_adopted_always": "#c07a2c",
    }
    policies = list(labels)
    x = np.arange(len(policies))
    max_ctrl = [placement["summary"][p]["max_ctrl"] * 100 for p in policies]
    mean_ctrl = [placement["summary"][p]["mean_ctrl"] * 100 for p in policies]
    fig, ax = plt.subplots(figsize=(7.8, 4.4))
    ax.bar(x - 0.18, max_ctrl, 0.36, color=[colors[p] for p in policies], label="worst case")
    ax.bar(x + 0.18, mean_ctrl, 0.36, color=[colors[p] for p in policies], alpha=0.45,
           label="mean")
    for i, val in enumerate(max_ctrl):
        ax.text(i - 0.18, val + 0.45, f"{val:.2f}%", ha="center", fontsize=8, weight="bold")
    _style(
        ax,
        "Equal 25-section budget: pins dominate, complexity improves the tail",
        "",
        "control-derivative error [%]",
    )
    ax.set_xticks(x)
    ax.set_xticklabels([labels[p] for p in policies])
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(FIGS / "02_policy_ranking_control.png", dpi=180)
    plt.close(fig)

    # 03: per-case view, because reviewers will ask whether one geometry drives it.
    case_names = list(placement["cases"])
    x = np.arange(len(case_names))
    width = 0.2
    fig, ax = plt.subplots(figsize=(11.5, 4.6))
    for i, p in enumerate(policies):
        vals = [
            placement["cases"][c]["approaches"][p]["worst_control"] * 100
            for c in case_names
        ]
        ax.bar(
            x + (i - 1.5) * width,
            vals,
            width,
            color=colors[p],
            label=labels[p].replace("\n", " "),
        )
    _style(
        ax,
        "Per-geometry control error: the claim is tail-risk reduction, not dominance",
        "",
        "worst control-derivative error [%]",
    )
    ax.set_xticks(x)
    ax.set_xticklabels(case_names, rotation=22, ha="right")
    ax.legend(frameon=False, fontsize=8, ncol=4)
    fig.tight_layout()
    fig.savefig(FIGS / "03_per_case_control_error.png", dpi=180)
    plt.close(fig)

    # 04: budget sweep for the hard case.
    test2 = audit["test2"]
    fig, ax = plt.subplots(figsize=(7.2, 4.2))
    for name, color in (
        ("nominal", "#5d83ab"),
        ("elevon_narrow", "#1f6f4a"),
        ("max_gradient", "#c07a2c"),
        ("random_1001", "#7b6ba8"),
    ):
        data = test2[name]
        budgets = sorted(int(k) for k in data)
        b = [data[str(n)]["B"]["ctrl"] * 100 for n in budgets]
        c = [data[str(n)]["C"]["ctrl"] * 100 for n in budgets]
        ax.plot(budgets, b, "--o", color=color, alpha=0.42, lw=1.3, ms=5)
        ax.plot(budgets, c, "-o", color=color, lw=1.8, ms=5, label=f"{name}: complexity")
    _style(
        ax,
        "Budget sweep: adaptive pays where the elevon ramp is severe",
        "final section budget",
        "worst control error [%]",
    )
    ax.set_yscale("log")
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(FIGS / "04_budget_sweep_control.png", dpi=180)
    plt.close(fig)

    # 05 and 06 need pyGeo, but no AVL. If pyGeo is unavailable, the data figures
    # above are still produced.
    try:
        fig_unified_complexity_anatomy()
        fig_section_grids()
    except Exception as exc:  # pragma: no cover - environment-dependent figure
        (FIGS / "PYGEO_FIGURE_WARNING.txt").write_text(
            f"Skipped pyGeo-dependent method figures: {exc}\n", encoding="utf-8"
        )
        print(f"skipped pyGeo-dependent method figures: {exc}")

    print(f"figures -> {FIGS}")


def fig_unified_complexity_anatomy() -> None:
    import dataclasses as _dataclasses

    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    from aeris.geometry.geometric_information import spanwise_information_profile

    _, gcfg, gen = _load_geometry_context()
    base = gen.sample_one(gcfg, seed=7000)
    sample = _dataclasses.replace(base, elevon_start_frac=0.70, elevon_end_frac=0.85)
    policy = POLICIES["C2_unified_complexity_always"]
    sections, _, meta = sections_for_policy(sample, policy, budget=25)
    del sections
    _, build, control = _build_loft(sample)
    band = (float(control["start_frac"]), float(control["end_frac"]))
    profile = spanwise_information_profile(
        build,
        n_probe=301,
        chordwise_probe=21,
        weights=_weights(policy),
        floor=policy.floor,
        combine=policy.combine,
        control_band=band,
    )
    y = np.asarray(profile.span_fraction)
    fig, axes = plt.subplots(3, 1, figsize=(9.2, 8.8), sharex=True)
    ax = axes[0]
    for name, ch in profile.channels.items():
        values = np.asarray(ch.values, dtype=float)
        span = float(np.max(values) - np.min(values))
        if span <= 1.0e-12:
            continue
        ax.plot(y, (values - np.min(values)) / span, lw=1.3, label=name)
    for pin in meta["feature_pins"]:
        ax.axvline(pin, color="#c07a2c", ls=":", lw=0.8)
    ax.axvspan(band[0], band[1], color="#c0392b", alpha=0.08)
    _style(ax, "Inputs to the unified spanwise complexity metric", "", "channel value, rescaled")
    ax.legend(frameon=False, fontsize=7, ncol=4)

    ax = axes[1]
    density = np.asarray(profile.density)
    ax.fill_between(y, 0, density, color="#6b8fb5", alpha=0.35)
    ax.plot(y, density, color="#1f4e79", lw=1.8)
    ax.axhline(policy.floor, color="#c07a2c", ls="--", lw=1.1)
    ax.axvspan(band[0], band[1], color="#c0392b", alpha=0.08)
    _style(ax, "Unified complexity density: worst active channel, floor = 0.50", "", "density")

    ax = axes[2]
    fractions = np.asarray(meta["fractions"], dtype=float)
    uniform = np.linspace(0.0, 1.0, len(fractions))
    ax.plot(uniform, np.ones_like(uniform), "|", color="#888", ms=24, mew=1.8,
            label="uniform")
    ax.plot(fractions, np.zeros_like(fractions) + 0.62, "|", color="#1f6f4a",
            ms=24, mew=1.8, label="unified complexity")
    for pin in meta["feature_pins"]:
        ax.plot([pin], [0.62], "v", color="#c07a2c", ms=6)
    ax.set_ylim(0.35, 1.25)
    ax.set_yticks([])
    _style(ax, "Resulting 25-section distribution", "span fraction", "")
    ax.legend(frameon=False, fontsize=8, ncol=3)

    fig.tight_layout()
    fig.savefig(FIGS / "05_unified_complexity_metric_anatomy.png", dpi=180)
    plt.close(fig)


def fig_section_grids() -> None:
    import dataclasses as _dataclasses

    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    _, gcfg, gen = _load_geometry_context()
    base = gen.sample_one(gcfg, seed=7000)
    samples = {
        "nominal": base,
        "narrow elevon": _dataclasses.replace(
            base, elevon_start_frac=0.70, elevon_end_frac=0.85
        ),
    }
    policies = [POLICIES["U1_uniform_pins"], POLICIES["C1_unified_complexity_auto"]]
    fig, axes = plt.subplots(2, 2, figsize=(11.5, 5.8), sharex="col")
    for row, (case_name, sample) in enumerate(samples.items()):
        for policy in policies:
            _, _, meta = sections_for_policy(sample, policy, budget=25)
            fractions = np.asarray(meta["fractions"], dtype=float)
            y = 1.0 if policy.key == "U1_uniform_pins" else 0.62
            axes[row, 0].plot(
                fractions,
                np.zeros_like(fractions) + y,
                "|",
                ms=24,
                mew=1.8,
                label=policy.label,
            )
            axes[row, 1].step(
                fractions[:-1],
                np.diff(fractions),
                where="post",
                lw=1.7,
                label=f"{policy.label}; ramp {meta['ramp_fraction'] * 100:.1f}%",
            )
        _, _, meta0 = sections_for_policy(sample, policies[0], budget=25)
        band = (float(meta0["control"]["start_frac"]), float(meta0["control"]["end_frac"]))
        for ax in axes[row]:
            ax.axvspan(band[0], band[1], color="#c0392b", alpha=0.08)
        axes[row, 0].set_ylim(0.35, 1.25)
        axes[row, 0].set_yticks([])
        _style(axes[row, 0], case_name, "", "")
        _style(axes[row, 1], f"{case_name}: local spacing", "", "Delta span")
        axes[row, 0].legend(frameon=False, fontsize=7)
        axes[row, 1].legend(frameon=False, fontsize=7)
    axes[-1, 0].set_xlabel("span fraction")
    axes[-1, 1].set_xlabel("span fraction")
    fig.suptitle("What the gated unified-complexity rule changes, and when it changes nothing",
                 fontsize=11.5, weight="bold")
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(FIGS / "06_section_grids_uniform_vs_complexity.png", dpi=180)
    plt.close(fig)


def figures_from_report(report_path: Path | None = None) -> None:
    _mkdirs()
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    path = report_path or DATA / "unified_complexity_distribution.json"
    report = _load_json(path)
    summary = report.get("summary", {})
    if not summary:
        raise ValueError(f"{path} has no summary; run the study first")
    keys = sorted(summary)
    labels = [POLICIES.get(k, PlacementPolicy(k, k, "unknown")).label for k in keys]
    p90 = [summary[k]["control"]["p90"] * 100 for k in keys]
    maxv = [summary[k]["control"]["max"] * 100 for k in keys]
    fig, ax = plt.subplots(figsize=(9.5, 4.6))
    x = np.arange(len(keys))
    ax.bar(x - 0.18, p90, 0.36, label="p90 control", color="#5d83ab")
    ax.bar(x + 0.18, maxv, 0.36, label="max control", color="#1f6f4a")
    _style(ax, "Unified complexity distribution study summary", "", "relative error [%]")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=20, ha="right")
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(FIGS / "20_full_study_summary.png", dpi=180)
    plt.close(fig)
    print(f"figures -> {FIGS}")


def rescue_latest() -> None:
    _mkdirs()
    src = DATA / "unified_complexity_distribution.json"
    if src.exists():
        (EVIDENCE / src.name).write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
    # Figures live under studies/figures; do not duplicate large binary files into
    # configs. Leave the README as the durable index instead.
    (EVIDENCE / "README.md").write_text(evidence_readme(), encoding="utf-8")
    print(f"evidence -> {EVIDENCE}")


def evidence_readme() -> str:
    return """# Evidence — unified complexity section-distribution study

This folder is reserved for the publication-grade section-distribution campaign
implemented by `standalone/lowfi_avl_study/unified_complexity_distribution_study.py`.

The study is intentionally separate from the earlier placement decision evidence.
Its ranking score excludes AVL drag (`CDind`, `cd_total`, `e`) because the
reference-neutrality audit showed the drag reference disagrees with itself by
roughly 1-3% depending on spanwise station placement. Drag is still reported as a
diagnostic.

Figures are written to `studies/figures/unified_complexity_distribution/`.
"""


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)

    run = sub.add_parser("run", help="run the new AVL campaign")
    run.add_argument("--quick", action="store_true", help="small smoke suite")
    run.add_argument("--suite", choices=("quick", "full"), default="full")
    run.add_argument("--budgets", default="11,15,19,25,33")
    run.add_argument("--policies", default=",".join(POLICIES))
    run.add_argument("--spanwise-panels", type=int, default=4)
    run.add_argument("--nchordwise", type=int, default=12)
    run.add_argument("--timeout", type=int, default=900)

    sub.add_parser("figures-existing", help="make paper figures from existing evidence")

    figs = sub.add_parser("figures", help="make figures from this study's JSON")
    figs.add_argument("--report", type=Path, default=None)

    sub.add_parser("rescue", help="copy latest JSON/README to configs evidence folder")
    return p


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "run":
        report = run_campaign(args)
        figures_from_report(DATA / "unified_complexity_distribution.json")
        print(json.dumps(report.get("summary", {}), indent=2))
    elif args.command == "figures-existing":
        figures_from_existing()
        rescue_latest()
    elif args.command == "figures":
        figures_from_report(args.report)
    elif args.command == "rescue":
        rescue_latest()
    else:  # pragma: no cover
        raise AssertionError(args.command)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
