# Discretisation of a Vortex-Lattice Model for Blended-Wing-Body Design-Space Exploration

### Choosing geometry sections and aerodynamic panels, and four rules for deciding such things honestly

**AERIS project — low-fidelity aerodynamic chain**
Consolidated 2026-07-26. Supersedes and unifies
`section_and_panel_convergence.md`, `hinge_panel_alignment.md`,
`discretisation_master_study.md`, `adaptive_section_placement.md`,
`dse_panelling_cost_accuracy.md`, `section_placement_decision.md`.
Decisions of record: **0009, 0010, 0012, 0013, 0014**.

---

## Abstract

A vortex-lattice aerodynamic model of a blended-wing-body UAV requires two
independent discretisation choices: how many spanwise **sections** describe the
lofted geometry, and how many aerodynamic **panels** the solver places on it. These
are routinely conflated. We separate them by construction and study each in turn.

We find that (i) 25 geometry sections converge the forces and stability derivatives
to 0.56%, (ii) 4 spanwise panels per section interval converge them to 0.54%, and
(iii) the chordwise panel count governs one class of quantity only — the control
derivatives — and does so through the number of panels landing aft of the hinge
rather than through hinge/panel-edge alignment, an initial hypothesis we tested and
rejected. Chordwise error follows `error ~ N_flap^−1.47` (R² = 0.966).

Solver cost is approximately cubic in vortex count, and the previously adopted
setting placed the model at 77% of AVL's compiled array limit, costing 58 s per
design point and making a 2000-design sweep 6.7 days. We show the resulting penalty
of a cheaper mesh is a **near-pure multiplicative bias** (spread across seven
geometries = 0.2% of the bias), which cancels under ranking, and therefore adopt a
two-tier scheme: 12 chordwise panels for exploration (14.6 s/point), 24 for
verification.

For section placement we show that hard feature pins — nodes forced exactly onto
planform kinks and control-surface edges — account for almost the entire effect,
reducing worst-case error from 34.54% to 1.98%. A curvature-based information
metric, applied under a gate, further improves the worst case to 1.68%, the median
control-derivative error to 0.418%, and its 90th percentile to 1.368%. Swept across
angle of attack, the gated rule holds a factor of three on elevon authority at
every α on the geometry where it engages, at the cost of a pitching-moment offset
equivalent to 0.05° of trim.

Finally, we report four methodological rules that emerged from errors made during
the work, each of which invalidated a result before it was caught: an
**admissibility floor** on relative error, covering both small references and
zero crossings; a **bias-versus-scatter** test for cheap tiers; a
**reference-neutrality audit**, which establishes that AVL's induced drag can never
rank spanwise discretisation; and **panel-matched reference construction**.

---

## Nomenclature

Every term is defined here before it is used. Terms marked † are this project's
vocabulary, not standard AVL terminology.

| term | meaning |
|---|---|
| **AVL** | Athena Vortex Lattice (Drela & Youngren). Models the wing as a *mean surface* — it sees camber and never sees thickness. |
| **section** | A spanwise station at which the geometry is defined: an aerofoil, chord, twist, and leading-edge position. Geometry input. |
| **panel / vortex** | One element of the aerodynamic lattice AVL builds *between* sections. Solver discretisation. |
| **strip** | One spanwise column of panels. AVL's limit is 500 strips (`NSMAX`). |
| **vortex count** | `2 × (n_sections − 1) × spanwise_panels × nchordwise`. AVL's limit is ≈6000. |
| **`nchordwise`** | Panels along the chord of each strip. |
| **`cspace`** | Chordwise spacing rule. 1.0 = cosine (bunched at the leading edge); 0.0 = uniform. |
| **band** † | The pair of span fractions between which the elevon exists, e.g. 0.60 → 0.95. |
| **gain ramp** † | AVL interpolates control gain linearly between sections. The intervals just *outside* each band edge therefore carry a partly-deflected control surface that does not physically exist. |
| **ramp fraction** † | (total width of those two intervals) ÷ (band width). The quantity DECISION-0010 identified as governing control error. |
| **span-margin** † | How far in from root and tip section placement stops. Non-zero means the physical tip is never modelled. |
| **feature pin** † | A span fraction at which a section is *forced* to exist: a planform kink or a control-surface edge. |
| **N_flap** | Number of chordwise panels landing aft of the hinge line. |
| **DSE** | Design-space exploration: sweeping many candidate designs to rank them. |
| **CDCL** | AVL's per-section viscous drag polar, supplied here by NeuralFoil. |

**Coefficients.** `CL` lift, `Cm` pitching moment, `CDind` induced drag,
`cd_total` total drag, `e` span efficiency, `Xnp` neutral point, `CLa`/`Cma`
lift/moment slope, `Clp` roll damping, `Cnb` yaw stiffness, `Cmq` pitch damping.
Control derivatives: `CL_δe`, `Cm_δe` (symmetric elevon = pitch), `Cl_δa`, `CY_δa`,
`Cn_δa` (differential elevon = roll).

---

## 1. Introduction

### 1.1 The problem

The aircraft is a blended-wing-body UAV. Its outer mould line is a pyGeo B-spline
loft; its low-fidelity aerodynamics come from AVL with a NeuralFoil viscous
correction. The design pipeline must evaluate thousands of candidate geometries.

Two numbers must be chosen before any of that runs:

1. **How many sections** describe the loft to the solver. Too few and the geometry
   the solver sees is not the geometry that was designed.
2. **How many panels** the solver puts on those sections. Too few and the flow
   solution is under-resolved.

These are different questions with different answers, and they are almost always
studied together — a "grid convergence study" that refines both at once cannot say
which one mattered.

### 1.2 Why this is not a routine convergence study

Three features make it harder than the textbook case.

**The control surface is the sensitive quantity.** For an aircraft whose only
control effectors are elevons, control authority is a *sizing* output, not a
by-product. It is also, as we show, the quantity that converges last by a wide
margin — every other coefficient is converged long before it.

**The solver has hard array limits, and fails silently at them.** AVL is compiled
with fixed arrays. Exceeding them does not raise an error; it returns a run with
every coefficient `None`.

**Cost is nonlinear in the choice.** AVL factorises a dense influence matrix, so
cost grows roughly with the cube of the vortex count. A discretisation chosen on
accuracy alone can silently make the tool unusable for its actual purpose.

### 1.3 Contributions

1. A **separated** convergence study: geometry sections and solver panels resolved
   independently (§4).
2. The **control-resolution criterion**: chordwise requirements are set by `N_flap`,
   the panel count aft of the hinge, not by hinge/panel-edge alignment — an initial
   hypothesis we published and then retracted on evidence (§4.3).
3. A **two-tier cost/accuracy scheme** for exploration versus verification,
   justified by a bias-versus-scatter test rather than by an error threshold (§5).
4. **Hard feature pins** and a gated curvature-based placement rule (§6).
5. **Four methodological rules** for discretisation studies, each derived from a
   mistake that invalidated a result before it was caught (§7).

---

## 2. Model and configuration

Geometry: pyGeo B-spline loft, order `k_span = 3`, sections extracted as CST
aerofoils. Planform is four segments with two interior kinks. One physical elevon
per side, emitted as two AVL controls on a shared hinge (`_sym` with `SgnDup = +1`,
`_diff` with `SgnDup = −1`), so that right = δe + δa and left = δe − δa.

Flow condition unless stated: α = 6°, β = 0°, V = 28 m/s, sea level, elevon
δe = δa = 4°, viscous correction on.

Symmetry via `YDUPLICATE`; therefore `span_margin = 0.0`, since any inset both
removes the physical tip and opens a gap at the centreline.

---

## 3. Method

### 3.1 Separation by construction

To study **sections**, the panel density is held fixed and the section count varied.
To study **panels**, the section count is held fixed and panels varied. Neither
sweep is permitted to move the other quantity — a constraint that turns out to be
harder to honour than it sounds (§7.4).

### 3.2 Error definition

All errors are **relative to a finer mesh of the same geometry in the same solver**:

    error(q) = |q_candidate − q_reference| / max(|q_candidate|, |q_reference|)

This measures *discretisation convergence*. It is not a claim of physical accuracy;
no wind-tunnel or CFD comparison is made anywhere in this paper.

Two other reference types appear in the wider project and are named where used:
closed-form physics (e.g. lifting-line `CLa = 2πAR/(AR+2)`) and cross-code
comparison against an independent AVL wrapper.

### 3.3 Admissibility of a relative error

A relative error is only reported when

    |q_reference| > 1e-4

i.e. 100× AVL's printed resolution of 1e−6. §7.1 explains why, and what it cost to
learn.

---

## 4. Results: how much discretisation is needed

### 4.1 Geometry sections

Panels fixed; section count varied. Reference: 65 sections.

| n_sections | worst force/stability field | worst error | CL_δe error |
|---|---|---|---|
| 5 | CDind | 15.5% | 52.4% |
| 7 | Cnb | 7.01% | 24.1% |
| 9 | Cnb | 4.94% | 14.8% |
| 13 | CDind | 1.94% | 0.33% |
| 17 | CDind | 0.72% | 1.55% |
| **25** | e | **0.56%** | 1.46% |
| 33 | cd_profile | 0.51% | 0.36% |

Forces and stability derivatives converge smoothly and are inside 0.6% by 25
sections. **The elevon derivative does not converge monotonically** — it is 0.33% at
13 sections and 1.46% at 25. This is not noise: it is the first appearance of the
mechanism that dominates the rest of the paper. Whether a section happens to land
near a band edge changes the gain ramp, and the gain ramp changes the control
derivative. Section *count* is the wrong control variable for that quantity;
section *placement* is the right one (§6).

**Adopted: `n_sections = 25`.**

### 4.2 Spanwise panels

Sections fixed at 25; spanwise panels per interval varied.

| panels/interval | strips per side | worst field | worst error |
|---|---|---|---|
| 1 | 24 | Clp | 2.85% |
| 2 | 48 | Clp | 1.29% |
| 3 | 72 | Clp | 0.75% |
| **4** | **96** | Cnb | **0.54%** |
| 6 | 144 | Cnb | 0.30% |
| 8 | 192 | cd_profile | 0.36% |

Converged and cheap. **Adopted: 4.**

### 4.3 Chordwise panels, and a hypothesis we had to discard

The chordwise grid is the dominant error source, and it acts almost entirely on the
control derivatives.

**The hypothesis.** The elevon hinge sits at 75% chord. With cosine spacing, panel
edges cluster at the leading edge, so the hinge generally falls *between* two edges.
It seemed self-evident that the offending quantity was the hinge-to-nearest-edge
distance, and we published that explanation.

**The test.** Correlating hinge/edge distance against `CL_δe` error, within each
chordwise level so the comparison is like-for-like:

| nchordwise | corr(edge distance, error) | corr(N_flap, error) |
|---|---|---|
| 8 | +0.611 | −0.718 |
| 16 | +0.077 | −0.865 |
| 24 | **−0.040** | **−0.972** |
| 32 | −0.163 | −0.966 |

The alignment correlation is inconsistent in both magnitude and **sign** — it
cannot be a mechanism. The count of panels aft of the hinge correlates strongly and
consistently. **The hypothesis was wrong and is retracted.**

**What actually governs it.** Fitting across hinge positions and panel counts:

    CL_δe error ~ N_flap^(−1.47),  R² = 0.966

| nchordwise | N_flap at hinge 0.814 | CL_δe error |
|---|---|---|
| 8 | 2 | 8.73% |
| 16 | 4 | 3.69% |
| **24** | **6** | **1.76%** |
| 32 | 9 | 0.76% |

> **The control-resolution criterion (DECISION-0010).** Resolve the *control
> surface*, not the wing: require **N_flap ≥ 6** chordwise panels aft of the hinge.
> This replaces any tuned panel count, and it transfers across hinge positions,
> which a tuned count does not.

**Cosine spacing is retained.** Uniform spacing puts an edge exactly on the hinge
and roughly halves the elevon error — but it degrades the neutral point and pitch
damping by 14–15×:

| quantity | cosine-8 | uniform-8 | penalty |
|---|---|---|---|
| Xnp | 3.6e−4 | 5.1e−3 | **14× worse** |
| Cmq | 3.2e−4 | 4.7e−3 | **15× worse** |
| CL | 1.37% | 2.29% | 1.7× worse |

Trading a factor of two on one derivative for a factor of fifteen on two others is
not a trade worth making. **Adopted: `cspace = 1.0`.**

---

## 5. Results: what the discretisation costs, and the two-tier scheme

### 5.1 The solver is the entire cost

Timing one design point at the previously adopted setting (25 sections, 4 spanwise,
24 chordwise):

| stage | time |
|---|---|
| pyGeo loft + extract 25 sections | 1.36 s |
| NeuralFoil viscous correction | 0.60 s |
| **AVL solve** | **56.93 s** |

![stage breakdown](figures/dse_panelling/03_stage_breakdown.png)

The intuitive suspects — B-spline lofting, 25 neural-network polar evaluations —
are innocent. There is no point optimising them.

### 5.2 Why the solver is slow here

AVL builds a dense influence matrix over all vortices and factorises it, so cost
scales between N² (matrix build) and N³ (factorisation). The adopted mesh was
192 strips × 24 chordwise = **4608 vortices, 77% of AVL's ≈6000 limit**. AVL is
sized for meshes in the hundreds to low thousands. We were running it at its
ceiling on every design point and then concluding that AVL is slow.

![vortex scaling](figures/dse_panelling/02_vortex_scaling.png)

### 5.3 The cost/accuracy curve

Reference: 30 chordwise (the richest *legal* mesh at this spanwise resolution; 32
would be 6144 vortices).

| nchordwise | vortices | time | speedup | worst error | which quantity |
|---|---|---|---|---|---|
| 4 | 768 | 1.8 s | 48× | 15.94% | CL_δe |
| 6 | 1152 | 3.7 s | 23.5× | 10.22% | CL_δe |
| 8 | 1536 | 6.9 s | 12.6× | 7.41% | CL_δe |
| **12** | **2304** | **14.6 s** | **5.9×** | **3.76%** | **CL_δe** |
| 16 | 3072 | 25.4 s | 3.4× | 1.79% | CL_δe |
| 24 | 4608 | 57.3 s | 1.5× | 0.62% | CL_δe |

![cost accuracy tradeoff](figures/dse_panelling/01_cost_accuracy_tradeoff.png)

**Every setting's worst error is a control derivative.** `Xnp` reads 0.3350 at every
setting from 6 panels upward — the neutral point is fully converged by six chordwise
panels. `CL` and `Cm` are inside 0.7% at 12.

![which quantity needs panels](figures/dse_panelling/04_which_quantity_needs_panels.png)

The expensive panels buy **one class of quantity**, not general accuracy.

### 5.4 Is a cheap mesh admissible for design-space exploration?

A 3.76% error is tolerable in a DSE **only if it is a consistent bias rather than
scatter**. A bias shifts every design by nearly the same factor and cancels when
designs are ranked; scatter reorders them and makes the sweep worthless.

`CL_δe` rises monotonically with panel count (0.00983 → 0.01163), the signature of a
bias. Tested directly across seven geometries by the ratio cheap/rich:

| quantity | mean ratio 12/24 | bias | spread across geometries | spread as % of bias |
|---|---|---|---|---|
| CL | 0.9967 | 0.33% | 0.0032 | 1.0% |
| Cm | 0.9955 | 0.45% | 0.0041 | 0.9% |
| Xnp | 1.0000 | 0.00% | 0.0005 | — |
| CLa | 1.0000 | 0.00% | 0.0004 | — |
| Cmq | 1.0000 | 0.00% | 0.0004 | — |
| **CL_δe** | **0.9689** | **3.11%** | **0.0066** | **0.2%** |
| **Cm_δe** | **0.9712** | **2.88%** | **0.0077** | **0.3%** |

![bias not scatter](figures/dse_panelling/05_bias_not_scatter.png)

The control-derivative penalty is a **near-pure multiplicative bias**: across seven
very different geometries the spread is 0.2–0.3% of the bias itself. The cheap mesh
underestimates elevon authority by a consistent ~3.1% regardless of shape.

### 5.5 The two-tier scheme

| tier | nchordwise | cost/point | 2000 designs × 5 α | use |
|---|---|---|---|---|
| **Exploration** | **12** | 14.6 s | **20 h** | sweeps, DoE, optimisation, screening |
| **Verification** | 24 | 57.3 s | 6.7 days | promoted designs, control sizing, pre-CFD |

The curve has no sharp knee — returns are close to constant-elasticity — so the
choice is made against a **requirement**, not against curvature. The requirement:
an overnight DoE, forces and stability inside 1%, control derivatives carrying a
stated bias-dominated ~4%. Control-authority *sizing* must be re-run at 24.

---

## 6. Results: where the sections go

### 6.1 The mechanism

AVL interpolates control gain linearly between consecutive sections. If the band
ends at 0.95 and the next section is at 1.00, AVL does not place a hard edge at
0.95 — it fades gain from 1 to 0 across that interval, so a strip of wing carrying
**no physical elevon** flies a half-deflected one.

The **ramp fraction** is that leaked width divided by band width. Measured
correlation with `CL_δe` error: **r = +0.978**. Target ≤ 0.15.

A structural consequence, easily missed: with 25 stations the uniform spacing is
0.042 of span, so a band 0.15 wide carries a ramp of about (0.042 + 0.042)/0.15 =
**56% regardless of pinning**. For short controls the 15% target is unreachable by
even spacing alone.

### 6.2 Hard feature pins

The curvature monitor of §6.3 is built on `|g''|^(1/2)`, which assumes a *smooth*
function. At a true kink it cannot resolve the feature no matter how much density
is piled nearby — a kink requires a node placed exactly **on** it. The BWB planform
has two such kinks by construction, plus two control-band edges, plus root and tip.

Pins are **inserted**, not substituted for a neighbour, and they are paid for out of
the section budget so that the requested count is the delivered count. A pin landing
within a quarter-interval of a base station absorbs it, and the freed section is
respent by bisecting the largest remaining gap.

### 6.3 The geometric-information metric

The metric is a curve along the span that is **tall where the shape changes fast and
short where it is nearly straight**, following de Boor (1973): to approximate a
curve by straight segments, error is minimised when each segment carries equal
`|g''|^(1/2)`.

![what the metric is](figures/placement_decision/06_what_the_metric_is.png)

1. Sample seven channels along the span: leading-edge x (sweep), z (dihedral),
   chord, twist, thickness, camber, control gain.
2. Divide each by a **fixed physical scale** — lengths by root chord, twist by 10°,
   thickness and camber by 0.1.
3. Second-difference, absolute value, square root.
4. Combine by taking the **worst** channel, not the mean. Averaging lets six calm
   channels dilute one violent one.
5. Weight `control_gain` ×3; weight `thickness` **×0**, because AVL is a
   mean-surface method that never sees thickness. Floor at 0.50 so no region is
   starved.

> Step 2 is a repair. The original implementation normalised each channel to unit
> integral, which erased magnitude: a 40° sweep break and a 0.02° twist wiggle both
> integrated to exactly 1.000 and received equal weight. Correcting this reversed
> the metric's measured verdict.

The seven channels, each in its own physical units, on the narrow-elevon geometry:

![spanwise channels](figures/placement_decision/10_spanwise_channels.png)

Two features are worth reading off directly. `control_gain` is a smoothed top-hat
over the band — its two edges are the steepest features anywhere in the set, which
is why it carries weight ×3. And `thickness` has a pronounced step near 45% span
that the monitor is explicitly told to **ignore**, because AVL cannot see thickness.

Collapsing those channels into a single complexity curve, and its integral:

![spanwise complexity](figures/placement_decision/11_spanwise_complexity.png)

The lower panel is the operational object: sections are placed at equal steps *up*
the cumulative curve. Where it is steep, the wing is complex and stations are close
together; where it is flat, they spread out. A straight diagonal would mean constant
complexity, i.e. uniform spacing is optimal.

### 6.4 What `auto` means

This is the setting that ships, and it is the one most easily misread. **`auto` is
not a third kind of spacing.** It is even spacing with pins, plus one test.

![what auto means](figures/placement_decision/09_what_auto_means.png)

1. Lay down even spacing for (25 − number of interior pins) stations.
2. **Insert** the pins.
3. Measure the ramp fraction of that grid.
4. **If ramp ≤ 15%: stop.** Ship the even+pinned grid. The metric is never
   computed. The result is identical to `never`.
5. **If ramp > 15%:** re-space the non-pin stations by the information metric,
   keeping every pin, and accept the result **only if it actually lowers the ramp**.
6. Restore the count to exactly 25 by bisecting the largest remaining gap.

Worked, on the two branches:

| | nominal | narrow elevon (band 0.70–0.85) |
|---|---|---|
| ramp of even+pinned grid | 7.6% | 66.7% |
| gate (≤15%)? | **closed** | **open** |
| what runs | even spacing kept | re-spaced by metric |
| final ramp | 7.6% | **13.0%** |
| worst control error | 0.25% | 1.52% → **1.12%** |

The grids this produces, on both branches:

![auto vs uniform grid](figures/placement_decision/12_auto_vs_uniform_grid.png)

On the nominal geometry the two rows of stations are *identical* — that is the gate
staying shut. On the narrow elevon, `auto` clusters stations around the band and the
local spacing plot on the right shows where the budget went.

On 5 of the 10 geometries tested the gate stayed closed and `auto` produced exactly
what `never` would have. The three modes are therefore:

- **`never`** — always even + pins.
- **`auto`** — even + pins, unless the control surface would be badly smeared.
- **`always`** — always run the metric, gate or no gate.

### 6.5 Comparison

Four approaches, matched 25-section budget, panel-matched reference (§7.4), 10
geometries, ranked on quantities the reference can resolve — control derivatives,
forces and stability derivatives, **excluding drag** (§7.3):

| approach | mean | **max** |
|---|---|---|
| A even, no pins | 15.17% | 34.54% |
| B even + hard pins | **0.82%** | 1.98% |
| **C gated (`auto`)** | 0.86% | **1.68%** |
| D forced (`always`) | 0.91% | 1.68% |

![per case](figures/placement_decision/01_per_case_control_error.png)

1. **Pins account for almost the entire effect** — 34.54% → 1.98%. This is the
   largest result in this section and is not in doubt.
2. **B and C tie on the mean** (0.04 pp apart, inside the reference's own ~0.5%
   noise). Claiming either is better on average would over-read the data.
3. **C has the better tail**, winning where the ramp is severe: narrow elevon 1.52%
   → 1.12%; another geometry at 36.3% ramp, 1.98% → 1.42%.

A budget sweep confirms this is not an artefact of one budget. On the narrow elevon,
adaptive placement wins at **every** budget tested:

| sections | even + pins | adaptive |
|---|---|---|
| 11 | 6.26% | **4.43%** |
| 15 | 2.94% | **0.63%** |
| 19 | 1.25% | **0.20%** |
| 25 | 1.52% | **0.63%** |

![budget sweep](figures/placement_decision/08_budget_sweep.png)

### 6.6 Distribution across the design set

Single worst-case numbers hide the shape of the distribution. Over the ten
geometries:

![error distributions](figures/placement_decision/15_error_distributions.png)

| approach | median worst-error | median control error | 90th pct control |
|---|---|---|---|
| A no pins | 14.01% | 12.320% | 24.599% |
| B even + pins | **0.73%** | 0.435% | 1.521% |
| **C `auto`** | 0.87% | **0.418%** | **1.368%** |
| D forced | 0.80% | 0.450% | 1.368% |

Pooling all five control derivatives across all ten geometries (n = 50 per
approach), `auto` is better than even+pins on **both** the median (0.418% vs
0.435%) and the 90th percentile (1.368% vs 1.521%). These are small margins, and
they are reported as such — but they are consistent in sign across three separate
statistics (median, p90, max).

### 6.7 Aerodynamic consequence across the envelope

A discretisation study reporting a single angle of attack invites the question of
whether the result holds across the flight envelope. Sweeping α from −2° to +12°:

![polars](figures/placement_decision/13_polars.png)

The lift curves, drag polars and moment curves lie on top of one another at this
scale — which is the intended result, and also why the errors must be plotted
separately to be read at all:

![polar errors](figures/placement_decision/14_polar_errors.png)

**Top row — elevon authority.** On the nominal geometry the two curves coincide
exactly: the gate is shut, so `auto` *is* even+pins. On the narrow elevon, `auto`
holds 0.48–0.50% against even spacing's 1.51–1.53% — **a consistent factor of three
at every angle of attack tested**, not a coincidence of the α = 6° design point.

**Bottom row — pitching moment, as an absolute offset.** Here `auto` is worse:
it carries |ΔCm| ≈ 0.0021 on the narrow elevon against even spacing's 0.00015.
This is a real trade, and it is reported rather than buried. Its physical size:
with Cma = −2.35 rad⁻¹ and Cm_δe = −0.0096 deg⁻¹, an offset of 0.0021 corresponds
to **0.05° of trim angle of attack, or 0.21° of trim elevon** — negligible against
the ~4° deflections of interest, and far smaller than the model's own physical
uncertainty.

So the trade is: a factor of three on the quantity that sizes the control surface,
against a trim offset two orders of magnitude below anything that would change a
design decision.

For a sweep whose designs cannot be inspected individually, the worst case is the
number that matters. **Adopted: `auto`.**

---

## 7. Four rules for deciding such things honestly

Each of these was learned by getting it wrong first. They are stated as rules
because each one silently invalidated a completed result.

### 7.1 Never quote a relative error on a reference near solver resolution

AVL prints six decimals, so its resolution is 1e−6. The yaw-due-to-roll-control
derivative `Cn_δa` has a reference near −2.3e−05. One unit in the last printed digit
is therefore

    1e-6 / 2.3e-5 = 4.35% "error", from rounding alone.

A 100-run study ranked placement policies on this quantity. Seven of nine policies
scored **identically — 4.348%** — on meshes with 6× different ramp fractions. It was
ranking rounding noise, and its conclusion was void.

> **Rule.** Drop any quantity whose reference magnitude is below 100× the solver's
> printed resolution (here, 1e−4). Drop it; do not score it as zero.

**The same failure appears a second way: at a zero crossing.** `Cm` passes through
zero between α = 0° and 2°. A relative-error plot across the α sweep therefore shows
a 6% spike for adaptive placement at exactly that α — while the underlying
*absolute* offset is nearly constant at 0.002 across the whole envelope. The spike
is entirely an artefact of the shrinking denominator; nothing happens to the
aerodynamics there.

> **Corollary.** A quantity that changes sign over the sweep must be reported as an
> absolute offset, not a relative error — the admissibility floor is a property of
> each evaluation, not of the quantity as a whole.

### 7.2 A cheap tier must be justified by bias, not by an error threshold

The usual practice is to pick a mesh whose error is below some tolerance. For a
*ranking* application this is the wrong test — both too strict and too weak. A 3%
consistent bias is harmless; a 1% scatter may be fatal.

> **Rule.** For a tier used to rank designs, report the *spread* of the cheap/rich
> ratio across geometries alongside the bias. Admissible when spread ≪ bias (here
> 0.2–0.3%).

### 7.3 Audit the reference for neutrality — and AVL drag never passes

A reference that answers differently depending on how *its own* sections were placed
cannot adjudicate a placement study. Worse, if one candidate shares its
construction, that candidate is flattered.

Building the reference both ways at increasing density:

| reference sections | nominal | narrow elevon |
|---|---|---|
| 49 | 2.90% | 0.83% |
| 73 | 1.37% | 0.67% |
| 97 | 1.17% | 0.74% |

![reference not neutral](figures/placement_decision/07_reference_not_neutral.png)

It **plateaus above 1% instead of converging**. The effect under test was ~1 pp, so
the yardstick's own uncertainty exceeded the measurement.

The cause is physical, not a coding defect: AVL obtains induced drag by
Trefftz-plane integration of the spanwise load distribution, which is acutely
sensitive to how stations sample that load. Adding sections does not remove the
sensitivity.

> **Rule.** `CDind`, `cd_total` and `e` must never be used to rank spanwise
> discretisation in AVL. Report them; never decide with them.

This audit **withdrew a completed verdict** of this project. An earlier version of
§6.5 ranked on an aggregate dominated by drag, against a reference that was itself
evenly spaced, and concluded that adaptive placement was harmful. Both errors
pushed the same way.

> **Corollary.** Never rank a method solely on the quantities it was designed to
> improve — that is question-begging — and never build a reference that shares one
> candidate's construction.

### 7.4 Refine the reference in the dimension under test only

To make a reference twice as resolved *in sections* without changing panel density,
we hold the total constant: candidates run 25 sections × 4 spanwise panels = 96
strips per side; the reference runs 49 sections × 2 panels = **the same 96 strips,
the same 4608 vortices**, with twice the geometric stations. The comparison then
isolates section placement rather than confounding it with panel resolution.

The naive alternative — 49 sections × 4 panels — is 9216 vortices, past AVL's limit,
and returns `status = FAILED` with every coefficient `None`. This silently produced
an all-`NaN` study.

> **Rule.** Never trust a solver's silence. Assert success explicitly before
> computing anything from a result.

---

## 8. Settings of record

```yaml
geometry:
  aero_discretisation:
    n_sections: 25                   # FINAL count, feature pins included
    span_margin: 0.0                 # full span; the tip is modelled
    spanwise_panels_per_section: 4   # 96 strips per side
    nchordwise: 12                   # exploration tier; 24 = verification tier
    cspace: 1.0                      # cosine
    snap_sections_to_control: true   # hard feature pins, inserted
    section_placement: auto          # even + pins, unless the ramp criterion fails
    ramp_fraction_limit: 0.15
```

Resulting mesh: 192 strips, 2304 vortices, ~14.6 s per design point, against AVL
limits of 500 strips and ≈6000 vortices.

---

## 9. Limitations

- **All errors are discretisation errors.** The reference is always a finer AVL
  mesh. No physical validation against experiment or CFD is claimed anywhere.
- **The gate is imperfect.** One geometry with a 32.7% ramp became *worse* under
  adaptive placement (0.81% → 1.68%). Ramp fraction correlates with benefit but does
  not fully predict it. Retuning the threshold against outcome is open work.
- **Sample size.** Ten geometries separate 34% from 2% comfortably; they do not
  resolve 0.05 pp differences. Those are reported as ties.
- **Single condition.** Discretisation is characterised at α = 6°, one speed, one
  elevon deflection pair. Deflection-dependence was checked separately and is
  approximately linear; angle-of-attack dependence is not characterised here.
- **The bias-consistency result covers seven geometries** from one generator family.
  It is not established for arbitrary planforms.
- **The floor value 0.50** in the information metric was tuned against the earlier,
  defective normalisation and has not been re-tuned since.
- **One unexplained observation.** A narrow-elevon geometry with pins hung AVL
  reproducibly at 24 chordwise, with well-formed geometry and valid aerofoil files.
  It does not occur at 12. Unresolved.

---

## 10. Conclusions

1. Geometry-section and solver-panel convergence are **different questions**. Studied
   together they cannot be told apart; studied separately, 25 sections and 4
   spanwise panels suffice to 0.56% and 0.54%.
2. The chordwise grid governs the **control derivatives alone**, through `N_flap`,
   the panel count aft of the hinge, with `error ~ N_flap^−1.47` (R² = 0.966). The
   intuitive hinge/panel-edge alignment explanation is **wrong** and was retracted.
3. Solver cost is approximately cubic in vortex count. Choosing panels on accuracy
   alone put the model at 77% of the solver's array limit and made design-space
   exploration infeasible. **Two tiers** — 12 panels for exploration, 24 for
   verification — restore it, at a cost that is a near-pure multiplicative bias and
   therefore cancels under ranking.
4. For section placement, **hard feature pins do almost all the work** (34.54% →
   1.98% worst case). A gated curvature metric improves the worst case further, to
   1.68%, by acting only where the control surface would otherwise be badly smeared.
5. Four rules govern the honesty of such studies: a print-noise floor; bias-versus-
   scatter admissibility; reference-neutrality auditing — which establishes that
   **AVL's induced drag can never rank spanwise discretisation**; and refining the
   reference only in the dimension under test.

The fourth conclusion is worth stating plainly. Three published results of this
project were retracted during the work: the hinge-alignment mechanism, an
airfoil-resolution explanation for a solver residual, and a verdict against adaptive
placement. In each case the error was found not by comparing against another code —
which would have shared the same blind spots — but by asking what the reference
itself could actually resolve.

---

## References

- de Boor, C. (1973). *Good approximation by splines with variable knots.*
  Springer Lecture Notes in Mathematics 363.
- Drela, M. and Youngren, H. *AVL — Athena Vortex Lattice.* MIT.
- Roache, P. J. (1994). *Perspective: A method for uniform reporting of grid
  refinement studies.* J. Fluids Eng. 116(3).
- Kenway, G., Kennedy, G., Martins, J. R. R. A. *pyGeo / MACH-Aero.*
- Sandia National Laboratories (2007). *The Verdict Geometric Quality Library.*
  SAND2007-1751.

---

## Appendix A — Figure index

| # | figure | shows |
|---|---|---|
| 1 | `dse_panelling/01_cost_accuracy_tradeoff` | cost vs accuracy, both log, panel counts labelled |
| 2 | `dse_panelling/02_vortex_scaling` | measured scaling against N² and N³, with AVL's ceiling |
| 3 | `dse_panelling/03_stage_breakdown` | where 58 s goes: geometry, viscous, solver |
| 4 | `dse_panelling/04_which_quantity_needs_panels` | only control derivatives need panels |
| 5 | `dse_panelling/05_bias_not_scatter` | cheap/rich ratio is level across geometries |
| 6 | `placement_decision/06_what_the_metric_is` | the metric built in three steps |
| 7 | `placement_decision/07_reference_not_neutral` | the reference disagreeing with itself |
| 8 | `placement_decision/08_budget_sweep` | adaptive wins at every section budget |
| 9 | `placement_decision/09_what_auto_means` | the gate, as a flow chart plus both branches |
| 10 | `placement_decision/10_spanwise_channels` | all seven channels in physical units |
| 11 | `placement_decision/11_spanwise_complexity` | complexity curve and its integral |
| 12 | `placement_decision/12_auto_vs_uniform_grid` | the station sets `auto` actually produces |
| 13 | `placement_decision/13_polars` | lift, drag, moment, elevon authority vs α |
| 14 | `placement_decision/14_polar_errors` | error across the envelope, done honestly |
| 15 | `placement_decision/15_error_distributions` | medians, quartiles, spread over 10 geometries |

## Appendix B — Reproduction

```bash
# cost / accuracy, and the bias-consistency test
python configs/aero/dse_panelling_evidence/cost_sweep.py
python standalone/lowfi_avl_study/dse_bias_check.py

# section placement, and the audit that withdrew the first verdict
python standalone/lowfi_avl_study/placement_decision_study.py
python standalone/lowfi_avl_study/placement_audit.py
python standalone/lowfi_avl_study/reference_neutrality.py

# figures
python standalone/lowfi_avl_study/make_dse_figures.py
python standalone/lowfi_avl_study/make_placement_figures.py
python standalone/lowfi_avl_study/make_metric_figures.py
python standalone/lowfi_avl_study/make_auto_figure.py
python standalone/lowfi_avl_study/make_spanwise_figures.py

# polars across the alpha envelope, and their figures
python standalone/lowfi_avl_study/placement_polars.py
python standalone/lowfi_avl_study/make_polar_figures.py
```

## Appendix C — Evidence

Tracked under `configs/`, so it survives `data/` being cleared:

| content | path |
|---|---|
| Cost sweep, stage timing, bias consistency | `configs/aero/dse_panelling_evidence/` |
| Placement comparison, 10 geometries | `configs/aero/placement_decision_evidence/` |
| Reference-neutrality and budget-sweep audit | `configs/aero/placement_audit_evidence/` |

## Appendix D — Decision records

| decision | subject |
|---|---|
| 0009 | Low-fidelity discretisation: sections, panels, chordwise spacing |
| 0010 | The control-resolution criterion supersedes tuned panel counts |
| 0012 | Spanwise monitor: worst-channel, thickness off, hard feature pins |
| 0013 | Two panelling tiers: exploration (12) and verification (24) |
| 0014 | Section placement: hard pins always; adaptive gated (`auto`) |

Plain-language companion for readers new to the vocabulary:
`studies/avl_placement_explained.md`. One-page settings reference:
`studies/SETTINGS_OF_RECORD.md`.
