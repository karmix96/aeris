# How we choose the panelling settings for our aerodynamics solver

**A plain-language plan, with every value locked before the first run.**

Date: 2026-07-28 · Status: proposed, not yet run · **Revision 3**

Revision 3 corrects a methodological error in revision 2 and rebuilds the plan
around an explicit justification for *why each criterion is used and in what order*.
See §10 for the full change list. The headline correction: revision 2 called a
directionally-extrapolated value "the true answer". It is not, and the plan is
restructured accordingly.

---

## Part 1 — What this is about

### What we are building

We are designing a small unmanned aircraft: a **blended wing body**, one smooth
shape with no separate fuselage, like a manta ray.

We do not design one aircraft. A computer tries **thousands** of variations and
tells us which is best — **design space exploration** (DSE). For that to work,
testing one shape must be fast. At one minute per shape, two thousand shapes is a
day and a half. At an hour, the idea collapses.

### The tool

**AVL** — old, small, fast. Give it a wing, it returns lift, drag and flight
behaviour. It is a simplified model, and that is exactly why we use it: fast enough
to run thousands of times. The best few designs go to slow, accurate software later.

### What "panelling" means

AVL cannot handle a smooth curved wing. It chops the wing into small flat boxes.
Like pixels in a photograph: more pixels, sharper picture, bigger file.

- **More boxes** → more accurate, slower
- **Fewer boxes** → faster, blurrier

Two directions: **across the wing** (spanwise) and **front to back** (chordwise).

### How the counts work

The wing is described by **25 slices** along the span, leaving **24 gaps**. The
current setting puts **4 panels in each gap**:

```
24 gaps × 4 panels   =  96 strips per wing
× 2 wings            = 192 strips total
× 12 chordwise       = 2,304 boxes
```

So "4 spanwise" is four *per gap*, totalling 192 strips.

### The hard ceiling — this shapes everything

AVL is compiled with fixed arrays: **at most 500 strips and about 6,000 boxes**.
Since strips = 48 × (spanwise panels), the two directions compete for one budget:

| spanwise per gap | strips | max chordwise |
|--:|--:|--:|
| 1 | 48 | 125 |
| 2 | 96 | 62 |
| 3 | 144 | 41 |
| 4 | 192 | 31 |
| 6 | 288 | 20 |
| 8 | 384 | 15 |
| 10 | 480 | 12 |

**You cannot refine both directions at once.** This is not an inconvenience to work
around — it is the central constraint, and §3 explains why it invalidates the
obvious approach.

### Why the setting matters

AVL's cost grows roughly with the **square to cube** of the box count. One design
point took 58 seconds:

| stage | time |
|---|---|
| building the wing shape | 1.4 s |
| air-friction correction | 0.6 s |
| **AVL itself** | **56.9 s** |

Two thousand designs at five angles = **6.7 days**. Cutting chordwise 24 → 12 gave
14.6 s and a 20-hour sweep. That is the decision under re-examination.

---

## Part 2 — Why we are doing this again

### Hole 1 — drag was never measured

Drag decides range, endurance and battery size. It is what the design exists to
reduce. We measured lift, pitching moment and elevon power, and never read the drag
number. We chose the main setting without looking at the main quantity.

### Hole 2 — we never established what "correct" is

To say 12 is close enough, you need something to be close *to*. We ran the biggest
mesh AVL would accept — 30 chordwise — and called it correct. It was not.

| chordwise | value (elevon power) | change |
|---|---|---|
| 6 | 0.01050 | |
| 12 | 0.01126 | +0.00076 |
| 24 | 0.01163 | +0.00037 |

Each doubling moves about half as much. Extended, the limit is near **0.01198**.

| | error we reported | actual |
|---|---|---|
| 12 chordwise | 3.76% | **~6%** |
| 24 chordwise | 0.62% | **~2.9%** |
| 30 — our "correct" answer | 0% by definition | **~2.3%** |

We measured with a ruler 2.3% short.

### Hole 3 — only one knob was ever turned

Chordwise was swept; spanwise sat at 4, untouched.

---

## Part 3 — The logic of the plan, and why it is in this order

This section is the justification for everything that follows. It is deliberately
placed before the steps, because the order of the steps is *derived* from it.

### The decision we must make

> Which panelling setting do we use for the design sweep?

### Four possible criteria, ranked by how much they assume

Any criterion we could use rests on assumptions. Ranked from most fragile to most
robust:

| | criterion | what it requires | fragility |
|---|---|---|---|
| **A** | error against the true converged value | a true value must exist and be obtainable — needs smooth, monotonic convergence inside the asymptotic range, in *both* directions | **highest** |
| **B** | change between successive meshes (δ) | only a refinement sequence | medium — can mislead badly (§3.3) |
| **C** | ranking stability across designs | only a *common comparator*; no truth required at all | **lowest** |
| **D** | runtime | measurement only | none |

### The consequence — and this is the core argument

**We build the decision on C and D, because they survive if everything else fails.**

Criterion C is the remarkable one. To ask *"does the cheap mesh rank the 30 designs
in the same order as the expensive mesh?"* you do not need to know the right answer
for any of them. You only need one consistent comparator. Ordering is far more
robust than value: a systematic error that shifts every design equally leaves the
ordering untouched.

So the hierarchy is:

1. **Primary criterion — ranking stability (C) plus cost (D).**
   These always work. They need no convergence assumption whatsoever.
2. **Secondary — the change between successive meshes (B).**
   This locates the knee of the accuracy–cost curve and shows the reader where the
   returns stop.
3. **Only where it is earned — Richardson extrapolation and GCI (A).**
   Used to *quantify the remaining numerical uncertainty*, per output, and only
   where the mathematical preconditions are demonstrably met.

**This ordering is not a preference. It is forced.** If we made A primary and A
turned out to be invalid for the hinge moments or the control derivatives — which is
entirely possible — we would have no decision procedure left. Building on C means
the study still produces an answer even in the worst case.

### 3.1 Why Richardson cannot be the backbone

Richardson extrapolation assumes:

1. at least three systematically refined meshes,
2. a known and preferably constant refinement ratio,
3. smooth convergence toward a single value,
4. that we are already **inside the asymptotic range**,
5. that nothing else about the mesh changes at the same time.

NASA's grid-convergence guidance is explicit that extrapolation is trustworthy only
once the meshes have reached the asymptotic range, and recommends at least three
levels to compute the observed order and the GCI.

For our study these conditions are **not guaranteed** for:

- stability derivatives,
- control derivatives,
- hinge moments,
- any quantity close to zero, where AVL's six-decimal printing dominates,
- extreme geometries — strong taper, very small elevons.

Some outputs will converge cleanly. Others may oscillate, or move less than AVL's
print resolution. A spreadsheet will always return a number. That does not make the
number physically meaningful.

### 3.2 The error in revision 2 — and it was a real one

Revision 2 proposed sweeping chordwise to 60 while holding **spanwise = 2**, and
called the extrapolated result "the true answer".

It is not. What that produces is:

```
Q(chordwise → ∞ , spanwise = 2)
```

and **not**:

```
Q(chordwise → ∞ , spanwise → ∞)
```

It is the chordwise-converged solution *on a fixed and rather coarse spanwise mesh*.
Naming it "the true answer" was wrong and would have propagated into every error
figure in the study.

**The correct name is: a *directional extrapolated estimate under fixed spanwise
resolution*.** That term is used throughout this revision, and the word "truth"
appears nowhere.

### 3.3 The δ trap — why B alone is not enough either

Two different things must never be confused:

**δ — the change between successive meshes.**
```
δ_N = |Q_N − Q_previous| / |Q_N|
```
Note this is *not* a CFD solver residual. AVL solves a linear system directly and
has no iteration history. δ means only: *how much did the answer move when we last
refined?*

**ε — the actual distance from the converged value.**
```
ε_N = |Q_N − Q_∞| / |Q_∞|
```

**A small δ does not imply a small ε.** For order *p* and refinement ratio *r*:

```
ε_N ≈ δ_N / (r^p − 1)
```

Our elevon data gives *p* ≈ 1. With *p* = 1 and doubling, this becomes **ε ≈ δ**:

> At first-order convergence, however much the last *doubling* moved the answer is
> roughly how much error remains.

Check it: 12 → 24 moved the answer 3.18%; the remaining error at 24 is 2.9%. Nearly
identical. This is exactly why "24 to 30 barely changed" was misleading — 24 to 30
is not a doubling, so it *cannot* move much, and the small step said nothing about
how far from converged we were.

**This is also why every refinement chain in this plan uses ratio r = 2.** A
doubling that barely moves is genuine information. A 1.25× refinement that barely
moves is nearly meaningless.

### 3.4 What we do when Richardson is not admissible

We do not force it. Instead:

- the **finest practical mesh** becomes the comparator,
- the quoted error is explicitly labelled a **lower bound**, not an error estimate,
- the report states that asymptotic convergence was not demonstrated for that
  quantity.

Labelling matters. An unqualified "0.6% error" that is really a lower bound is how
the previous study went wrong.

---

## Part 4 — The steps

**Total: ~1,303 AVL runs over 36 shapes. ~8.7 hours of compute; roughly 1.5 hours of
real time running 8 at once on the machine's 12 cores.**

---

### Step 0 — Lock the rules *(no runs)*

**Why.** Deciding the score after seeing results means unconsciously choosing the
score that favours your preferred answer. We proved this on ourselves: re-scoring
the previous study's data seven reasonable ways moved every option at least three
places, and *both* options once declared "the winner" ranked both 1st and 7th–8th
depending on the scoring chosen.

**Frozen in a committed file before run one:**

1. **30 normal shapes** from the same sampler the real sweep uses.
2. **6 extreme shapes** — high aspect ratio, narrow elevon, wide elevon, strong
   taper gradient, and two more. Reported **separately, never pooled**: they were
   hand-picked to be hard and would drag the averages somewhere unrepresentative.
3. **The quantity list:**
   - Drag: induced drag, total drag, span efficiency, lift-to-drag ratio
   - Forces: lift coefficient, pitching moment
   - Stability: neutral point and five derivatives
   - Control: five elevon derivatives
   - Hinge moments on both elevon slots — these size the servos, and being
     hinge-line quantities they are the most panel-hungry things we have
4. **The pass mark** — Part 6, written before any result exists.
5. **The print-noise rule.** AVL prints six decimals. Any quantity whose comparator
   is below **1e−4** is discarded — a "5% error" there is rounding in the last
   digit. Ignoring this destroyed the previous study, where seven of nine options
   scored an *identical* 4.348% on meshes differing sixfold.
6. **The Richardson admissibility gates** — Part 5, per output, decided now.
7. **The interaction criterion** — Step 1, numeric, decided now.
8. **The shortlist rule** — Step 4, decided now even though its outputs cannot be.

---

### Step 1 — The 2D lattice: the backbone of the study *(234 runs, ~1.2 h)*

**Why this comes first, and why it is not just a "pilot".** Two separate
one-directional studies cannot, on their own, tell you about the finished mesh —
that is the error of §3.2. A crossed grid can, because it lets you fit an error
model in *both* directions at once:

```
Q(n_chord, n_span)  ≈  Q_∞ + a·h_chord^p + b·h_span^q
```

With a crossed lattice you can fit all five unknowns — including the joint limit
`Q_∞` — instead of gluing two one-directional extrapolations together and hoping.
This grid is therefore the enabling data for any legitimate convergence claim, not
a preliminary check.

**The design — ratio 2 in both directions:**

```
chordwise ∈ {6, 12, 24, 48}      spanwise ∈ {1, 2, 4, 8}
```

**13 of the 16 cells are legal:**

| spanwise ↓ / chordwise → | 6 | 12 | 24 | 48 |
|---|:-:|:-:|:-:|:-:|
| 1 | ✓ | ✓ | ✓ | ✓ |
| 2 | ✓ | ✓ | ✓ | ✓ |
| 4 | ✓ | ✓ | ✓ | ✗ 9,216 |
| 8 | ✓ | ✓ | ✗ 9,216 | ✗ |

Run on **6 shapes at 3 angles**.

**What it delivers — three things at once:**

1. **Is convergence smooth at all?** Before spending on long ladders.
2. **Do the two directions interact?** The gate below.
3. **Where is the sweet-spot region?** So the later steps look in the right place.

**The interaction criterion, locked now.** The question asked of the data is:

> When chordwise goes 6 → 12 → 24, is the change about the same whether spanwise is
> 2 or 8?

Interaction is judged **acceptable** only if all three hold:

1. The two-way term of a factorial fit is **under 20%** of the sum of the two main
   effects.
2. It does not change **which combinations pass** the accuracy gate in Part 6.
3. It does not materially change the **ranking of the shapes**.

**This is a gate.** Fail any one and the directions are *not* separable: the
one-directional ladders in Steps 2 and 3 are not interpretable on their own, and we
expand this lattice into the primary experiment rather than pretending otherwise.
We find this out for 1.2 hours, before spending the other 7.5.

---

### Step 2 — Chordwise resolution ladder *(288 runs, ~1.3 h)*

**Why, given Step 1 already sweeps chordwise.** Step 1 has only three chordwise
levels — enough to fit a model, not enough to *see the curve* or to test whether the
fitted order is stable. This step provides both.

**What is varied:**

```
chordwise = 4, 6, 8, 10, 12, 15, 16, 20, 24, 30, 40, 60
```

**Held fixed: spanwise = 2** (the ceiling table forbids anything else at 60).

**Why these twelve values.** They are chosen so the ladder contains **four
independent ratio-2 chains**:

```
4 → 8 → 16        6 → 12 → 24        10 → 20 → 40        15 → 30 → 60
```

Each chain gives its own estimate of the observed order *p* and its own
extrapolated value. **Four estimates at four different resolution bands is an
empirical test of whether we are in the asymptotic range** — if *p* is stable across
the chains, we are; if *p* drifts, we are not, and no amount of extrapolation will
fix it. This is stronger than a single triplet plus an assumption.

**What this step produces — named correctly.** A *directional extrapolated estimate
under fixed spanwise resolution*, `Q(chord→∞, span=2)`, per shape, angle and
quantity, with a GCI uncertainty band. It is **not** the converged AVL solution, and
it is used only to (a) establish the shape and rate of chordwise convergence and
(b) cross-check the joint fit from Step 1.

**On angles.** Three: **−2°, 0°, +4°**, the production workflow's own default sweep
(`src/aeris/commands/workflow.py:582`). There is no sense validating panelling at
conditions the tool is not used at. One shape is additionally run at **+8°** as a
robustness probe.

*Justification for only three:* AVL's influence matrix does not depend on angle of
attack at all — only the right-hand side does. So mesh sensitivity is expected to be
weakly angle-dependent for the linear quantities, and the angles mainly probe the
*viscous drag correction*, which is nonlinear. The +8° probe tests that expectation
rather than assuming it.

**Honest exit.** If the four chains disagree on *p*, or the sequence oscillates, we
report that asymptotic convergence was not demonstrated, and fall back to §3.4.

---

### Step 3 — Spanwise resolution ladder *(168 runs, ~1.35 h)*

**Why second.** This step must hold chordwise fixed. Step 2 tells us where chordwise
convergence stands, so the value is chosen rather than guessed.

**What is varied:**

```
spanwise = 1, 2, 3, 4, 6, 8, 10 panels per gap
```

Contains the ratio-2 chains `1 → 2 → 4` and `2 → 4 → 8`; the values 3, 6 and 10 fill
in the curve for the knee plot.

**Held fixed: chordwise = 12.**

**Why 12 — this is forced, not chosen.** Reaching spanwise 10 means 480 strips,
which caps chordwise at **12** (ceiling table). Revision 2 proposed holding chordwise
at "20, 24 or 30". That is arithmetically impossible alongside a ladder reaching 10.

**The compromise is covered by Step 1**, whose lattice contains spanwise 1→2→4→8 at
chordwise 24 and 48 as well as at 12. If the spanwise convergence shape is the same
across those chordwise levels, holding chordwise at 12 here did not distort it — and
that comparison is exactly the separability gate.

---

### Step 4 — Panel spacing *(48 runs, ~20 min)*

**Why.** Chordwise panels need not be evenly spaced. Bunching them near the leading
and trailing edges, where pressure changes fastest, is **cosine spacing**. We use
full cosine today and have never checked whether it is right at a *reduced* panel
count — where it matters most, because there are fewer panels to place well.

**What is run.** Three spacings — uniform, half-cosine, full cosine — crossed with
chordwise {8, 12, 16, 24} at spanwise 4, on 4 shapes at one angle.

**Why here.** Cheap, and only meaningful once Step 2 has shown which panel counts
matter.

---

### Step 5 — Build the shortlist *(no runs)*

**Why.** Step 6 costs half the remaining budget and runs **once**. Everything before
it exists to earn a short list worth that spend.

**The values cannot honestly be fixed now** — determining them is what Steps 1–4 do.
**The selection rule is locked now:**

1. One setting clearly **below** the knee — deliberately too cheap, to show what
   failure looks like.
2. Two or three settings **spanning the knee**, including the current 12 / 4.
3. One setting clearly **above** the knee — the most expensive legal combination
   whose numerical uncertainty (GCI where valid, lower bound where not) is under
   ~1%. This becomes the practical comparator for the ranking test.
4. Spanwise count from Step 3 and spacing from Step 4, applied uniformly across the
   shortlist so the comparison isolates chordwise.

**Indicative only — not a commitment:**

| | chordwise | spanwise per gap | role |
|---|--:|--:|---|
| A | 8 | 3–4 | deliberately cheap |
| B | 12 | 3–4 | current practice |
| C | 16 | 4 | mid |
| D | 20 | 4–6 | higher accuracy |
| E | 24 | 4 | practical comparator |

---

### Step 6 — Does cheap pick the same aircraft? *(540 runs, ~4.3 h)*

**Why this is the decisive step.** It is criterion C — the one that needs no truth.
See §3.

Two examples make the point:

- Cheap setting wrong by 3% on **every** design, always the same direction → every
  design shifts together, the order is unchanged, you still pick the same winner.
  **Costs nothing.**
- Cheap setting wrong by only 1%, but **randomly** — some high, some low → the order
  shuffles and you promote the wrong aircraft. **Fatal.**

A large consistent error is safe. A small random error is not. A setting can sit
perfectly on the knee and still be useless if its error is scattered.

**What is run.** All 30 normal shapes through each shortlisted setting at
**−2°, 0°, +4°**. Separately, the 6 extreme shapes through the same settings.

**What is measured.**

1. Rank the 30 designs using the **expensive comparator**.
2. Rank the same 30 using each **cheap** setting.
3. Compare:
   - **Spearman correlation** — how closely the orderings agree, 1.0 identical.
   - **Top-3 retention** — of the three best designs the comparator chose, how many
     does the cheap setting also place in its top three? This matters more than the
     correlation, because only the best few are ever promoted.
   - **Consistent or scattered** — for every quantity, drag included: is the error a
     uniform shift or does it vary shape to shape? Measured as the spread of the
     cheap/comparator ratio across the 30, as a fraction of the shift itself.

**On the comparator.** It is the finest setting affordable on all 30 shapes. It is
**not** claimed to be correct, and the question asked of it is purely relative.

---

### Step 7 — Honest timings *(25 runs, ~12 min)*

**Why.** A timing taken while eight other jobs share the machine is not a timing.
And timings are only needed for the shortlist, which does not exist until Step 5.

**What is run.** Each shortlisted setting five times, **alone**, on an idle machine.
We report the **median**, not the best — the median predicts the real dataset cost.

---

### Step 8 — Document it

- Convergence curves, observed orders per chain, and the asymptotic-range assessment
- Extrapolated values **with uncertainty bands**, clearly labelled as directional or
  joint, and clearly flagged where extrapolation was refused
- Error tables, with lower-bound entries marked as such
- Cost-versus-uncertainty curves showing the knee
- The ranking comparison
- A written justification for the chosen setting
- All raw results into a tracked folder, surviving the working directory being
  cleared
- Software versions, configuration hashes, machine, load

---

## Part 5 — Reference values: what they are, per output

There is **no single reference number**. There is a separate one for every
combination of shape, angle, quantity and refinement direction.

**Example.** For shape 7 at +4°, take the pitching moment across the chordwise
ladder, examine how it converges, and — *if the gates below pass* — extrapolate to
`Cm(chord→∞, span=2)`, with an uncertainty band. That is the comparator for that
quantity, that shape, that angle.

### The admissibility gates, applied to every output separately

Before any extrapolation is computed, that output must pass **all** of:

1. **Monotonic** over the last three levels of the chain.
2. **Differences shrinking** with refinement.
3. **Observed order sane and reasonably stable** — 0.5 ≤ p ≤ 3, and consistent
   across the four ratio-2 chains of Step 2.
4. **Asymptotic-range check passes** — the standard test that successive GCI values
   scale as `r^p`.
5. **Not near zero** — comparator above the 1e−4 print-noise floor.

**If all pass:** compute the Richardson extrapolation, compute the GCI, and report
the numerical uncertainty.

**If any fails:** do **not** force it. Use the finest practical mesh as comparator,
label the quoted error a **lower bound**, and state in the report that asymptotic
convergence was not demonstrated for that quantity.

### The two comparators, for two different jobs

| purpose | comparator | status |
|---|---|---|
| numerical uncertainty | extrapolated value + GCI, where admissible | best available estimate, with a stated band |
| numerical uncertainty, where not admissible | finest practical mesh | **lower bound only** |
| ranking of the 30 shapes | most expensive shortlist setting | **practical**, explicitly not truth |

---

## Part 6 — The acceptance criteria

### Five hard gates — pass or fail

A cheap setting is admissible only if **all five** hold:

1. **Spearman correlation ≥ 0.98** on lift-to-drag across the 30 shapes.
2. **All three** of the comparator's top-3 designs retained.
3. **Numerical uncertainty below 1%** on the non-control quantities — lift, pitching
   moment, drag, stability. Measured as GCI where admissible, as the lower-bound
   difference where not.
4. **Control quantities consistent, not scattered** — any size of shift allowed,
   provided the spread across shapes is **≤ 5% of the shift**.
5. **Every run reports success**, at every angle, on every shape.

### The selection rule

**Among the settings passing all five gates, choose the cheapest.**

This rule *already implements* the knee: the cheapest passing setting is by
construction the point beyond which further spending buys nothing the gates
recognise. The knee plot is therefore **evidence we present**, not a sixth gate —
keeping it as a separate criterion would create two rules that could disagree.

### If nothing passes

We do not lower the bar to manufacture a winner. We report that the DSE tier
requires a more expensive discretisation than hoped, and state what it costs.

---

## Part 7 — Safety checks throughout

**AVL fails silently.** Give it a mesh past its internal limits and it prints no
error — it returns a result where every number is blank, indistinguishable from a
genuine physics failure. This once turned an entire study into nonsense before
anyone noticed. Every run is checked for success, and the study **stops** rather
than quietly averaging over a failure.

**Verify the mesh we got.** AVL reports the mesh it built. It is compared against
the mesh requested, every run.

**Record everything.** Software version, configuration hash, machine, concurrent
load.

---

## Part 8 — What this study proves, and what it does not

**It proves exactly one thing:**

> The chosen AVL discretisation is fine enough that the results do not change
> significantly with more panels, and do not change which designs are ranked best.

**It does not prove:**

- that AVL agrees with CFD,
- that AVL agrees with experiment,
- that NeuralFoil gives correct viscous drag,
- that the elevon model is physically realistic,
- that the flow at high angle is correctly described,
- that AVL captures separation or any nonlinear behaviour.

Four distinct levels of validation:

| level | question | status |
|---|---|---|
| **1. Panelling convergence** | Is AVL numerically settled? | **this study** |
| 2. Solver validation | Does AVL agree with CFD or experiment? | separate, later |
| 3. Model validation | Are aerofoils, elevons, viscous corrections right? | separate |
| 4. Surrogate validation | Does the machine-learning model learn the data correctly? | separate |

**This study proves we are using AVL correctly. It does not prove AVL is reality.**
Saying so plainly is part of the deliverable.

---

## Part 9 — What we will be able to claim

Not "we used 12 panels because it seemed enough". Instead:

> A systematic panel-refinement study was carried out in both discretisation
> directions of the AVL model, on a crossed lattice with a constant refinement ratio
> of two. The operating point was selected as the cheapest setting satisfying stated
> gates on numerical uncertainty, on consistency of error, and on preservation of
> the design ranking and the leading designs. Richardson extrapolation and the Grid
> Convergence Index were applied only to those outputs and mesh sequences
> demonstrated to lie in the asymptotic range; where that could not be demonstrated,
> the finest practical mesh was used and the reported figures are stated as lower
> bounds.

That is the real purpose: **to show we save time without choosing the wrong
aircraft.**

---

## Part 10 — Changes in revision 3

1. **Corrected a methodological error.** Revision 2 called
   `Q(chord→∞, span=2)` "the true answer". It is a *directional extrapolated
   estimate under fixed spanwise resolution*. The word "truth" is now absent, and
   the joint limit is obtainable only from the Step 1 lattice, and only if
   separability holds.
2. **Demoted Richardson from backbone to instrument.** The primary criterion is now
   ranking stability plus cost — the criteria that survive if convergence
   assumptions fail. Part 3 sets out the justification explicitly.
3. **Made the crossed lattice the backbone** rather than a late interaction check,
   and put it first. It is the only data that can support a joint convergence claim,
   and it is the cheapest thing that can invalidate the rest of the plan.
4. **Constant refinement ratio r = 2 in both directions**, replacing the previous
   irregular ladder used as one long extrapolation.
5. **Four independent ratio-2 chains in the chordwise ladder**, giving four estimates
   of the observed order — an *empirical* asymptotic-range test rather than an
   assumption.
6. **Per-output admissibility gates**, with an explicit refusal path and
   **lower-bound labelling** where extrapolation is not earned.
7. **Angles corrected to the production sweep** (−2°, 0°, +4°), with a +8° probe;
   justified by AVL's influence matrix being independent of angle of attack.
8. **The knee demoted from gate to evidence**, leaving exactly one selection rule.

Earlier corrections retained from revision 2: the spanwise ladder is incompatible
with high chordwise (ceiling table), and the spanwise-8 / chordwise-16 cell is
illegal at 6,144 boxes.

---

## Appendix — the runs at a glance

| step | question | cells | shapes | angles | runs | time |
|---|---|--:|--:|--:|--:|--:|
| 1 | 2D lattice: interaction + joint fit | 13 | 6 | 3 | 234 | 1.20 h |
| 2 | chordwise curve + order stability | 12 | 8 | 3 | 288 | 1.30 h |
| 3 | spanwise curve | 7 | 8 | 3 | 168 | 1.35 h |
| 4 | which spacing? | 12 | 4 | 1 | 48 | 0.34 h |
| 6 | does cheap pick the same winners? | 5 | 30 | 3 | 450 | 3.55 h |
| 6 | extreme shapes, reported apart | 5 | 6 | 3 | 90 | 0.71 h |
| 7 | honest timings | 5 | 1 | 1 | 25 | 0.20 h |
| | | | | | **1,303** | **~8.7 h** |

36 shapes total: 30 from the real design sweep, 6 deliberately extreme. Roughly
**1.5 hours** in practice, running 8 at a time across 12 cores.
