# AERIS low-fidelity settings of record

**One page. What AERIS runs, why, and what it costs.** Last revised 2026-07-26.

If you change any number here, change it in `configs/geometry/bwb.yaml` — that file
is the source of truth, and the CLI and GUI both read their defaults from it.

---

## The settings

```yaml
geometry:
  aero_discretisation:
    n_sections: 25                   # FINAL count, feature pins included
    span_margin: 0.0                 # full span — the tip is modelled
    spanwise_panels_per_section: 4   # 96 strips per side
    nchordwise: 12                   # DSE tier. 24 = verification tier
    cspace: 1.0                      # cosine chordwise spacing
    snap_sections_to_control: true   # hard feature pins, inserted not swapped
    section_placement: auto          # adaptive only when the ramp criterion fails
    ramp_fraction_limit: 0.15
```

Resulting AVL mesh: **192 strips, 2304 vortices, ~14.6 s per design point.**
AVL's compiled limits are 500 strips and ~6000 vortices; `write_native_avl` now
raises if you cross either.

---

## Why each number

| setting | value | why | decision |
|---|---|---|---|
| `n_sections` | 25 | ≤0.56% worst-seed on forces + stability. It is the FINAL count — pins are paid out of the budget, not added on top | 0009, 0012 |
| `span_margin` | 0.0 | an inset means the real wing tip is never modelled; the tip vortex forms inboard of where it belongs | 0005 |
| `spanwise_panels_per_section` | 4 | ≤0.54% worst-seed | 0009 |
| `nchordwise` | **12** | AVL's cost is ~cubic in vortex count. 24 was 4608 vortices = 77% of the ceiling and 57 s/point. 12 is 3.9× faster; the whole penalty is a ~3% *bias* on control derivatives that cancels in ranking | **0013** |
| `cspace` | 1.0 | cosine resolves the pitching moment. Uniform halves elevon error but degrades Xnp/Cmq 14–15× | 0009 |
| `snap_sections_to_control` | true | a kink needs a node exactly on it; the curvature monitor cannot resolve one by piling density nearby. Removing pins takes the worst case from <2% to **34.54%** | 0012, 0014 |
| `section_placement` | **auto** | ties uniform+pins on the mean, improves the worst case (1.98% → 1.68%) where the ramp is severe, identical where it is not | **0014** |
| `ramp_fraction_limit` | 0.15 | the gate. Imperfect — see open items | 0010 |

---

## Two tiers, and when to switch

| tier | `nchordwise` | cost/point | 2000 designs × 5 α | use |
|---|---|---|---|---|
| **DSE** (default) | 12 | 14.6 s | **20 h** | sweeps, DoE, optimisation, screening |
| **Verification** | 24 | 57.3 s | 6.7 days | promoted designs, control-authority sizing, anything feeding CFD |

Switch with `--nchordwise 24` (CLI) or the chordwise field in the GUI's pyGeo→AVL
panel. **Control-authority sizing must be re-run at 24** — the DSE tier
underestimates elevon authority by a consistent ~3.1%.

---

## Three rules that are easy to get wrong

**1. Never quote a relative error on a tiny reference.** AVL prints 6 decimals, so
its resolution is 1e−6. `Cn_da` has a reference near −2.3e−05, where one unit in the
last printed digit is 4.35% "error" from rounding alone. Drop any quantity whose
reference is below **1e−4**. Omitting this rule invalidated an entire 100-run study,
in which seven of nine policies scored *identically* on meshes with 6× different
discretisation.

**2. Never rank spanwise discretisation with drag.** `CDind`, `cd_total` and `e`
cannot adjudicate placement in AVL. A reference disagrees with *itself* by 1.2–2.9%
on drag depending on how its own sections are placed, and this does not converge
away — 49/73/97 sections give 2.90%/1.37%/1.17%. AVL's Trefftz-plane drag is
acutely sensitive to how stations sample the spanwise load. Report drag; never
decide with it.

**3. Never trust an AVL run's silence.** Exceeding its compiled arrays does not
produce an error — it produces `status=FAILED` with every coefficient `None`,
indistinguishable from a physics failure. It silently turned one study entirely to
`NaN`. Always assert `status == "SUCCESS"` before computing anything.

---

## Where the evidence lives

| what | where |
|---|---|
| Panelling cost/accuracy | `studies/dse_panelling_cost_accuracy.md` · `configs/aero/dse_panelling_evidence/` |
| Section placement + audit | `studies/section_placement_decision.md` · `configs/aero/placement_decision_evidence/`, `configs/aero/placement_audit_evidence/` |
| Plain-language explainer | `studies/avl_placement_explained.md` |
| Decisions | `decision/0013-*.md`, `decision/0014-*.md` |
| Figures | `studies/figures/dse_panelling/`, `studies/figures/placement_decision/` |

Everything under `configs/` is tracked and survives `data/` being wiped.

---

## Open items

- The `ramp_fraction_limit: 0.15` gate does not fully predict benefit — one
  geometry with a 32.7% ramp got *worse* under adaptive placement. Retune against
  outcome, not ramp.
- `floor = 0.50` in the monitor was tuned against the earlier magnitude-erasing
  normalisation and has never been re-tuned.
- The monitor produces the information integral needed to *choose* the section
  budget rather than fixing it at 25. Unwired.
- One geometry (narrow elevon + pins) hung AVL reproducibly at 24 chordwise with
  valid geometry. It does not occur at 12. Unexplained.
