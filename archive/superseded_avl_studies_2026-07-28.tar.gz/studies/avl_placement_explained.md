# Plain-language answers: band, gain ramp, span-margin, "error against what", the information metric, and how sections actually get placed

You asked five things. This document answers each one directly, in order, with the
exact lines of code that do the work. No jargon is used before it is defined.

---

## 1. Why study "band", "gain ramp" and "span-margin" when those words are not in the AVL user primer?

**Because they are not AVL's words. They are AERIS's words for choices AERIS has to
make before it is allowed to write an AVL file.**

AVL does not generate geometry. It reads a `.avl` text file in which *you* have
already decided where every spanwise station sits and which stations carry a
control surface. Mark Drela's primer describes the file format; it does not tell
you how to fill it in. Those three words name the three decisions AERIS makes when
it fills it in:

| AERIS word | What it names | The AVL thing it controls |
|---|---|---|
| **band** | the pair of span fractions where the elevon starts and ends, e.g. 0.60 → 0.95 | *which* sections get a `CONTROL` line |
| **gain ramp** | the smeared, partly-deflected strip of wing just outside each band edge | a side-effect of AVL's `gain` interpolation |
| **span-margin** | how far in from the root and tip we stop placing sections | whether the wing root and tip physically exist in the model |

They are studied because each one silently changed the answer. Details below.

---

## 2. How are they manipulated in the code?

### band

The band is two numbers on the geometry sample: `elevon_start_frac` and
`elevon_end_frac` (nominally 0.60 and 0.95). They are design variables — the DoE
varies them. `build_pygeo_sections_from_config` reads them and passes them onward
as `control = (name, start, end, hinge_x)`.

In `native_avl.py:271`, every section is tested against that pair, and only
sections inside it get a control:

```python
frac = float(getattr(sec, "span_fraction", le[1]))
if control and ctrl_start - 1e-9 <= frac <= ctrl_end + 1e-9:
    lines += ["CONTROL", ..., f"{ctrl_name}_sym 1 {ctrl_hinge} 0 0 0  1", ...]
```

`1` is the gain, `ctrl_hinge` is the hinge position in local chord fraction
(0.75 = hinge at 75% chord), and `SgnDup` is `+1` for the symmetric copy and `-1`
for the differential one. Two `CONTROL` blocks on the same hinge is how one
physical elevon does both pitch and roll: right elevon = `de + da`, left = `de − da`.

### gain ramp

This one is not written anywhere. It **emerges**, and that is exactly why it needed
studying. AVL linearly interpolates the control gain between consecutive sections.
So if the band ends at 0.95 and the next section outboard is at 1.00, AVL does not
put a hard edge at 0.95 — it fades the gain from 1 at 0.95 to 0 at 1.00. That whole
0.05-wide interval flies a **half-deflected elevon that does not exist**.

The ramp fraction is that leaked width divided by the band width:

```python
# src/aeris/geometry/geometric_information.py
below = f[f < lo - 1e-9]; above = f[f > hi + 1e-9]
ramp = ((lo - below[-1]) if below.size else 0.0) + ((above[0] - hi) if above.size else 0.0)
return float(ramp / width)
```

Band 0.60–0.95 with neighbours at 0.5417 and 1.0: leaked width
(0.60 − 0.5417) + (1.0 − 0.95) = 0.108, band width 0.35 → **ramp = 31%**. Nearly a
third of the elevon's authority is smeared onto wing that has no elevon. That is
not a rounding effect, it is a modelling error, and it is why the ramp fraction has
a config limit (`ramp_fraction_limit: 0.15`).

**This is also where one of our bugs lived.** The original code tagged only the
inboard section of each interval, which let the gain taper away across the
outboard-most interval and silently deleted part of the elevon. The fix (the
comment at `native_avl.py:259-264`) is to tag *both* boundary sections.

### span-margin

One number: `linspace(margin, 1 − margin, n)`. With `margin = 0.02` the outermost
section sits at 98% span, so **the real wing tip is never modelled** — AVL's tip
vortex forms 2% inboard of where it should. It used to default to 0.02. It now
defaults to **0.0**, and `native_avl.py:389` carries the note explaining why. This
was a real error being introduced deliberately to dodge a numerical worry that
turned out not to exist.

---

## 3. "Error percent" — against *what*?

Fair confusion, because the answer is different in different studies and I did not
always say which. There are only three references used anywhere, and every number
is one of them:

| Reference type | Meaning | Used in |
|---|---|---|
| **Grid reference** | the *same geometry, same solver*, run at much finer discretisation (e.g. 49 sections vs 25) | convergence & placement studies |
| **Closed-form physics** | a formula with a known answer — e.g. lifting-line `CLa = 2πAR/(AR+2)`, `e = 1` for an elliptic load | physics validation |
| **Cross-code** | AeroSandbox's AVL wrapper on the same geometry | the DoE comparison only |

So "the narrow elevon showed 4.34% error" means: **this quantity, computed on a
25-section mesh, differs by 4.34% from the same quantity on a 49-section mesh of
the same aircraft.** It is a statement about *our own discretisation being too
coarse*, not about AVL being wrong and not about the aircraft.

Never a comparison to wind-tunnel data. We have none. Nothing in these studies
claims physical accuracy — they claim *numerical* convergence.

### The one rule that matters here

A percentage is meaningless when the reference is tiny. AVL prints 6 decimals, so
its smallest distinguishable output is 1e−6. The yaw-due-to-roll-control
derivative `Cn_da` has a reference around −2.3e−05. One unit in AVL's last printed
digit is therefore 1e−6 / 2.3e−5 = **4.35% "error" from rounding alone**.

That is why the earlier metric study was invalid: it ranked policies on `Cn_da`,
and seven of nine policies scored *exactly* 4.348% on meshes with 6× different ramp
fractions. It was ranking rounding noise. Every study now drops any quantity whose
reference is below **1e−4** (100× the print resolution).

---

## 4. What is the "geometric information metric" and how is it built?

**In one sentence: it is a curve along the span that is tall where the wing's shape
is changing fast, and short where the wing is nearly straight — so that sections
can be put where the shape actually needs describing.**

The idea is old and standard (de Boor 1973): if you are going to approximate a
curve with straight segments, the error is smallest when you space the points so
that each segment carries equal `|second derivative|^(1/2)`. Straight regions need
few points; sharply curving regions need many.

Built in five steps, in `src/aeris/geometry/geometric_information.py`:

**Step 1 — sample the shape.** Walk the span on a fine grid and record seven
numbers at each station, the "channels":

`x_le` (leading-edge sweep) · `z_le` (dihedral) · `chord` · `twist` ·
`thickness` · `camber` · `control_gain`

**Step 2 — divide each channel by a fixed physical scale** so they are comparable:
lengths by root chord, twist by 10°, thickness and camber by 0.1.

```python
CHANNEL_REFERENCE_SCALES = {"x_le": ..., "twist": 10.0, "thickness": 0.1, ...}
```

This step is where the metric was **broken and got fixed**. The original code
normalised each channel to unit integral, which erased magnitude: a 40° sweep break
and a 0.02° twist wiggle both integrated to exactly 1.000 and got equal say. A
fixed physical scale means a big change looks big. Fixing this *reversed* Task 6's
verdict — the metric went from "10× worse than uniform" to a win.

**Step 3 — take the curvature.** Second difference along the span, absolute value,
then square root. That is the de Boor density `ρ(y) ∝ |g''(y)|^(1/2)`.

**Step 4 — combine the channels by taking the WORST one** (`combine="max"`), not
the average. Averaging lets six calm channels dilute one violent one; the whole
point is to catch the violent one.

**Step 5 — clamp the floor at 0.50** so no region can be starved of sections
entirely, and weight `control_gain` ×3 (control edges matter most) and
`thickness` ×0 (AVL is a **mean-surface** method — it sees camber and never sees
thickness, so thickness curvature is information AVL cannot use).

The output is a density curve. Its cumulative integral, inverted, gives the section
positions: equal information per interval.

---

## 5. So how do sections *actually* get placed? The literal sequence.

In `pygeo_avl_adapter.py`, in this order:

**(a) Uniform base grid.** `n_sections` is the FINAL count you want (25). Subtract
the pins you're about to insert, then space the rest evenly:

```python
n_base = int(n_sections) - (len(interior_pins) if snap_sections_to_control else 0)
fractions = np.linspace(lo, hi, n_base)
```

**(b) Insert the hard pins.** Six span fractions where the geometry has a genuine
kink, computed from the sample itself:

```python
feature_pins = [0.0, (1-b3_ratio)*split_ratio, 1-b3_ratio, elevon_start, elevon_end, 1.0]
fractions = np.unique(np.concatenate([fractions, feature_pins]))
```

They are **inserted**, never substituted. That distinction was another bug: the old
code replaced the nearest neighbour, which dropped 2 of the 6 pins and widened the
gaps. And band-edge snapping used to *move* a section onto the edge, which widened
the gain ramp from 11.8% to 23.0% — the opposite of the intent.

**(c) Check the ramp criterion.** Compute the ramp fraction of the grid so far. If
it is already under 15%, **stop — ship the uniform+pinned grid.** The adaptive
machinery does not run. This is the gate:

```python
uniform_ramp = ramp_fraction(fractions, band)
if mode == "always" or (mode == "auto" and uniform_ramp > limit):
    ...
```

**(d) Only if the gate opens:** build the information profile from §4 and
re-distribute the non-pin sections by equal-information spacing, keeping all pins.
Accept it only if it actually *improves* the ramp fraction.

**(e) Top the budget back up.** A pin can land exactly on a base station, and the
dedupe then leaves 24 instead of 25. Bisect the largest remaining gap until the
count is right — which also happens to repair the worst gradation jump.

**(f) Extract.** Those fractions go to pyGeo, which evaluates the loft and returns
an `ExtractedSection` per station. Those become `SECTION` blocks in the `.avl`.

### The short version

> Even spacing → force sections onto the 6 real kinks → if the elevon edges are
> still smeared more than 15%, re-space by shape-change density → make sure the
> count is exactly what was asked → hand to pyGeo.

For the great majority of geometries, step (d) never runs. That is deliberate: the
adaptive path only engages where a written-down criterion says the simple path has
failed.

---

## The bugs these words uncovered

Worth stating plainly, because the studies exist for a reason:

1. Three elevon design variables never reached AVL — every aero run in the DoE flew
   the same nominal elevon.
2. Only the inboard boundary section was tagged, so part of every elevon was
   silently ramped away.
3. `span_margin = 0.02` meant the wing tip was never modelled.
4. Band-edge snapping moved sections instead of inserting them, *doubling* the
   gain ramp.
5. `must_include` pins replaced their neighbours, dropping 2 of 6.
6. The information metric erased magnitude, so a sweep break and a wiggle counted
   the same.

None of these would have been found by comparing AERIS to another code — several
would have been present in both.
