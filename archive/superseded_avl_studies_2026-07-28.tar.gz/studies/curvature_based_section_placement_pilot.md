# Pilot study — Curvature-based section placement for AVL

Date: 2026-07-26
Module under review: `src/aeris/geometry/geometric_information.py`
Pilot script: `standalone/lowfi_avl_study/curvature_monitor_placement_study.py`
Artifacts: `artifacts/curvature_monitor_placement_study/`

## 1. Rename the idea

The old name, **geometric information metric**, is too grand and slightly
misleading. This is not Shannon information, Fisher information, or statistical
information.

The correct name is:

> **curvature-based interpolation-error monitor**

That is exactly what the method does. AVL receives spanwise `SECTION`s and
linearly interpolates between them. Therefore the placement error is mostly an
interpolation error. For a spanwise quantity `g(y)`, linear interpolation error
scales like:

```text
error ~ h^2 * |g''(y)|
```

So the simple rule is:

```text
large second derivative -> closer AVL sections
small second derivative -> wider AVL sections
zero second derivative  -> AVL already represents it with straight interpolation
```

This is simple enough to explain to a professor without pretending it is a new
theory of information.

## 2. What channels are monitored

The method treats each AVL-interpolated spanwise quantity as one channel:

| channel | what it detects |
|---|---|
| `x_le` | changes in leading-edge sweep |
| `z_le` | changes in dihedral |
| `chord` | changes in taper rate |
| `twist` | nonlinear twist |
| `thickness` | airfoil-thickness transitions |
| `camber` | camber transitions |
| `control_gain` | elevon start and end |

The control channel is not an AVL manual term. It is an AERIS-side model of what
AVL sees: control is active inside the elevon span and inactive outside it. Between
two `SECTION`s, AVL linearly interpolates that control state.

## 3. Current formula vs cleaner formula

The current AERIS formula is:

```text
rho_current(y) = sum_k w_k * sqrt(abs(g_k''(y)))
```

That is a reasonable heuristic, but the cleaner derivation is:

```text
combined_error(y) ~ h^2 * sum_k w_k * abs(g_k''(y))
```

which gives:

```text
rho_proposed(y) = sqrt(sum_k w_k * abs(g_k''(y)))
```

The pilot script compares both without changing production code.

## 4. What this pilot did

This was a geometry-only pilot on 12 deterministic random designs from
`configs/geometry/bwb.yaml`.

It compared three section-placement policies:

| policy | meaning |
|---|---|
| `uniform_plus_edges` | 25 equal sections plus exact elevon start/end pins |
| `current_sum_sqrt` | current AERIS monitor: `sum(w * sqrt(abs(g'')))` |
| `proposed_sqrt_sum` | cleaner monitor: `sqrt(sum(w * abs(g'')))`, with exact-count repair |

No AVL was run. Therefore these are **not aerodynamic error numbers**. They only
measure section placement quality proxies: ramp fraction, section count, and
maximum spacing.

## 5. Geometry-only results

| policy | mean ramp | max ramp | mean max-gap ratio | section count range |
|---|---:|---:|---:|---:|
| `uniform_plus_edges` | 13.9 % | 26.2 % | 1.00x | 27-27 |
| `current_sum_sqrt` | 11.8 % | 17.9 % | 1.87x | 25-25 |
| `proposed_sqrt_sum` | 11.6 % | 18.5 % | 1.87x | 25-25 |

Interpretation:

- Both adaptive monitors reduce average ramp fraction compared with uniform-plus-edge placement.
- The proposed formula behaves very similarly to the current formula on these random designs.
- The proposed formula is slightly better on mean ramp, slightly worse on worst ramp in this small sample.
- Both adaptive methods create larger gaps than uniform spacing. This confirms that a real spacing/growth constraint is better than relying only on the `floor = 0.50` safety knob.

## 6. Why the control surface has weight 3

The control channel currently has weight `3.0`; the other channels have weight
`1.0`.

That is not a physics constant.

It is a numerical-priority choice. The low-fidelity studies found that the largest
AVL discretisation problem was not area, MAC, sweep, or basic lift. It was the
elevon derivative, especially `CL_delta_e`. In simple words:

> The wing shape was already resolved well enough before the control surface was.

So the code gives the control channel extra weight to stop the adaptive placement
from spending too many sections on smooth wing regions while missing the elevon
edges.

The honest explanation is:

```text
weight 3 means: "control accuracy matters more in this study because the design
loop needs trustworthy elevon authority."
```

It does **not** mean:

```text
control surfaces are physically three times more important than chord or twist.
```

The number should be treated as a calibrated heuristic. If the study objective is
clean-wing lift/drag only, the control weight should be reduced or removed. If the
study objective is control authority, the extra weight is justified, but it should
be reported.

## 7. What should change before publication

Recommended changes before this appears in a paper:

1. Rename the method to **curvature-based interpolation-error monitor**.
2. Change the blend from `sum(w * sqrt(abs(g'')))` to `sqrt(sum(w * abs(g'')))`.
3. Pin known features explicitly: root, tip, planform breaks, airfoil stations,
   elevon start/end, and any other discontinuities.
4. Make `must_include` preserve the exact requested section count by inserting
   replacement nodes into the largest gaps.
5. Replace or supplement `floor = 0.50` with a direct max-spacing or cell-growth
   constraint.
6. Improve airfoil-change detection using CST/Kulfan coefficients instead of only
   thickness and max camber.
7. Fix stale code comments that still say each channel is normalized to unit
   range or unit integral.

## 8. What this pilot does not prove

This pilot does **not** prove that the proposed placement gives lower AVL
coefficient error.

To prove that, the next study must run AVL and compare:

```text
uniform placement
current adaptive placement
proposed adaptive placement
finer reference placement
```

for at least:

```text
CL, CDind, Cm, CL_delta_e, Cl_delta_a, Cma, Xnp
```

Until that is done, the proposed formula is mathematically cleaner and easier to
defend, but it is not yet aerodynamically validated.

## 9. Bottom line

The present AERIS method is a good prototype, but the paper should not call it an
information metric.

Use this wording:

> AVL represents the spanwise geometry by piecewise-linear interpolation between
> user-defined sections. We therefore place sections using a curvature-based
> interpolation-error monitor built from the second derivatives of the spanwise
> geometry and control-gain channels.

That is honest, simple, and defensible.
