# The sweet spot: what panelling makes AVL a DSE tool instead of a verification tool

**Status: decided — DECISION-0013. Supersedes the panel count in DECISION-0009.**

## The problem, stated bluntly

A single low-fidelity design point was taking **58 seconds**. At that rate a
2000-design sweep with 5 angles of attack each is **6.7 days**. That is not a
design-space-exploration tool; it is a verification tool that we had mislabelled.

DECISION-0009 chose 24 chordwise panels because 8 panels carry ~7.7% error on
elevon authority. That reasoning was correct as far as it went, and it went only
half way: **it never priced the choice.** Accuracy was optimised against nothing.

## Where the 58 seconds actually goes

| stage | time |
|---|---|
| pyGeo loft + extract 25 sections | 1.36 s |
| NeuralFoil viscous correction | 0.60 s |
| **AVL solve** | **56.93 s** |

![stages](figures/dse_panelling/03_stage_breakdown.png)

The solver is the entire cost; geometry and the viscous correction are noise. This
matters because the intuitive suspects — B-spline lofting, 25 NeuralFoil polar
evaluations — are innocent. There is no point optimising them.

## Why AVL is slow here, and why that is our fault

AVL builds a **dense** aerodynamic influence matrix over every vortex and
factorises it. Cost therefore grows roughly with the **cube** of the vortex count.
The measured sweep gives an exponent of 1.9–2.6 over this range, consistent with a
matrix build (N²) plus factorisation (N³) in the regime where neither dominates.

Our production mesh was 192 strips × 24 chordwise = **4608 vortices, 77% of AVL's
compiled ~6000 limit**. AVL is a 1980s vortex-lattice code sized for meshes in the
hundreds to low thousands. We were running it near its ceiling on every single
design point, by choice, and then concluding that AVL is slow.

![tradeoff](figures/dse_panelling/01_cost_accuracy_tradeoff.png)

## The measurement

Nominal geometry (seed 7000), 25 sections, 4 spanwise panels per interval,
alpha 6°, V 28 m/s, elevon δe = δa = 4°, viscous on. Reference is 30 chordwise —
the richest **legal** mesh at this spanwise resolution (32 would be 6144 vortices,
over the limit).

| nchordwise | vortices | time | speedup | worst error | which quantity |
|---|---|---|---|---|---|
| 4 | 768 | 1.8 s | 48× | 15.94% | CL_δe |
| 6 | 1152 | 3.7 s | 23.5× | 10.22% | CL_δe |
| 8 | 1536 | 6.9 s | 12.6× | 7.41% | CL_δe |
| **12** | **2304** | **14.6 s** | **5.9×** | **3.76%** | **CL_δe** |
| 16 | 3072 | 25.4 s | 3.4× | 1.79% | CL_δe |
| 24 | 4608 | 57.3 s | 1.5× | 0.62% | CL_δe |

![scaling](figures/dse_panelling/02_vortex_scaling.png)

### The decisive detail

**Every setting's worst error is a control derivative.** Everything else is
converged far earlier:

| nchordwise | CL | Cm | Xnp | CL_δe | Cm_δe |
|---|---|---|---|---|---|
| 8 | 1.07% | 1.47% | 0.00% | 7.41% | 7.00% |
| 12 | 0.51% | 0.67% | 0.00% | 3.76% | 3.48% |
| 16 | 0.23% | 0.33% | 0.00% | 1.79% | 1.59% |

`Xnp` reads **0.3350 at every setting from 6 panels upward** — the neutral point is
fully converged by 6 chordwise panels. Lift, pitching moment and the stability
derivatives are all inside 1.5% by 8. Only the hinge-line quantities need panels,
because resolving a control surface means putting enough panel edges aft of the
hinge (DECISION-0010: error ~ N_flap^−1.47).

So the expensive panels are buying **one class of quantity**, not general accuracy.

![which quantity](figures/dse_panelling/04_which_quantity_needs_panels.png)

## Why 3.76% is acceptable for a DSE — the part that had to be checked

A large error is only tolerable in design-space exploration if it is a consistent
**bias** rather than scatter. A bias shifts every design by nearly the same factor
and therefore cancels when designs are *ranked* against each other; scatter
reorders them and makes the sweep worthless.

The sweep shows CL_δe rising monotonically — 0.00983, 0.01050, 0.01083, 0.01126,
0.01149, 0.01163 — which is the signature of a bias, not noise. That was then tested
directly across **7 geometries** (nominal, narrow elevon, wide elevon, max gradient,
max AR, two random DoE draws) by measuring the ratio cheap/rich per geometry:

| quantity | mean ratio 12/24 | bias | spread across geometries | spread as % of bias |
|---|---|---|---|---|
| CL | 0.9967 | 0.33% | 0.0032 | 1.0% |
| Cm | 0.9955 | 0.45% | 0.0041 | 0.9% |
| Xnp | 1.0000 | 0.00% | 0.0005 | — |
| CLa | 1.0000 | 0.00% | 0.0004 | — |
| Cmq | 1.0000 | 0.00% | 0.0004 | — |
| **CL_δe** | **0.9689** | **3.11%** | **0.0066** | **0.2%** |
| **Cm_δe** | **0.9712** | **2.88%** | **0.0077** | **0.3%** |

This is the result that licenses the cheap tier. The control-derivative penalty is a
**near-pure multiplicative bias**: the spread across seven very different geometries
is 0.2–0.3% of the bias itself. The 12-panel mesh underestimates elevon authority
by a consistent ~3.1% regardless of shape, so any comparison *between* designs is
essentially unaffected. `Xnp`, `CLa` and `Cmq` carry no bias at all — the ratio is
1.0000 — so the "% of bias" column is meaningless for them (it divides by ~zero).

![bias](figures/dse_panelling/05_bias_not_scatter.png)

## The decision: two tiers, not one compromise

| tier | nchordwise | cost/point | use |
|---|---|---|---|
| **DSE** | **12** | 14.6 s | design-space sweeps, DoE, optimisation, screening |
| **Verification** | 24 | 57.3 s | promoted designs, control-authority sizing, anything feeding CFD |

`configs/geometry/bwb.yaml` now ships **12**. Raise it with `--nchordwise 24` (CLI)
or the GUI's chordwise field for verification work.

Why 12 and not 8 or 16:

- **8** (6.9 s) halves the cost again but doubles the control-derivative error to
  7.4%. Elevon authority is a *sizing* quantity for this aircraft, not a
  by-product, so 7% is too coarse to screen on.
- **16** (25.4 s) buys 1.79% for 1.7× the time. Defensible, but it puts a
  2000-design sweep back to 14 hours versus 8.
- **12** is where the cost curve crosses back under the "overnight sweep" threshold
  while keeping every non-control quantity under 0.7%.

There is no sharp knee in this curve — returns are close to constant-elasticity —
so the choice is properly made against a **requirement**, not against curvature.
The requirement is: an overnight DoE, with force/moment/stability quantities inside
1% and control derivatives carrying a stated, bias-dominated ~4%.

## Revised arithmetic

| sweep | at 24 chordwise | at 12 chordwise |
|---|---|---|
| 10 designs × 5 α | 48 min | 12 min |
| 500 designs × 5 α | 40 h | 10 h |
| 2000 designs × 5 α | 6.7 days | **20 h** |

## What is not claimed

- The reference is a finer AVL mesh, not CFD or experiment. This establishes
  **discretisation convergence**, not physical accuracy.
- The sweep is one geometry. The bias-consistency check covers 7; the *cost* curve
  is single-geometry because cost depends on vortex count, which is set by the
  discretisation and not by the shape.
- 12 is calibrated for 25 sections × 4 spanwise panels. Change the spanwise
  resolution and the vortex budget moves; `write_native_avl` now refuses
  over-limit combinations outright rather than letting AVL fail opaquely.

## A defect found on the way

The first attempt at this study returned `NaN` for every quantity. The cause: a
49-section reference at 4 spanwise panels and 24 chordwise is 9216 vortices, past
AVL's limit — and **AVL's response is not an error message**. It returns a run with
`status=FAILED` and every coefficient `None`, indistinguishable from a physics
failure. `AeroDiscretisationConfig.avl_limits_ok()` already existed but was only
consulted at config-parse time, so nothing guarded a direct call.
`write_native_avl` now raises with a specific, actionable message. Two tests cover
both limits (`tests/aero/test_native_avl_physics_validation.py`).

## Reproduce

```bash
python configs/aero/dse_panelling_evidence/cost_sweep.py
python standalone/lowfi_avl_study/dse_bias_check.py
```

Evidence (tracked, survives `data/` being wiped):
`configs/aero/dse_panelling_evidence/`.
