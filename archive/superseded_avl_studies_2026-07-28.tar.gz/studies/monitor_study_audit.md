# Audit: the section-placement study does not establish its conclusion

**Status: the shipped `section_placement: auto` (DECISION-0014) is not supported by
the evidence behind it.** This document says why, using only data already on disk.
No new solver runs were made.

Evidence re-analysed: `artifacts/curvature_monitor_aero_study/` (100 native AVL
runs, 10 geometries × 9 policies + reference), `configs/aero/placement_decision_evidence/`,
`configs/aero/placement_audit_evidence/`.
Re-analysis script: `standalone/lowfi_avl_study/reanalyse_monitor_study.py`.
Output: `configs/aero/monitor_study_reanalysis/`.

---

## 1. The ranking is an artefact of the score definition

The same 90 comparison rows were re-scored under seven defensible definitions of
"error": with and without the print-noise floor, with and without drag, control-only,
forces-and-stability-only, and aggregated by max / mean / median over the ten
geometries. Nothing else changed.

| policy | D1 | D2 | D3 | D4 | D5 | D6 | D7 | rank spread |
|---|--:|--:|--:|--:|--:|--:|--:|--:|
| `sqrt_sum_w1` | 2 | 8 | 2 | 2 | 3 | 2 | 3 | **2–8** |
| `max_channel_w3_no_thickness` | 8 | 1 | 1 | 1 | 8 | 1 | 5 | **1–8** |
| `sqrt_sum_w3_gap15` | 1 | 4 | 7 | 7 | 2 | 4 | 1 | **1–7** |
| `sqrt_sum_w3_no_thickness` | 7 | 2 | 5 | 5 | 5 | 3 | 2 | 2–7 |
| `current_sum_sqrt_w3` | 4 | 5 | 4 | 4 | 6 | 7 | 7 | 4–7 |
| `max_channel_w3` | 6 | 3 | 6 | 6 | 7 | 5 | 4 | 3–7 |
| `sqrt_sum_w3` | 5 | 6 | 3 | 3 | 9 | 6 | 6 | 3–9 |
| `uniform_pinned25` | 3 | 7 | 8 | 8 | **1** | 8 | 8 | **1–8** |
| `sqrt_sum_w0` | 9 | 9 | 9 | 9 | 4 | 9 | 9 | 4–9 |

D1 everything, no floor · D2 everything + floor · D3 no drag + floor ·
D4 control only + floor · D5 forces+stability + floor · D6 = D3 by mean ·
D7 = D3 by median.

Every policy moves at least three places. Three of them span seven or eight.
The two policies that have been declared "the winner" at different times —
`sqrt_sum_w3_gap15` and `max_channel_w3_no_thickness` — each rank 1st under some
definitions and 7th or 8th under others.

**A ranking that inverts under a reasonable change of score is not a result.**

---

## 2. Excluding drag hid the cost of adaptive placement

The rule "never rank spanwise discretisation with drag" was introduced because the
reference disagrees with itself on drag. Applying it deleted the quantity the design
study actually optimises. That was the wrong response, and it concealed a systematic
effect.

Induced drag, per geometry, relative error against the 49-section reference:

| policy | CDind mean | CDind max |
|---|--:|--:|
| `sqrt_sum_w0` | 0.23% | 0.58% |
| **`uniform_pinned25`** | **0.24%** | **0.50%** |
| `max_channel_w3_no_thickness` | 0.38% | 0.76% |
| `sqrt_sum_w3_no_thickness` | 0.39% | 0.64% |
| `sqrt_sum_w1` | 0.39% | 0.66% |
| `sqrt_sum_w3` | 0.42% | 0.74% |
| `max_channel_w3` | 0.47% | 0.77% |
| `sqrt_sum_w3_gap15` | 0.51% | 0.83% |
| `current_sum_sqrt_w3` | 0.51% | 0.77% |

Paired sign test, uniform+pins against each of the eight adaptive monitors, ten
geometries each:

```
pooled: uniform better on 59 of 80 paired comparisons
one-sided binomial p = 1.3e-05
```

This is not scatter. Adaptive placement is systematically worse on induced drag,
and it is worse on forces and stability too (D5 ranks `uniform_pinned25` first).
Adaptive wins only on the control derivatives — the one channel the monitor is
weighted 3× to favour.

**So the true shape of the result is a trade, not a win:** adaptive placement buys
control-derivative accuracy and pays for it in drag, forces and stability. The
shipped decision recorded the purchase and not the price, because the price was in
the quantity that had been excluded.

### There is a plausible mechanism

AVL's induced drag is a Trefftz-plane integral of the spanwise circulation, and the
strips are its quadrature nodes. Uniform spacing is a well-conditioned quadrature of
a smooth, near-elliptic load. Clustering strips onto geometric features starves the
outboard span, where dΓ/dy is largest and where most of the induced-drag integrand
lives. A monitor built to resolve *geometry* is not built to integrate *load*.

### But the measurement is confounded

The reference is `reference_uniform49` — uniform placement with the same pins.
`uniform_pinned25` therefore shares the reference's construction, which flatters it.
Two explanations predict the same sign:

- **(a)** non-uniform strips genuinely degrade the drag quadrature;
- **(b)** uniform candidates converge to a uniform reference faster.

**The existing data cannot separate them.** This is the same defect flagged in the
placement audit — "never build a reference that shares one candidate's construction"
— which was written down and then not acted on.

---

## 3. Five more defects

**3.1 The reference is not converged and was never shown to be.** It disagrees with
itself by 1.2–2.9% on drag and up to 1.20% on control derivatives, and refining it
49 → 73 → 97 does not converge the disagreement away (2.90% / 1.37% / 1.17%). The
effect being resolved between policies is ~0.3–1.0 pp. The instrument is less
precise than the thing it measures.

**3.2 The score is circular.** Under the noise floor, dropping drag leaves a score
that is *identical* to control-only (D3 and D4 produce the same ranking to the
digit) — control errors dominate every other admissible quantity in every case. So
the monitor was tuned with `control_weight = 3` and then judged by a control-dominated
metric.

**3.3 n = 10, ranked by a maximum.** Both studies rank partly on the worst of ten
samples. A max over ten is unstable. Paired sign tests on the aggregate score show
the top policies are indistinguishable — `max_channel_w3_no_thickness` goes 5–5,
5–5, 3–4 and 3–7 against its nearest rivals. Six different policies each win at
least one geometry outright.

**3.4 One operating point.** Everything was run at α = 6°, β = 0, V = 28 m/s,
δe = δa = 4°. A discretisation rule for a DSE tool has to hold across the polar,
and the polar sweep that exists was run separately on two geometries only.

**3.5 One-at-a-time variation.** Thickness on/off, weight 0/1/3, combine rule, gap
repair were each varied from a baseline rather than crossed. Interactions are
invisible — and `no_thickness` helps under `max_channel` but the weight sweep was
only run under `sqrt_sum`, so the two changes actually shipped together were never
tested together.

---

## 4. What is actually established

Firm, and unaffected by any of the above:

- **Hard feature pins are worth having.** Removing them takes the worst case from
  under 2% to 34.54%. That is an order-of-magnitude effect, far outside every noise
  source discussed here, and it has a mechanism: `|g''|^½` equidistribution cannot
  resolve a true kink however much density it piles nearby.
- **AVL fails silently over its array limits** and must be guarded.
- **Relative error on a reference below ~1e-4 is print rounding**, not physics. This
  invalidated the original ranking, in which seven of nine policies scored an
  identical 4.348% on meshes with 6× different discretisation.

Not established, and currently shipped as if it were:

- **that adaptive placement beats uniform + pins.** The aggregate difference is
  0.05–0.1 pp against a reference whose own noise is ≥0.65 pp; the sign flips with
  the score definition; and on the drag objective the sign is consistently against
  adaptive.
- **which channel-combination formula is best.** `sqrt_sum`, `max_channel` and the
  incumbent `sum_sqrt` are inseparable at this sample size.
- **that thickness weight 0 is right.** The argument is sound — AVL's core is a
  mean-surface method — but the measurement supporting it is inside the noise.

---

## 5. What a serious benchmark requires

**5.1 Delete the external reference.** A discretisation study does not need a
"truth" grid, and any truth grid built by one of the candidate rules is
contaminated. Run each placement family over an h-refinement ladder and measure
self-convergence — `|f(n) − f(2n)|` — with no reference at all. Fit the observed
order of convergence and Richardson-extrapolate to h → 0. That yields a limit with
no placement of its own, and it answers the question that matters: *which rule
converges faster, and do the two rules converge to the same aircraft?* If they
converge to different values, one of them is wrong and the error ranking was
meaningless.

Feasible ladder at 2 spanwise panels / 12 chordwise, inside AVL's 500-strip and
6000-vortex limits: n = 13, 17, 21, 25, 33, 41, 49, 61, 73, 97, 121.

**5.2 Score on the decision, not the coefficient.** The tool ranks designs. The
question is not "what is the error in CL_δe" but "does the placement rule change
which design wins?" Run a fixed DoE at each placement rule and measure rank
correlation against the converged limit. A rule that shifts every design by the same
amount costs nothing; a rule that reorders them is disqualifying regardless of its
absolute error.

**5.3 Report drag.** It is the objective. If a placement rule degrades induced drag,
that is the headline, not a footnote — and if the reference is too noisy to say so,
fix the reference (5.1) rather than remove the quantity.

**5.4 Cross the factors.** {sum_sqrt, sqrt_sum, max_channel} × {thickness 0, 1} ×
{control weight 0, 1, 3}, not one-at-a-time.

**5.5 Fix the sample and the statistics in advance.** More geometries drawn from the
DoE distribution the tool will actually see, not hand-picked stress cases mixed with
seeds; and a stated aggregation and paired test written down before the run.

**5.6 More than one operating point.** At minimum low, cruise and high α, since the
spanwise load — which is what the strips are sampling — changes shape across it.

---

## 6. Recommendation

Mark DECISION-0014 **disputed, not withdrawn**, and leave the configuration alone
until 5.1 has been run. The configuration has already been flipped once on this
evidence; flipping it a third time on the same inconclusive data would repeat the
mistake rather than correct it.

The convergence study in 5.1 is the smallest experiment that can settle it:
11 levels × 2 families × 10 geometries ≈ 220 runs, roughly 75 minutes at the DSE
tier — and unlike the 100 runs already spent, its conclusion does not depend on
choosing a score.
