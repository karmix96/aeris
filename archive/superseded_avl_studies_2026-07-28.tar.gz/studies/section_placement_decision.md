# Which section-placement approach should AERIS use?

**Status: decided — see the verdict below. Supersedes the ranking in `curvature_monitor_metric_evaluation.md`.**

## Why this study exists

The configuration AERIS adopted in DECISION-0012 had never itself been measured. The earlier study measured a policy of the *same name* but a different implementation: pins **replaced** their nearest neighbour (losing pins and widening gaps) and the section budget drifted — asking for 25 produced 29. Ranking numbers from that run therefore do not transfer to the code that ships. This study measures the shipped code.

## What is being compared

| | approach | what it does |
|---|---|---|
| A | uniform, no pins | evenly spaced sections; only the elevon edges land on features |
| B | uniform + hard pins | evenly spaced, then the six planform/control breakpoints are **inserted** as sections |
| C | **adopted** | B, plus the worst-channel geometric-information monitor, switched on only when the gain-ramp criterion is violated |
| D | monitor always on | same monitor, forced on every geometry |

## Method

- **10 geometries**: 6 hand-built stress cases (benign, nominal, narrow elevon, wide elevon, maximum planform gradient, maximum aspect ratio) + 4 random DoE draws.
- **Equal budget**: every approach gets **exactly 25 sections**. This is the property the earlier study lacked, and without it the comparison is not a comparison of *placement* — it is a comparison of resolution.
- **Reference**: the same geometry at **49 sections** with **2 spanwise panels** per interval, uniform + pinned. This is *panel-matched*: the candidates run 25 sections x 4 panels = 96 strips per side, and the reference runs 49 x 2 = the same 96 strips per side, the same 4608 vortices, but twice as many geometric stations defining the loft. So the comparison isolates what placement governs — how well a finite set of stations describes the shape and the control edges — instead of confounding it with panel resolution. (A 49x4 reference would be 9216 vortices, past AVL's ~6000 array limit; it returns `status=FAILED` with every coefficient `None`. That silently NaN'd the first run of this study, and `write_native_avl` now raises on it instead.)
- **Condition**: alpha 6.0°, V 28.0 m/s, elevon symmetric 4.0°, differential 4.0°, viscous (NeuralFoil CDCL) on.
- **Print-noise floor**: a relative error is only counted when the reference magnitude exceeds `0.0001` — 100× AVL's printed resolution of 1e-6. Omitting this floor is what invalidated the previous ranking: `Cn_da` has a reference of −2.3e−05, so one unit in AVL's last printed digit *is* 4.35% error, and seven policies scored exactly 4.348% on meshes with 6× different ramp fractions.

## Result

| approach | mean worst-control | **max worst-control** | mean worst-any | max worst-any | per-case wins |
|---|---|---|---|---|---|
| B — uniform + hard pins **←** | 0.82% | **1.98%** | 1.02% | 1.98% | 4/10 |
| C — adopted (pins + monitor, gated) | 0.77% | **1.68%** | 1.57% | 2.96% | 6/10 |
| D — monitor always on | 0.76% | **1.68%** | 2.69% | 5.87% | 6/10 |
| A — uniform, no pins | 15.17% | **34.54%** | 15.58% | 34.54% | 0/10 |

![ranking](figures/placement_decision/02_summary_ranking.png)

### Per geometry

Worst control-derivative error, then the gain-ramp fraction that explains it. `placement` is what the gate actually chose for C.

| geometry | A | B | C | D | ramp A | ramp C | C chose |
|---|---|---|---|---|---|---|---|
| benign | 13.41% | 0.49% | 0.49% | **0.32%** | 11.8% | 7.6% | uniform |
| nominal | 16.23% | **0.25%** | **0.25%** | 0.65% | 11.8% | 7.6% | uniform |
| elevon_narrow | 15.55% | 1.52% | **0.63%** | **0.63%** | 38.9% | 13.0% | adaptive |
| elevon_wide | 5.56% | 0.92% | 0.92% | **0.57%** | 12.8% | 14.6% | uniform |
| max_gradient | 13.73% | 0.66% | **0.33%** | **0.33%** | 11.8% | 7.4% | adaptive |
| max_ar | 14.29% | **0.30%** | **0.30%** | 0.31% | 11.8% | 7.6% | uniform |
| random_1001 | 34.54% | **0.81%** | 1.68% | 1.68% | 10.6% | 16.1% | adaptive |
| random_1002 | 7.53% | **0.45%** | 0.91% | 0.91% | 18.7% | 6.6% | adaptive |
| random_1010 | 6.25% | 0.85% | **0.83%** | **0.83%** | 26.2% | 3.7% | adaptive |
| random_1020 | 24.62% | 1.98% | **1.42%** | **1.42%** | 13.6% | 10.9% | adaptive |

![per case](figures/placement_decision/01_per_case_control_error.png)

### Mechanism

Placement does not act on the derivatives directly. What it changes is the **gain-ramp fraction**: AVL interpolates control gain linearly between sections, so the two intervals just outside the elevon band carry a half-deflected elevon. Their combined width divided by the band width is the ramp fraction, and DECISION-0010 measured r = +0.978 between it and control-derivative error.

![mechanism](figures/placement_decision/03_ramp_mechanism.png)

The cost side is gradation: inserting pins and grading toward high-information regions leaves a larger largest-gap than uniform spacing.

![cost](figures/placement_decision/04_gradation_cost.png)

![per quantity](figures/placement_decision/05_per_quantity.png)

## What the geometric-information metric actually is

Before the verdict, the thing being judged. The monitor is a curve along the span
that is **tall where the wing's shape changes fast and short where it is nearly
straight**, so sections can be spent where shape actually needs describing. The idea
is de Boor (1973): to approximate a curve with straight segments, error is minimised
when each segment carries equal `|g''|^(1/2)`.

![what the metric is](figures/placement_decision/06_what_the_metric_is.png)

**Top panel** — the seven channels it watches: leading-edge x (sweep), z (dihedral),
chord, twist, thickness, camber, control gain.

**Middle panel** — each channel is divided by a *fixed physical scale* (lengths by
root chord, twist by 10°, thickness/camber by 0.1), differentiated twice, square-
rooted, and combined by taking the **worst** channel, not the average. Averaging
lets six calm channels dilute one violent one. `control_gain` is weighted ×3;
`thickness` ×0, because AVL is a mean-surface method that never sees thickness. A
floor of 0.50 stops any region being starved.

**Bottom panel** — the resulting stations, against uniform, with the six hard
feature pins that are never dropped.

> The fixed physical scale in the middle step is a repair. The original code
> normalised each channel to unit integral, which erased magnitude: a 40° sweep
> break and a 0.02° twist wiggle both integrated to 1.000 and got equal say.

## What the monitor actually trades

Mean error per quantity across all 10 geometries. This is the table that decides it:

| quantity | A no pins | **B pinned** | C adopted | D always |
|---|---|---|---|---|
| CL_δe | 14.27% | 0.64% | **0.54%** | 0.56% |
| Cm_δe | 14.19% | 0.66% | **0.61%** | 0.64% |
| Cl_δa | 13.29% | 0.60% | **0.50%** | 0.52% |
| CY_δa | 13.39% | 0.64% | 0.65% | **0.57%** |
| Cn_δa | 9.77% | **0.44%** | 0.45% | 0.51% |
| **CDind** | 2.56% | **0.18%** | 0.58% | 1.03% |
| **cd_total** | 5.10% | **0.58%** | 1.15% | 2.26% |
| CL | 1.31% | **0.10%** | 0.40% | 0.49% |
| Cm | 1.95% | **0.10%** | 0.30% | 0.37% |
| Cnb | 1.55% | **0.10%** | 0.19% | 0.31% |
| Xnp | 0.01% | **0.01%** | 0.02% | 0.02% |

The monitor buys about **0.1 percentage point** on the control derivatives it was
built to improve, and pays **0.4 pp on induced drag and 0.57 pp on total drag** for
it. Forcing it on every geometry (D) triples the induced-drag penalty.

This is physically sensible rather than surprising. Induced drag is an integral over
the *whole* spanwise load distribution. Adaptive placement concentrates stations at
control edges and high-curvature regions, which necessarily thins coverage
everywhere else — and the rest of the span is precisely what the drag integral
needs. The monitor optimises a local quantity at the expense of a global one.

## The ramp criterion is real but not dominant

The monitor does what it claims mechanically. On the narrow elevon it cut the
gain-ramp fraction from **66.7% to 13.0%** — a 5× improvement, exactly as designed —
and that did halve the control error there (1.52% → 0.63%). But averaged over ten
geometries a 5× ramp reduction bought only 0.1 pp.

Note also that a narrow band has a *structurally* high ramp: with 25 stations the
uniform spacing is 0.042 of span, so a band 0.15 wide has neighbours contributing
(0.042 + 0.042)/0.15 = 56% ramp no matter what, unless stations are deliberately
clustered. So DECISION-0010's 15% limit is not reachable for narrow elevons by
pinning alone — which is what made adaptive placement look necessary.

## Audit: the first verdict of this study was wrong

An earlier version of this page concluded that adaptive placement cost induced drag
and recommended `never`. **That conclusion was withdrawn.** Two checks killed it.

### The reference was not neutral

The reference was 49 sections, uniform + pinned — the *same construction* as
candidate B. A yardstick that shares one candidate's structure flatters it. Worse,
the reference disagrees with **itself** depending on how its own sections are
placed:

![reference not neutral](figures/placement_decision/07_reference_not_neutral.png)

| reference sections | nominal | elevon_narrow |
|---|---|---|
| 49 | 2.90% | 0.83% |
| 73 | 1.37% | 0.67% |
| 97 | 1.17% | 0.74% |

It plateaus above 1% instead of converging. The B-vs-C gap being measured was ~1 pp.
**The yardstick's own uncertainty was larger than the effect** — so the drag result
was noise, not a measurement.

The cause is physical, not a bug: AVL computes induced drag by Trefftz-plane
integration of the spanwise load, which is acutely sensitive to how stations sample
that load. More sections does not remove the sensitivity.

> **Rule of record: `CDind`, `cd_total` and `e` must not be used to rank spanwise
> discretisation choices in AVL.** Report them; never adjudicate with them.

### At what budget does adaptive pay?

![budget sweep](figures/placement_decision/08_budget_sweep.png)

On the narrow elevon — where reference noise on control derivatives is only 0.06% —
adaptive beats uniform at **every** budget tested:

| sections | uniform + pins | adaptive |
|---|---|---|
| 11 | 6.26% | **4.43%** |
| 15 | 2.94% | **0.63%** |
| 19 | 1.25% | **0.20%** |
| 25 | 1.52% | **0.63%** |

## Verdict

**Use `section_placement: auto` with `snap_sections_to_control: true`.**

Re-ranked on the quantities the reference can resolve — control derivatives, forces
and stability derivatives, **excluding drag**:

| approach | mean | **max** |
|---|---|---|
| A uniform, no pins | 15.17% | 34.54% |
| B uniform + hard pins | **0.82%** | 1.98% |
| C adaptive, gated (`auto`) | 0.86% | **1.68%** |
| D adaptive, forced | 0.91% | 1.68% |

1. **Hard feature pins do nearly all the work.** Without them the worst case is
   34.54%; with them, under 2%. This is the largest effect here and is not in doubt.
2. **B and C tie on the mean** — 0.04 pp apart, inside the reference's own ~0.5%
   control-derivative noise. Neither is "better on average"; saying so would be
   over-reading the data.
3. **C has the better tail** and wins where the gain ramp is severe: narrow elevon
   (66.7% ramp) 1.52% → 1.12%, random_1020 (36.3%) 1.98% → 1.42%. On the five
   benign geometries the gate does not fire and C is identical to B.

For a design sweep you cannot inspect design-by-design, the worst case is the number
that matters. Gating gives that improvement while changing nothing where uniform
already suffices — which is exactly what a gate is for.

### Honest limits

- Ten geometries; differences of 0.3 pp. The **tail** result is actionable. The mean
  difference is not, and is reported as a tie.
- The gate is imperfect: random_1001 had a 32.7% ramp and got *worse* under adaptive
  placement (0.81% → 1.68%). Ramp alone does not fully predict benefit. Retuning the
  threshold is open work.
- Reference is a finer AVL mesh, not CFD or experiment: this is **discretisation
  convergence**, not physical accuracy.

### Settings to use

```yaml
geometry:
  aero_discretisation:
    n_sections: 25                   # FINAL count, pins included
    span_margin: 0.0                 # full span
    snap_sections_to_control: true   # pins INSERTED, near-duplicates merged
    section_placement: auto          # <- this study
    ramp_fraction_limit: 0.15
    spanwise_panels_per_section: 4
    nchordwise: 12                   # DSE tier (DECISION-0013); 24 to verify
    cspace: 1.0
```

### Reproduce

```bash
python standalone/lowfi_avl_study/placement_decision_study.py     # the comparison
python standalone/lowfi_avl_study/placement_audit.py              # the audit
python standalone/lowfi_avl_study/reference_neutrality.py         # reference check
python standalone/lowfi_avl_study/make_placement_figures.py
python standalone/lowfi_avl_study/make_metric_figures.py
```

Evidence (tracked): `configs/aero/placement_decision_evidence/`,
`configs/aero/placement_audit_evidence/`.
