# Study Protocol — Unified Complexity Section Distribution

Status: protocol + implementation added. Quick budget sweep and full-suite
budget-25 validation completed.

Script:
`standalone/lowfi_avl_study/unified_complexity_distribution_study.py`

Evidence folder:
`configs/aero/unified_complexity_distribution_evidence/`

Figures:
`studies/figures/unified_complexity_distribution/`

## Research Question

For a fixed final number of AVL spanwise sections, does the AERIS unified
spanwise complexity metric give more reliable aerodynamic outputs than the
strong simple baseline: **uniform spacing plus hard feature pins**?

The paper claim must be conditional on the answer:

- If adaptive complexity only ties uniform+pins, publish **hard feature pins** as
  the primary method and report the complexity metric as a targeted extension.
- If adaptive complexity improves the tail without damaging force/stability
  outputs, publish **uniform+pins plus gated unified complexity**.
- Do not publish "adaptive is generally better than uniform" unless it wins across
  budgets, geometries and flight points.

## Why Drag Is Reported But Not Used For Ranking

`CDind`, `cd_total` and `e` are excluded from the placement score.

Reason: the reference-neutrality audit showed that an AVL reference can disagree
with itself on drag depending only on how its own spanwise sections are placed.
The recorded self-disagreement is about 1-3% for drag, larger than the placement
effects being judged. That means drag is not an independent yardstick for
spanwise placement; it is partly another output of the placement rule.

This is not hiding drag. The study still reports drag as a diagnostic. It simply
does not allow an invalid reference to decide the winner.

Ranking quantities:

```text
Core:     CL, Cm, Xnp, CLa, Cma, Clp, Cnb, Cmq
Control: CL_de, Cm_de, Cl_da, CY_da, Cn_da
Report only, not rank: CDind, cd_total, e
```

A relative error is admissible only when `|reference| > 1e-4`, 100 times AVL's
printed precision. Below that, percentage error is dominated by print noise or
zero crossings and must not rank a policy.

## Method Under Test

The method should be named plainly:

> Unified spanwise complexity metric for AVL section placement.

It is "unified" because one monitor combines the spanwise functions AVL
interpolates:

```text
x_le, z_le, chord, twist, camber, thickness, control_gain
```

Each channel is scaled by a fixed physical reference, differentiated twice, and
converted to a density proportional to `sqrt(|g''|)`, the classical
piecewise-linear interpolation-error monitor. The channels are combined with a
worst-channel rule so one sharp feature cannot be diluted by several quiet ones.

The novelty is not "curvature exists." The defensible novelty is:

1. Treating the control-surface gain as a normal spanwise interpolation channel.
2. Combining geometry, airfoil-shape and control-gain channels in one fixed-scale
   monitor.
3. Using hard feature pins for true discontinuities that a curvature monitor
   cannot resolve.
4. Gating adaptive placement so ordinary geometries keep the simpler uniform+pins
   grid.

## Policies

The full script compares:

| key | policy | purpose |
|---|---|---|
| `U0_uniform_no_pins` | uniform spacing, no hard feature pins | bad baseline |
| `U1_uniform_pins` | uniform spacing + hard feature pins | strongest simple baseline |
| `C0_complexity_geom_only` | complexity metric without control channel | ablation |
| `C1_unified_complexity_auto` | unified complexity, gated by ramp criterion | production claim |
| `C2_unified_complexity_always` | unified complexity always on | method stress test |
| `C3_complexity_thickness_on` | complexity with thickness weighted on | physics ablation |
| `C4_complexity_sum_blend` | sum blend instead of worst-channel | metric ablation |

Every policy must deliver the same final section count. Pins are paid from the
budget, not added on top.

## Reference Construction

The reference refines the dimension being tested and not the panel density.

For a candidate budget `B`:

```text
candidate: B sections, 4 spanwise panels per interval
reference: 2B - 1 sections, 2 spanwise panels per interval
```

Both have the same total spanwise strips. Therefore the comparison tests section
placement, not hidden spanwise panel refinement.

Any over-limit AVL combination is skipped and recorded, not silently scored.

## Geometry And Flight Matrix

The script supports `--quick` for smoke tests and `--suite full` for the paper.

The full suite contains constructed stress cases plus random DoE draws:

```text
nominal, benign, narrow elevon, wide elevon, hinge_min, hinge_max,
max_gradient, max_ar, min_ar, max_dihedral, random seeds
```

The flight sweep is:

```text
alpha = -2, 0, 3, 6, 9, 12 deg
de = 4 deg, da = 4 deg
```

The first publication pass should run this matrix at `nchordwise = 12`, because
the placement comparison is same-solver/same-grid and the 12-panel control error
is a known ranking bias. Selected promoted cases should then be repeated at
`nchordwise = 24`.

## Predeclared Acceptance Rule

Compared with `U1_uniform_pins`, `C1_unified_complexity_auto` is publishable as
the recommended rule only if:

1. It lowers the worst or 90th-percentile control-derivative error.
2. It does not raise the 90th-percentile core force/stability error by more than
   0.5 percentage points.
3. It behaves consistently over more than one section budget.
4. It has no unexplained solver failures that are specific to the adaptive grid.

If only item 1 holds, the correct claim is tail-risk reduction, not general
superiority. If item 1 does not hold, publish uniform+pins.

## Results To Date

Two evidence sets have been generated:

```text
quick budget sweep:
  configs/aero/unified_complexity_distribution_evidence/
    unified_complexity_distribution_quick_20260727.json

full-suite budget-25 validation:
  configs/aero/unified_complexity_distribution_evidence/
    unified_complexity_distribution_full_b25_20260727.json
```

Both reports completed with zero recorded AVL failures.

The quick sweep used 4 geometries, 5 section budgets, 1 flight point and all
seven policies. On that matrix, the strongest ranked method was
`U1_uniform_pins`:

| policy | mean control error | max control error | mean core error |
|---|---:|---:|---:|
| `U0_uniform_no_pins` | 24.69% | 51.11% | 3.01% |
| `U1_uniform_pins` | 1.32% | 3.26% | 0.53% |
| `C1_unified_complexity_auto` | 1.90% | 7.58% | 1.54% |
| `C3_complexity_thickness_on` | 1.74% | 7.44% | 1.58% |
| `C4_complexity_sum_blend` | 1.65% | 5.64% | 1.26% |

The full-suite budget-25 validation used 16 geometries, 6 flight points and the
selected baseline/comparator policy set. On that larger fixed-budget matrix,
the adaptive policies reduced control-band ramping and some average/p90 control
errors, but they did not dominate the simple baseline in worst-case ranked
error:

| policy | mean control error | p90 control error | max control error | max ranked error | mean ramp fraction |
|---|---:|---:|---:|---:|---:|
| `U0_uniform_no_pins` | 14.82% | 24.63% | 48.04% | 57.62% | 15.70% |
| `U1_uniform_pins` | 0.93% | 1.91% | 4.81% | 4.81% | 18.94% |
| `C1_unified_complexity_auto` | 0.93% | 1.76% | 4.81% | 7.54% | 9.32% |
| `C3_complexity_thickness_on` | 0.85% | 1.49% | 7.14% | 7.14% | 5.10% |
| `C4_complexity_sum_blend` | 0.77% | 1.04% | 6.31% | 6.31% | 7.25% |

Therefore the current defensible conclusion is:

> Publish **uniform spacing plus hard feature pins** as the recommended AVL
> section-placement rule. Present the unified complexity metric as a useful
> diagnostic and as a candidate tail/mean-error reducer at fixed budget, but do
> not yet claim it is the generally superior default.

This conclusion is conservative but hard to attack. The adaptive metric clearly
reduces the control-band ramp metric, but the predeclared acceptance rule also
requires consistent superiority across budgets and no worse tail behavior.
Those conditions are not yet satisfied.

## Commands

Fast figure generation from the existing evidence:

```bash
python standalone/lowfi_avl_study/unified_complexity_distribution_study.py figures-existing
```

Small smoke campaign:

```bash
python standalone/lowfi_avl_study/unified_complexity_distribution_study.py run --quick
```

Full publication campaign:

```bash
python standalone/lowfi_avl_study/unified_complexity_distribution_study.py run --suite full
```

Targeted full-suite budget-25 validation used for the current evidence:

```bash
python standalone/lowfi_avl_study/unified_complexity_distribution_study.py run \
  --suite full \
  --budgets 25 \
  --policies U0_uniform_no_pins,U1_uniform_pins,C1_unified_complexity_auto,C3_complexity_thickness_on,C4_complexity_sum_blend
```

Use `--nchordwise 24` for verification repeats where AVL limits allow it.
